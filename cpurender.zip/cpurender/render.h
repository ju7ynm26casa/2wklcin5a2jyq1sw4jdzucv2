#ifndef CPURENDER_RENDER_H
#define CPURENDER_RENDER_H

#include <stdint.h>
#include <stddef.h>

#define RT_WIDTH  1280
#define RT_HEIGHT 720
#define RT_MAX_BOUNCES 3
#define RT_NUM_SPHERES 5
#define RT_PLANE_Y (-1.15f)
#define RT_HIT_EPS 1e-3f
#define RT_MAX_DIST 1e6f

typedef struct {
    float posx, posy, posz, _p0;
    float fwdx, fwdy, fwdz, _p1;
    float rtx,  rty,  rtz,  _p2;
    float upx,  upy,  upz,  _p3;
    float ldx,  ldy,  ldz,  _p4;
    float aspect, fov_scale, inv_w, inv_h;
} RenderCam;

/* Sphere data as structure-of-arrays, 8-wide padded for AVX2 gathers. */
typedef struct {
    float cx[8], cy[8], cz[8], r2[8];
    float cr[8], cg[8], cb[8], refl[8];
} SphereSOA;

#ifdef __cplusplus
extern "C" {
#endif

void render_scanlines_ref (uint8_t *fb, int pitch, int y0, int y1,
                           const RenderCam *cam, const SphereSOA *sph);
void render_scanlines_avx2(uint8_t *fb, int pitch, int y0, int y1,
                           const RenderCam *cam, const SphereSOA *sph);

#ifdef __cplusplus
}
#endif

#endif
