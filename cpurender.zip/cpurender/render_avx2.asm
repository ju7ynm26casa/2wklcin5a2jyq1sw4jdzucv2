; =============================================================================
; render_avx2.asm — 8-wide AVX2/AVX-512 packet tracer for CPURender
;
; SysV AMD64 export:
;   void render_scanlines_avx2(uint8_t *fb, int pitch, int y0, int y1,
;                              const RenderCam *cam, const SphereSOA *sph);
;
; Generated from Clang 18 -O3 -ffast-math -march=native (Intel syntax) and
; converted to NASM. The kernel traces 8 primary rays at a time against 5
; spheres + a ground plane, with hard shadows and 3 reflection bounces.
; =============================================================================
bits 64
default rel

section .rodata
align 4
LCPI0_0:
    dd 0x3f800000
LCPI0_1:
    dd 0x80000000
LCPI0_2:
    dd 0x3f000000
LCPI0_3:
    dd 0xc0000000
LCPI0_5:
    dd 0x40000000
LCPI0_6:
    dd 0x358637bd
LCPI0_7:
    dd 0xbf933333
LCPI0_8:
    dd 0x1e3ce508
LCPI0_9:
    dd 0x3a83126f
LCPI0_10:
    dd 0x49742400
LCPI0_11:
    db 1
    db 0
    db 0
    db 0
LCPI0_15:
    dd 0x7fffffff
LCPI0_16:
    dd 0x322bcc77
LCPI0_17:
    dd 2
LCPI0_18:
    dd 0x40400000
LCPI0_19:
    dd 0x3e3851ec
LCPI0_20:
    dd 0x3f3851ec
LCPI0_21:
    dd 0x3ea3d70a
LCPI0_22:
    dd 0x3f51eb85
LCPI0_23:
    dd 0x3f733333
LCPI0_24:
    dd 0x3f7f3b64
LCPI0_25:
    dd 0x43a6aaab
LCPI0_26:
    dd 0xc3a62aab
LCPI0_27:
    dd 0x3f4ccccd
LCPI0_28:
    dd 0x3f19999a
LCPI0_29:
    dd 0x3e4ccccd
LCPI0_30:
    dd 0x3df5c28f
LCPI0_31:
    dd 0x3b83126f
LCPI0_32:
    dd 0x3eb33333
LCPI0_33:
    dd 0x3e0f5c29
LCPI0_34:
    dd 0x437f0000
LCPI0_36:
    times 4 db 255
align 32
LCPI0_4:
    dd 0x3f000000
    dd 0x3fc00000
    dd 0x40200000
    dd 0x40600000
    dd 0x40900000
    dd 0x40b00000
    dd 0x40d00000
    dd 0x40f00000
LCPI0_12:
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
    db 2
    db 0
    db 0
    db 0
LCPI0_13:
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
    db 3
    db 0
    db 0
    db 0
LCPI0_14:
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
    db 4
    db 0
    db 0
    db 0
LCPI0_35:
    times 32 db 255

section .text
global render_scanlines_avx2
align 16
render_scanlines_avx2:
	cmp	edx, ecx
	jge	LBB0_9
	sub	rsp, 1816
	vbroadcastss	ymm0, dword [r8]
	vmovups	yword [rsp + 528], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 4]
	vmovups	yword [rsp + 496], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 8]
	vmovups	yword [rsp + 464], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 16]
	vmovups	yword [rsp + 208], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 20]
	vmovups	yword [rsp + 176], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 24]
	vmovups	yword [rsp + 144], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 32]
	vmovups	yword [rsp + 432], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 36]
	vmovups	yword [rsp + 400], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 40]
	vmovups	yword [rsp + 368], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 48]
	vmovups	yword [rsp + 112], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 52]
	vmovups	yword [rsp + 80], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 56]
	vmovups	yword [rsp + 48], ymm0  ; 32-byte Spill
	vbroadcastss	ymm1, dword [r8 + 64]
	vbroadcastss	ymm2, dword [r8 + 68]
	vbroadcastss	ymm3, dword [r8 + 72]
	vbroadcastss	ymm0, dword [r8 + 84]
	vmovups	yword [rsp + 16], ymm0  ; 32-byte Spill
	vmulss	xmm0, xmm0, dword [r8 + 80]
	vbroadcastss	ymm0, xmm0
	vmovups	yword [rsp + 336], ymm0  ; 32-byte Spill
	vbroadcastss	ymm0, dword [r8 + 88]
	vmovups	yword [rsp + 304], ymm0  ; 32-byte Spill
	vmovss	xmm0, dword [r8 + 92]  ; xmm0 = mem[0],zero,zero,zero
	vmovss	dword [rsp - 116], xmm0  ; 4-byte Spill
	movsxd	rax, esi
	vmovups	yword [rsp + 816], ymm3  ; 32-byte Spill
	vmulss	xmm0, xmm3, xmm3
	vmovups	yword [rsp + 848], ymm2  ; 32-byte Spill
	vfmadd231ps	ymm0, ymm2, ymm2  ; ymm0 = (ymm2 * ymm2) + ymm0
	vmovups	yword [rsp + 880], ymm1  ; 32-byte Spill
	vfmadd231ps	ymm0, ymm1, ymm1  ; ymm0 = (ymm1 * ymm1) + ymm0
	vbroadcastss	ymm1, xmm0
	vmovss	xmm2, dword [rel LCPI0_0]  ; xmm2 = [1.0E+0,0.0E+0,0.0E+0,0.0E+0]
	vdivss	xmm0, xmm2, xmm0
	vbroadcastss	ymm0, xmm0
	vbroadcastss	ymm2, dword [rel LCPI0_1]  ; ymm2 = [-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0,-0.0E+0]
	vxorps	ymm1, ymm1, ymm2
	vmovups	yword [rsp + 720], ymm1  ; 32-byte Spill
	vmovups	yword [rsp + 784], ymm0  ; 32-byte Spill
	vmovups	yword [rsp + 752], ymm2  ; 32-byte Spill
	vxorps	ymm0, ymm0, ymm2
	vmovups	yword [rsp + 688], ymm0  ; 32-byte Spill
	movsxd	rdx, edx
	movsxd	rcx, ecx
	vbroadcastss	ymm0, dword [rel LCPI0_3]  ; ymm0 = [-2.0E+0,-2.0E+0,-2.0E+0,-2.0E+0,-2.0E+0,-2.0E+0,-2.0E+0,-2.0E+0]
	vmovups	yword [rsp - 16], ymm0  ; 32-byte Spill
	vbroadcastss	ymm8, dword [rel LCPI0_0]  ; ymm8 = [1.0E+0,1.0E+0,1.0E+0,1.0E+0,1.0E+0,1.0E+0,1.0E+0,1.0E+0]
	vbroadcastss	ymm0, dword [rel LCPI0_5]  ; ymm0 = [2.0E+0,2.0E+0,2.0E+0,2.0E+0,2.0E+0,2.0E+0,2.0E+0,2.0E+0]
	vmovups	yword [rsp + 272], ymm0  ; 32-byte Spill
	vbroadcastss	ymm24, dword [rel LCPI0_6]  ; ymm24 = [9.99999997E-7,9.99999997E-7,9.99999997E-7,9.99999997E-7,9.99999997E-7,9.99999997E-7,9.99999997E-7,9.99999997E-7]
	vbroadcastss	ymm0, dword [rel LCPI0_34]  ; ymm0 = [2.55E+2,2.55E+2,2.55E+2,2.55E+2,2.55E+2,2.55E+2,2.55E+2,2.55E+2]
	vmovups	yword [rsp + 240], ymm0  ; 32-byte Spill
	vmovups	yword [rsp - 48], ymm8  ; 32-byte Spill
	vmovups	yword [rsp + 656], ymm24  ; 32-byte Spill
	vmovups	ymm28, yword [rsp + 816]  ; 32-byte Reload
	vmovups	ymm27, yword [rsp + 848]  ; 32-byte Reload
	jmp	LBB0_2
align 16
LBB0_7:
	inc	rdx
	cmp	rdx, rcx
	je	LBB0_8
LBB0_2:
	mov	rsi, rdx
	imul	rsi, rax
	add	rsi, rdi
	vcvtsi2ss	xmm0, xmm11, edx
	vaddss	xmm0, xmm0, dword [rel LCPI0_2]
	vmulss	xmm0, xmm0, dword [rsp - 116]  ; 4-byte Folded Reload
	vbroadcastss	ymm0, xmm0
	vfmadd132ps	ymm0, ymm8, yword [rsp - 16]  ; 32-byte Folded Reload
	vmulps	ymm1, ymm0, yword [rsp + 16]  ; 32-byte Folded Reload
	vmovaps	ymm2, ymm1
	vmovups	ymm0, yword [rsp + 80]  ; 32-byte Reload
	vfmadd213ps	ymm2, ymm0, yword [rsp + 176]  ; 32-byte Folded Reload
	vmovups	yword [rsp + 592], ymm2  ; 32-byte Spill
	vmovups	ymm0, yword [rsp + 112]  ; 32-byte Reload
	vfmadd213ps	ymm0, ymm1, yword [rsp + 208]  ; 32-byte Folded Reload
	vmovups	yword [rsp + 560], ymm0  ; 32-byte Spill
	vmovups	ymm0, yword [rsp + 48]  ; 32-byte Reload
	vfmadd213ps	ymm1, ymm0, yword [rsp + 144]  ; 32-byte Folded Reload
	vmovups	yword [rsp + 624], ymm1  ; 32-byte Spill
	xor	r8d, r8d
	jmp	LBB0_3
align 16
LBB0_6:
	vxorps	xmm2, xmm2, xmm2
	vmaxps	ymm0, ymm26, ymm2
	vminps	ymm0, ymm8, ymm0
	vmovups	ymm3, yword [rsp + 240]  ; 32-byte Reload
	vmulps	ymm0, ymm0, ymm3
	vmaxps	ymm1, ymm20, ymm2
	vminps	ymm1, ymm8, ymm1
	vmulps	ymm1, ymm1, ymm3
	vmaxps	ymm2, ymm29, ymm2
	vminps	ymm2, ymm8, ymm2
	vmulps	ymm2, ymm2, ymm3
	vcvtps2dq	ymm0, ymm0
	vcvtps2dq	ymm1, ymm1
	vcvtps2dq	ymm2, ymm2
	vpslld	ymm1, ymm1, 8
	vpslld	ymm0, ymm0, 16
	vpternlogd	ymm0, ymm2, ymm1, 254
	vmovdqu	yword [rsi + 4*r8], ymm0
	lea	r10, [r8 + 8]
	cmp	r8, 1272
	mov	r8, r10
	jae	LBB0_7
LBB0_3:
	vcvtsi2ss	xmm0, xmm11, r8d
	vbroadcastss	ymm0, xmm0
	vaddps	ymm0, ymm0, yword [rel LCPI0_4]
	vmulps	ymm0, ymm0, yword [rsp + 304]  ; 32-byte Folded Reload
	vfmsub132ps	ymm0, ymm8, yword [rsp + 272]  ; 32-byte Folded Reload
	vmulps	ymm31, ymm0, yword [rsp + 336]  ; 32-byte Folded Reload
	vmovaps	ymm9, ymm31
	vmovups	ymm0, yword [rsp + 560]  ; 32-byte Reload
	vfmadd132ps	ymm9, ymm0, yword [rsp + 432]  ; 32-byte Folded Reload
	vmovaps	ymm7, ymm31
	vmovups	ymm0, yword [rsp + 592]  ; 32-byte Reload
	vfmadd132ps	ymm7, ymm0, yword [rsp + 400]  ; 32-byte Folded Reload
	vmovups	ymm0, yword [rsp + 624]  ; 32-byte Reload
	vfmadd132ps	ymm31, ymm0, yword [rsp + 368]  ; 32-byte Folded Reload
	xor	r10d, r10d
	vxorps	xmm26, xmm26, xmm26
	vmovups	ymm0, yword [rsp + 528]  ; 32-byte Reload
	vmovups	ymm1, yword [rsp + 496]  ; 32-byte Reload
	vmovups	ymm21, yword [rsp + 464]  ; 32-byte Reload
	vxorps	xmm20, xmm20, xmm20
	vxorps	xmm29, xmm29, xmm29
	vmovaps	ymm25, ymm8
align 16
LBB0_4:
	vcmpgtps	k0, ymm25, ymm24
	kortestb	k0, k0
	je	LBB0_6
	vmulps	ymm4, ymm31, ymm31
	vfmadd231ps	ymm4, ymm7, ymm7  ; ymm4 = (ymm7 * ymm7) + ymm4
	vfmadd231ps	ymm4, ymm9, ymm9  ; ymm4 = (ymm9 * ymm9) + ymm4
	vrcpps	ymm3, ymm4
	vmovaps	ymm2, ymm3
	vfmsub213ps	ymm2, ymm4, ymm8  ; ymm2 = (ymm4 * ymm2) - ymm8
	vfnmadd132ps	ymm2, ymm3, ymm3  ; ymm2 = -(ymm2 * ymm3) + ymm3
	vcmpgtps	k1, ymm4, dword [rel LCPI0_8]{1to8}
	vmovups	ymm18, yword [rsp + 752]  ; 32-byte Reload
	vxorps	ymm17, ymm2, ymm18
	vbroadcastss	ymm3, dword [r9]
	vmovups	yword [rsp + 912], ymm3  ; 32-byte Spill
	vsubps	ymm3, ymm0, ymm3
	vbroadcastss	ymm5, dword [r9 + 32]
	vmovups	yword [rsp + 1744], ymm5  ; 32-byte Spill
	vsubps	ymm6, ymm1, ymm5
	vbroadcastss	ymm5, dword [r9 + 64]
	vmovups	yword [rsp + 1680], ymm5  ; 32-byte Spill
	vsubps	ymm8, ymm21, ymm5
	vmovups	yword [rsp - 80], ymm9  ; 32-byte Spill
	vmulps	ymm9, ymm8, ymm31
	vfmadd231ps	ymm9, ymm7, ymm6  ; ymm9 = (ymm7 * ymm6) + ymm9
	vfmadd231ps	ymm9, ymm3, yword [rsp - 80]  ; 32-byte Folded Reload
	vmulps	ymm8, ymm8, ymm8
	vfmadd231ps	ymm8, ymm6, ymm6  ; ymm8 = (ymm6 * ymm6) + ymm8
	vfnmsub231ps	ymm8, ymm3, ymm3  ; ymm8 = -(ymm3 * ymm3) - ymm8
	vbroadcastss	ymm3, dword [r9 + 96]
	vmovups	yword [rsp + 1712], ymm3  ; 32-byte Spill
	vaddps	ymm3, ymm8, ymm3
	vmulps	ymm6, ymm9, ymm9
	vfmadd231ps	ymm6, ymm4, ymm3  ; ymm6 = (ymm4 * ymm3) + ymm6
	vxorps	xmm5, xmm5, xmm5
	vcmpleps	k0 {k1}, ymm5, ymm6
	vmaxps	ymm3, ymm6, ymm5
	vsqrtps	ymm3, ymm3
	vaddps	ymm6, ymm9, ymm3
	vmulps	ymm10, ymm6, ymm17
	vsubps	ymm3, ymm3, ymm9
	vmulps	ymm3, ymm3, ymm2
	vbroadcastss	ymm8, dword [rel LCPI0_9]  ; ymm8 = [1.00000005E-3,1.00000005E-3,1.00000005E-3,1.00000005E-3,1.00000005E-3,1.00000005E-3,1.00000005E-3,1.00000005E-3]
	vcmpleps	k2, ymm8, ymm10
	vbroadcastss	ymm6, dword [rel LCPI0_10]  ; ymm6 = [1.0E+6,1.0E+6,1.0E+6,1.0E+6,1.0E+6,1.0E+6,1.0E+6,1.0E+6]
	vmovups	yword [rsp + 1488], ymm6  ; 32-byte Spill
	vcmpleps	k2 {k2}, ymm10, ymm6
	kandb	k2, k2, k0
	vpmovm2d	ymm9, k2
	vcmpleps	k2, ymm8, ymm3
	vcmpleps	k2 {k2}, ymm3, ymm6
	kandb	k2, k2, k0
	vpcmpeqd	ymm14, ymm14, ymm14
	vpxord	ymm12 {k2}{z}, ymm9, ymm14
	vblendvps	ymm3, ymm10, ymm3, ymm12
	vpor	ymm10, ymm12, ymm9
	vblendvps	ymm3, ymm6, ymm3, ymm10
	vpbroadcastd	ymm13, dword [rel LCPI0_11]  ; ymm13 = [1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0,0]
	vpblendvb	ymm9, ymm5, ymm13, ymm10
	vpblendvb	ymm10, ymm14, ymm5, ymm10
	vpcmpeqd	ymm11, ymm11, ymm11
	vbroadcastss	ymm12, dword [r9 + 4]
	vmovups	yword [rsp + 1776], ymm12  ; 32-byte Spill
	vsubps	ymm12, ymm0, ymm12
	vbroadcastss	ymm14, dword [r9 + 36]
	vmovups	yword [rsp + 1616], ymm14  ; 32-byte Spill
	vsubps	ymm14, ymm1, ymm14
	vbroadcastss	ymm15, dword [r9 + 68]
	vmovups	yword [rsp + 1552], ymm15  ; 32-byte Spill
	vsubps	ymm15, ymm21, ymm15
	vmulps	ymm16, ymm15, ymm31
	vfmadd231ps	ymm16, ymm7, ymm14  ; ymm16 = (ymm7 * ymm14) + ymm16
	vfmadd231ps	ymm16, ymm12, yword [rsp - 80]  ; 32-byte Folded Reload
	vmulps	ymm15, ymm15, ymm15
	vfmadd231ps	ymm15, ymm14, ymm14  ; ymm15 = (ymm14 * ymm14) + ymm15
	vfnmsub231ps	ymm15, ymm12, ymm12  ; ymm15 = -(ymm12 * ymm12) - ymm15
	vbroadcastss	ymm12, dword [r9 + 100]
	vmovups	yword [rsp + 1584], ymm12  ; 32-byte Spill
	vaddps	ymm12, ymm12, ymm15
	vmulps	ymm14, ymm16, ymm16
	vfmadd231ps	ymm14, ymm4, ymm12  ; ymm14 = (ymm4 * ymm12) + ymm14
	vcmpleps	k0 {k1}, ymm5, ymm14
	vmaxps	ymm12, ymm14, ymm5
	vsqrtps	ymm12, ymm12
	vaddps	ymm14, ymm16, ymm12
	vmulps	ymm14, ymm14, ymm17
	vsubps	ymm12, ymm12, ymm16
	vmulps	ymm12, ymm12, ymm2
	vcmpleps	k2, ymm8, ymm14
	vcmpleps	k2 {k2}, ymm14, ymm3
	kandb	k2, k2, k0
	vpmovm2d	ymm15, k2
	vcmpleps	k2, ymm8, ymm12
	vcmpleps	k2 {k2}, ymm12, ymm3
	kandb	k2, k2, k0
	vmovups	yword [rsp - 112], ymm7  ; 32-byte Spill
	vpxord	ymm7 {k2}{z}, ymm15, ymm11
	vblendvps	ymm12, ymm14, ymm12, ymm7
	vpor	ymm7, ymm15, ymm7
	vblendvps	ymm3, ymm3, ymm12, ymm7
	vpblendvb	ymm9, ymm9, ymm13, ymm7
	vpblendvb	ymm10, ymm10, ymm13, ymm7
	vbroadcastss	ymm7, dword [r9 + 8]
	vmovups	yword [rsp + 1648], ymm7  ; 32-byte Spill
	vsubps	ymm7, ymm0, ymm7
	vbroadcastss	ymm6, dword [r9 + 40]
	vmovups	yword [rsp + 1456], ymm6  ; 32-byte Spill
	vsubps	ymm12, ymm1, ymm6
	vbroadcastss	ymm6, dword [r9 + 72]
	vmovups	yword [rsp + 1392], ymm6  ; 32-byte Spill
	vsubps	ymm14, ymm21, ymm6
	vmulps	ymm15, ymm14, ymm31
	vfmadd231ps	ymm15, ymm12, yword [rsp - 112]  ; 32-byte Folded Reload
	vfmadd231ps	ymm15, ymm7, yword [rsp - 80]  ; 32-byte Folded Reload
	vmulps	ymm14, ymm14, ymm14
	vfmadd231ps	ymm14, ymm12, ymm12  ; ymm14 = (ymm12 * ymm12) + ymm14
	vfnmsub231ps	ymm14, ymm7, ymm7  ; ymm14 = -(ymm7 * ymm7) - ymm14
	vbroadcastss	ymm6, dword [r9 + 104]
	vmovups	yword [rsp + 1424], ymm6  ; 32-byte Spill
	vaddps	ymm7, ymm14, ymm6
	vmulps	ymm12, ymm15, ymm15
	vfmadd231ps	ymm12, ymm4, ymm7  ; ymm12 = (ymm4 * ymm7) + ymm12
	vcmpleps	k0 {k1}, ymm5, ymm12
	vmaxps	ymm7, ymm12, ymm5
	vsqrtps	ymm7, ymm7
	vaddps	ymm12, ymm15, ymm7
	vmulps	ymm12, ymm12, ymm17
	vsubps	ymm7, ymm7, ymm15
	vmulps	ymm7, ymm7, ymm2
	vcmpleps	k2, ymm8, ymm12
	vcmpleps	k2 {k2}, ymm12, ymm3
	kandb	k2, k2, k0
	vpmovm2d	ymm14, k2
	vcmpleps	k2, ymm8, ymm7
	vcmpleps	k2 {k2}, ymm7, ymm3
	kandb	k2, k2, k0
	vpxord	ymm15 {k2}{z}, ymm14, ymm11
	vblendvps	ymm7, ymm12, ymm7, ymm15
	vpor	ymm14, ymm15, ymm14
	vblendvps	ymm3, ymm3, ymm7, ymm14
	vpblendvb	ymm12, ymm9, ymm13, ymm14
	vpblendvb	ymm10, ymm10, yword [rel LCPI0_12], ymm14
	vbroadcastss	ymm7, dword [r9 + 12]
	vmovups	yword [rsp + 1520], ymm7  ; 32-byte Spill
	vsubps	ymm7, ymm0, ymm7
	vbroadcastss	ymm6, dword [r9 + 44]
	vmovups	yword [rsp + 1360], ymm6  ; 32-byte Spill
	vsubps	ymm9, ymm1, ymm6
	vbroadcastss	ymm6, dword [r9 + 76]
	vmovups	yword [rsp + 1296], ymm6  ; 32-byte Spill
	vsubps	ymm14, ymm21, ymm6
	vmulps	ymm15, ymm14, ymm31
	vfmadd231ps	ymm15, ymm9, yword [rsp - 112]  ; 32-byte Folded Reload
	vfmadd231ps	ymm15, ymm7, yword [rsp - 80]  ; 32-byte Folded Reload
	vmulps	ymm14, ymm14, ymm14
	vfmadd231ps	ymm14, ymm9, ymm9  ; ymm14 = (ymm9 * ymm9) + ymm14
	vfnmsub231ps	ymm14, ymm7, ymm7  ; ymm14 = -(ymm7 * ymm7) - ymm14
	vbroadcastss	ymm6, dword [r9 + 108]
	vmovups	yword [rsp + 1328], ymm6  ; 32-byte Spill
	vaddps	ymm7, ymm14, ymm6
	vmulps	ymm9, ymm15, ymm15
	vfmadd231ps	ymm9, ymm4, ymm7  ; ymm9 = (ymm4 * ymm7) + ymm9
	vcmpleps	k0 {k1}, ymm5, ymm9
	vmaxps	ymm7, ymm9, ymm5
	vsqrtps	ymm7, ymm7
	vaddps	ymm9, ymm15, ymm7
	vmulps	ymm9, ymm9, ymm17
	vsubps	ymm7, ymm7, ymm15
	vmulps	ymm7, ymm7, ymm2
	vcmpleps	k2, ymm8, ymm9
	vcmpleps	k2 {k2}, ymm9, ymm3
	kandb	k2, k2, k0
	vpmovm2d	ymm14, k2
	vcmpleps	k2, ymm8, ymm7
	vcmpleps	k2 {k2}, ymm7, ymm3
	kandb	k2, k2, k0
	vpxord	ymm15 {k2}{z}, ymm14, ymm11
	vblendvps	ymm7, ymm9, ymm7, ymm15
	vpor	ymm15, ymm15, ymm14
	vblendvps	ymm9, ymm3, ymm7, ymm15
	vpblendvb	ymm14, ymm12, ymm13, ymm15
	vpblendvb	ymm3, ymm10, yword [rel LCPI0_13], ymm15
	vmovdqa64	ymm22, ymm3
	vbroadcastss	ymm3, dword [r9 + 48]
	vmovups	yword [rsp + 1264], ymm3  ; 32-byte Spill
	vsubps	ymm3, ymm1, ymm3
	vbroadcastss	ymm5, dword [r9 + 80]
	vmovups	yword [rsp + 1232], ymm5  ; 32-byte Spill
	vsubps	ymm7, ymm21, ymm5
	vmulps	ymm10, ymm7, ymm31
	vfmadd231ps	ymm10, ymm3, yword [rsp - 112]  ; 32-byte Folded Reload
	vmulps	ymm7, ymm7, ymm7
	vfmadd231ps	ymm7, ymm3, ymm3  ; ymm7 = (ymm3 * ymm3) + ymm7
	vbroadcastss	ymm3, dword [r9 + 16]
	vmovups	yword [rsp + 1200], ymm3  ; 32-byte Spill
	vsubps	ymm3, ymm0, ymm3
	vfmadd231ps	ymm10, ymm3, yword [rsp - 80]  ; 32-byte Folded Reload
	vfnmsub231ps	ymm7, ymm3, ymm3  ; ymm7 = -(ymm3 * ymm3) - ymm7
	vbroadcastss	ymm3, dword [r9 + 112]
	vmovups	yword [rsp + 1168], ymm3  ; 32-byte Spill
	vaddps	ymm3, ymm3, ymm7
	vmulps	ymm7, ymm10, ymm10
	vfmadd231ps	ymm7, ymm4, ymm3  ; ymm7 = (ymm4 * ymm3) + ymm7
	vxorps	xmm3, xmm3, xmm3
	vcmpleps	k0 {k1}, ymm3, ymm7
	vmaxps	ymm3, ymm7, ymm3
	vsqrtps	ymm3, ymm3
	vaddps	ymm7, ymm10, ymm3
	vmulps	ymm5, ymm7, ymm17
	vsubps	ymm3, ymm3, ymm10
	vmulps	ymm2, ymm3, ymm2
	vcmpleps	k1, ymm8, ymm5
	vcmpleps	k1 {k1}, ymm5, ymm9
	kandb	k1, k1, k0
	vcmpleps	k2, ymm8, ymm2
	vcmpleps	k2 {k2}, ymm2, ymm9
	kandb	k2, k2, k0
	vpmovm2d	ymm3, k1
	vpxord	ymm7 {k2}{z}, ymm3, ymm11
	vblendvps	ymm2, ymm5, ymm2, ymm7
	vpor	ymm3, ymm7, ymm3
	vblendvps	ymm2, ymm9, ymm2, ymm3
	vbroadcastss	ymm5, dword [rel LCPI0_7]  ; ymm5 = [-1.14999998E+0,-1.14999998E+0,-1.14999998E+0,-1.14999998E+0,-1.14999998E+0,-1.14999998E+0,-1.14999998E+0,-1.14999998E+0]
	vsubps	ymm19, ymm5, ymm1
	vrcpps	ymm5, yword [rsp - 112]  ; 32-byte Folded Reload
	vmulps	ymm7, ymm19, ymm5
	vfmsub231ps	ymm19, ymm7, yword [rsp - 112]  ; 32-byte Folded Reload
	vfnmadd213ps	ymm19, ymm5, ymm7  ; ymm19 = -(ymm5 * ymm19) + ymm7
	vcmpleps	k1, ymm8, ymm19
	vmovups	ymm5, yword [rsp - 112]  ; 32-byte Reload
	vandps	ymm5, ymm5, dword [rel LCPI0_15]{1to8}
	vcmpgeps	k1 {k1}, ymm5, dword [rel LCPI0_16]{1to8}
	vrsqrtps	ymm5, ymm4
	vmulps	ymm7, ymm5, ymm5
	vbroadcastss	ymm6, dword [rel LCPI0_18]  ; ymm6 = [3.0E+0,3.0E+0,3.0E+0,3.0E+0,3.0E+0,3.0E+0,3.0E+0,3.0E+0]
	vfnmadd213ps	ymm7, ymm4, ymm6  ; ymm7 = -(ymm4 * ymm7) + ymm6
	vmovaps	ymm30, ymm6
	vmovups	yword [rsp + 976], ymm6  ; 32-byte Spill
	vbroadcastss	ymm6, dword [rel LCPI0_2]  ; ymm6 = [5.0E-1,5.0E-1,5.0E-1,5.0E-1,5.0E-1,5.0E-1,5.0E-1,5.0E-1]
	vmulps	ymm4, ymm5, ymm6
	vmulps	ymm9, ymm4, ymm7
	vmulps	ymm5, ymm9, yword [rsp - 112]  ; 32-byte Folded Reload
	vmovaps	ymm4, ymm6
	vmovups	yword [rsp + 944], ymm6  ; 32-byte Spill
	vfmadd213ps	ymm4, ymm5, ymm6  ; ymm4 = (ymm5 * ymm4) + ymm6
	vmovaps	ymm15, ymm5
	vmovups	yword [rsp + 1072], ymm5  ; 32-byte Spill
	vmovups	ymm5, yword [rsp - 48]  ; 32-byte Reload
	vsubps	ymm7, ymm5, ymm4
	vbroadcastss	ymm12, dword [rel LCPI0_19]  ; ymm12 = [1.80000007E-1,1.80000007E-1,1.80000007E-1,1.80000007E-1,1.80000007E-1,1.80000007E-1,1.80000007E-1,1.80000007E-1]
	vmulps	ymm16, ymm4, ymm12
	vmovups	yword [rsp + 1008], ymm12  ; 32-byte Spill
	vbroadcastss	ymm5, dword [rel LCPI0_20]  ; ymm5 = [7.20000029E-1,7.20000029E-1,7.20000029E-1,7.20000029E-1,7.20000029E-1,7.20000029E-1,7.20000029E-1,7.20000029E-1]
	vmovups	yword [rsp + 1136], ymm5  ; 32-byte Spill
	vfmadd231ps	ymm16, ymm7, ymm5  ; ymm16 = (ymm7 * ymm5) + ymm16
	vmulps	ymm17, ymm4, dword [rel LCPI0_21]{1to8}
	vbroadcastss	ymm10, dword [rel LCPI0_22]  ; ymm10 = [8.19999992E-1,8.19999992E-1,8.19999992E-1,8.19999992E-1,8.19999992E-1,8.19999992E-1,8.19999992E-1,8.19999992E-1]
	vfmadd231ps	ymm17, ymm7, ymm10  ; ymm17 = (ymm7 * ymm10) + ymm17
	vmulps	ymm4, ymm4, ymm5
	vfmadd231ps	ymm4, ymm7, dword [rel LCPI0_23]{1to8}  ; ymm4 = (ymm7 * mem) + ymm4
	vmulps	ymm7, ymm31, ymm28
	vmovups	yword [rsp + 1104], ymm9  ; 32-byte Spill
	vmulps	ymm7, ymm9, ymm7
	vfmadd231ps	ymm7, ymm15, ymm27  ; ymm7 = (ymm15 * ymm27) + ymm7
	vmulps	ymm9, ymm9, yword [rsp - 80]  ; 32-byte Folded Reload
	vmovups	yword [rsp + 1040], ymm9  ; 32-byte Spill
	vmovups	ymm5, yword [rsp + 880]  ; 32-byte Reload
	vfmadd231ps	ymm7, ymm9, ymm5  ; ymm7 = (ymm9 * ymm5) + ymm7
	vcmpgtps	k2, ymm7, dword [rel LCPI0_24]{1to8}
	vbroadcastss	ymm23, dword [rel LCPI0_25]  ; ymm23 = [3.33333344E+2,3.33333344E+2,3.33333344E+2,3.33333344E+2,3.33333344E+2,3.33333344E+2,3.33333344E+2,3.33333344E+2]
	vfmadd213ps	ymm23 {k2}{z}, ymm7, dword [rel LCPI0_26]{1to8}  ; ymm23 {%k2} {z} = (ymm7 * ymm23) + mem
	vbroadcastss	ymm9, dword [rel LCPI0_27]  ; ymm9 = [8.00000011E-1,8.00000011E-1,8.00000011E-1,8.00000011E-1,8.00000011E-1,8.00000011E-1,8.00000011E-1,8.00000011E-1]
	vfmadd231ps	ymm16, ymm23, ymm9  ; ymm16 = (ymm23 * ymm9) + ymm16
	vfmadd231ps	ymm17, ymm23, dword [rel LCPI0_28]{1to8}  ; ymm17 = (ymm23 * mem) + ymm17
	vbroadcastss	ymm15, dword [rel LCPI0_29]  ; ymm15 = [2.00000003E-1,2.00000003E-1,2.00000003E-1,2.00000003E-1,2.00000003E-1,2.00000003E-1,2.00000003E-1,2.00000003E-1]
	vfmadd213ps	ymm23, ymm15, ymm4  ; ymm23 = (ymm15 * ymm23) + ymm4
	vcmpltps	k2, ymm24, ymm25
	vpblendvb	ymm4, ymm14, ymm13, ymm3
	vcmpleps	k1 {k1}, ymm19, ymm2
	vpbroadcastd	ymm4 {k1}, dword [rel LCPI0_17]
	vpcmpgtd	k3 {k2}, ymm13, ymm4
	kmovw	word [rsp - 118], k3  ; 2-byte Spill
	vmovaps	ymm7 {k3}{z}, ymm25
	vfmadd213ps	ymm16, ymm7, ymm26  ; ymm16 = (ymm7 * ymm16) + ymm26
	vfmadd213ps	ymm17, ymm7, ymm20  ; ymm17 = (ymm7 * ymm17) + ymm20
	vfmadd213ps	ymm23, ymm7, ymm29  ; ymm23 = (ymm7 * ymm23) + ymm29
	vmovdqa64	ymm7, ymm22
	vpblendvb	ymm3, ymm7, yword [rel LCPI0_14], ymm3
	vmovaps	ymm2 {k1}, ymm19
	vfmadd231ps	ymm0, ymm2, yword [rsp - 80]  ; 32-byte Folded Reload
	vfmadd231ps	ymm1, ymm2, yword [rsp - 112]  ; 32-byte Folded Reload
	vfmadd213ps	ymm2, ymm31, ymm21  ; ymm2 = (ymm31 * ymm2) + ymm21
	vmovdqa32	ymm3 {k1}, ymm11
	vxorps	xmm7, xmm7, xmm7
	vpermd	ymm7, ymm3, yword [r9]
	vsubps	ymm14, ymm0, ymm7
	vxorps	xmm7, xmm7, xmm7
	vpermd	ymm7, ymm3, yword [r9 + 32]
	vsubps	ymm19, ymm1, ymm7
	vxorps	xmm7, xmm7, xmm7
	vpermd	ymm7, ymm3, yword [r9 + 64]
	vsubps	ymm20, ymm2, ymm7
	vmulps	ymm7, ymm20, ymm20
	vfmadd231ps	ymm7, ymm19, ymm19  ; ymm7 = (ymm19 * ymm19) + ymm7
	vfmadd231ps	ymm7, ymm14, ymm14  ; ymm7 = (ymm14 * ymm14) + ymm7
	vrsqrtps	ymm11, ymm7
	vmulps	ymm21, ymm11, ymm11
	vfnmadd213ps	ymm21, ymm7, ymm30  ; ymm21 = -(ymm7 * ymm21) + ymm30
	vmulps	ymm7, ymm11, ymm6
	vmulps	ymm11, ymm7, ymm21
	vpcmpeqd	k1, ymm4, ymm13
	vmovups	ymm7, yword [rsp - 48]  ; 32-byte Reload
	vmulps	ymm7 {k1}, ymm11, ymm19
	vmulps	ymm21 {k1}{z}, ymm11, ymm14
	vmulps	ymm30 {k1}{z}, ymm11, ymm20
	vmulps	ymm11, ymm9, ymm0
	vroundps	ymm11, ymm11, 1
	vcvttps2dq	ymm11, ymm11
	vmulps	ymm14, ymm9, ymm2
	vroundps	ymm14, ymm14, 1
	vcvttps2dq	ymm14, ymm14
	vpaddd	ymm11, ymm14, ymm11
	vpand	ymm11, ymm11, ymm13
	vxorps	xmm19, xmm19, xmm19
	vpsubd	ymm11, ymm19, ymm11
	vblendvps	ymm14, ymm15, ymm9, ymm11
	vblendvps	ymm9, ymm12, ymm10, ymm11
	vmovaps	ymm26, ymm9
	vpermps	ymm26 {k1}, ymm3, yword [r9 + 128]
	vpermps	ymm9 {k1}, ymm3, yword [r9 + 160]
	vpermps	ymm14 {k1}, ymm3, yword [r9 + 192]
	vbroadcastss	ymm13, dword [rel LCPI0_30]  ; ymm13 = [1.19999997E-1,1.19999997E-1,1.19999997E-1,1.19999997E-1,1.19999997E-1,1.19999997E-1,1.19999997E-1,1.19999997E-1]
	vpermps	ymm13 {k1}, ymm3, yword [r9 + 224]
	vmulps	ymm3, ymm30, ymm31
	vfmadd231ps	ymm3, ymm7, yword [rsp - 112]  ; 32-byte Folded Reload
	vfmadd231ps	ymm3, ymm21, yword [rsp - 80]  ; 32-byte Folded Reload
	vcmpltps	k1, ymm19, ymm3
	vxorps	xmm12, xmm12, xmm12
	vxorps	ymm21 {k1}, ymm21, ymm18
	vxorps	ymm7 {k1}, ymm7, ymm18
	vxorps	ymm30 {k1}, ymm30, ymm18
	vbroadcastss	ymm3, dword [rel LCPI0_31]  ; ymm3 = [4.00000019E-3,4.00000019E-3,4.00000019E-3,4.00000019E-3,4.00000019E-3,4.00000019E-3,4.00000019E-3,4.00000019E-3]
	vfmadd231ps	ymm0, ymm21, ymm3  ; ymm0 = (ymm21 * ymm3) + ymm0
	vfmadd231ps	ymm1, ymm7, ymm3  ; ymm1 = (ymm7 * ymm3) + ymm1
	vfmadd231ps	ymm2, ymm30, ymm3  ; ymm2 = (ymm30 * ymm3) + ymm2
	vsubps	ymm3, ymm1, yword [rsp + 1744]  ; 32-byte Folded Reload
	vsubps	ymm10, ymm2, yword [rsp + 1680]  ; 32-byte Folded Reload
	vmulps	ymm11, ymm10, ymm28
	vfmadd231ps	ymm11, ymm27, ymm3  ; ymm11 = (ymm27 * ymm3) + ymm11
	vmulps	ymm10, ymm10, ymm10
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm0, yword [rsp + 912]  ; 32-byte Folded Reload
	vfmadd231ps	ymm11, ymm5, ymm3  ; ymm11 = (ymm5 * ymm3) + ymm11
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm10, yword [rsp + 1712]  ; 32-byte Folded Reload
	vmulps	ymm29, ymm11, ymm11
	vmovups	ymm18, yword [rsp + 720]  ; 32-byte Reload
	vfmadd231ps	ymm29, ymm18, ymm3  ; ymm29 = (ymm18 * ymm3) + ymm29
	vmaxps	ymm3, ymm29, ymm12
	vsqrtps	ymm3, ymm3
	vaddps	ymm10, ymm11, ymm3
	vsubps	ymm3, ymm3, ymm11
	vmovups	ymm24, yword [rsp + 688]  ; 32-byte Reload
	vmulps	ymm10, ymm10, ymm24
	vcmpleps	k1, ymm8, ymm10
	vmovups	ymm6, yword [rsp + 1488]  ; 32-byte Reload
	vcmpleps	k0 {k1}, ymm10, ymm6
	vmovups	ymm22, yword [rsp + 784]  ; 32-byte Reload
	vmulps	ymm3, ymm3, ymm22
	vcmpleps	k1, ymm8, ymm3
	vcmpleps	k3 {k1}, ymm3, ymm6
	vsubps	ymm3, ymm1, yword [rsp + 1616]  ; 32-byte Folded Reload
	vsubps	ymm10, ymm2, yword [rsp + 1552]  ; 32-byte Folded Reload
	vmulps	ymm11, ymm10, ymm28
	vfmadd231ps	ymm11, ymm27, ymm3  ; ymm11 = (ymm27 * ymm3) + ymm11
	vmulps	ymm10, ymm10, ymm10
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm0, yword [rsp + 1776]  ; 32-byte Folded Reload
	vfmadd231ps	ymm11, ymm5, ymm3  ; ymm11 = (ymm5 * ymm3) + ymm11
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm10, yword [rsp + 1584]  ; 32-byte Folded Reload
	vmulps	ymm19, ymm11, ymm11
	vfmadd231ps	ymm19, ymm18, ymm3  ; ymm19 = (ymm18 * ymm3) + ymm19
	vmaxps	ymm3, ymm19, ymm12
	vsqrtps	ymm3, ymm3
	vaddps	ymm10, ymm11, ymm3
	vsubps	ymm3, ymm3, ymm11
	vmulps	ymm10, ymm10, ymm24
	vcmpleps	k1, ymm8, ymm10
	vcmpleps	k4 {k1}, ymm10, ymm6
	vmulps	ymm3, ymm3, ymm22
	vcmpleps	k1, ymm8, ymm3
	vcmpleps	k5 {k1}, ymm3, ymm6
	vsubps	ymm3, ymm1, yword [rsp + 1456]  ; 32-byte Folded Reload
	vsubps	ymm10, ymm2, yword [rsp + 1392]  ; 32-byte Folded Reload
	vmulps	ymm11, ymm10, ymm28
	vfmadd231ps	ymm11, ymm27, ymm3  ; ymm11 = (ymm27 * ymm3) + ymm11
	vmulps	ymm10, ymm10, ymm10
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm0, yword [rsp + 1648]  ; 32-byte Folded Reload
	vfmadd231ps	ymm11, ymm5, ymm3  ; ymm11 = (ymm5 * ymm3) + ymm11
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm10, yword [rsp + 1424]  ; 32-byte Folded Reload
	vmulps	ymm20, ymm11, ymm11
	vfmadd231ps	ymm20, ymm18, ymm3  ; ymm20 = (ymm18 * ymm3) + ymm20
	vmaxps	ymm3, ymm20, ymm12
	vsqrtps	ymm3, ymm3
	vaddps	ymm10, ymm11, ymm3
	vsubps	ymm3, ymm3, ymm11
	vmulps	ymm10, ymm10, ymm24
	vcmpleps	k1, ymm8, ymm10
	vcmpleps	k6 {k1}, ymm10, ymm6
	vmulps	ymm3, ymm3, ymm22
	vcmpleps	k1, ymm8, ymm3
	vcmpleps	k7 {k1}, ymm3, ymm6
	vsubps	ymm3, ymm1, yword [rsp + 1360]  ; 32-byte Folded Reload
	vsubps	ymm10, ymm2, yword [rsp + 1296]  ; 32-byte Folded Reload
	vmulps	ymm11, ymm10, ymm28
	vfmadd231ps	ymm11, ymm27, ymm3  ; ymm11 = (ymm27 * ymm3) + ymm11
	vmulps	ymm10, ymm10, ymm10
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm3, ymm0, yword [rsp + 1520]  ; 32-byte Folded Reload
	vfmadd231ps	ymm11, ymm5, ymm3  ; ymm11 = (ymm5 * ymm3) + ymm11
	vfmadd231ps	ymm10, ymm3, ymm3  ; ymm10 = (ymm3 * ymm3) + ymm10
	vsubps	ymm10, ymm10, yword [rsp + 1328]  ; 32-byte Folded Reload
	vmulps	ymm3, ymm11, ymm11
	vfmadd231ps	ymm3, ymm18, ymm10  ; ymm3 = (ymm18 * ymm10) + ymm3
	vmaxps	ymm10, ymm12, ymm3
	vsqrtps	ymm10, ymm10
	vaddps	ymm15, ymm11, ymm10
	vsubps	ymm10, ymm10, ymm11
	korb	k3, k0, k3
	vmulps	ymm11, ymm15, ymm24
	vcmpleps	k1, ymm8, ymm11
	vcmpleps	k1 {k1}, ymm11, ymm6
	korb	k4, k4, k5
	vmulps	ymm10, ymm10, ymm22
	vcmpleps	k5, ymm8, ymm10
	vcmpleps	k0 {k5}, ymm10, ymm6
	vsubps	ymm10, ymm1, yword [rsp + 1264]  ; 32-byte Folded Reload
	vsubps	ymm11, ymm2, yword [rsp + 1232]  ; 32-byte Folded Reload
	vmulps	ymm15, ymm11, ymm28
	vfmadd231ps	ymm15, ymm27, ymm10  ; ymm15 = (ymm27 * ymm10) + ymm15
	vmulps	ymm11, ymm11, ymm11
	vfmadd231ps	ymm11, ymm10, ymm10  ; ymm11 = (ymm10 * ymm10) + ymm11
	vsubps	ymm10, ymm0, yword [rsp + 1200]  ; 32-byte Folded Reload
	vfmadd231ps	ymm15, ymm5, ymm10  ; ymm15 = (ymm5 * ymm10) + ymm15
	vfmadd231ps	ymm11, ymm10, ymm10  ; ymm11 = (ymm10 * ymm10) + ymm11
	vsubps	ymm10, ymm11, yword [rsp + 1168]  ; 32-byte Folded Reload
	vmulps	ymm11, ymm15, ymm15
	vfmadd231ps	ymm11, ymm18, ymm10  ; ymm11 = (ymm18 * ymm10) + ymm11
	vmaxps	ymm10, ymm11, ymm12
	vsqrtps	ymm10, ymm10
	vaddps	ymm18, ymm15, ymm10
	vsubps	ymm10, ymm10, ymm15
	korb	k5, k6, k7
	vmulps	ymm15, ymm18, ymm24
	vcmpleps	k6, ymm8, ymm15
	vcmpleps	k6 {k6}, ymm15, ymm6
	korb	k1, k1, k0
	vmulps	ymm10, ymm10, ymm22
	vcmpleps	k7, ymm8, ymm10
	vcmpleps	k0 {k7}, ymm10, ymm6
	vsubps	ymm6, ymm5, yword [rsp + 1040]  ; 32-byte Folded Reload
	vsubps	ymm8, ymm27, yword [rsp + 1072]  ; 32-byte Folded Reload
	vmovups	ymm12, yword [rsp + 1104]  ; 32-byte Reload
	vfnmadd213ps	ymm12, ymm31, ymm28  ; ymm12 = -(ymm31 * ymm12) + ymm28
	vmulps	ymm10, ymm12, ymm12
	vfmadd231ps	ymm10, ymm8, ymm8  ; ymm10 = (ymm8 * ymm8) + ymm10
	vfmadd231ps	ymm10, ymm6, ymm6  ; ymm10 = (ymm6 * ymm6) + ymm10
	vrsqrtps	ymm15, ymm10
	vmulps	ymm18, ymm15, ymm15
	vfnmadd213ps	ymm18, ymm10, yword [rsp + 976]  ; 32-byte Folded Reload
	vmulps	ymm10, ymm15, yword [rsp + 944]  ; 32-byte Folded Reload
	vxorps	xmm15, xmm15, xmm15
	vpcmpgtd	k2 {k2}, ymm4, ymm15
	vcmpleps	k3 {k3}, ymm15, ymm29
	vcmpleps	k4 {k4}, ymm15, ymm19
	vcmpleps	k5 {k5}, ymm15, ymm20
	vcmpleps	k1 {k1}, ymm15, ymm3
	korb	k6, k6, k0
	vcmpleps	k0 {k6}, ymm15, ymm11
	vmovups	ymm24, yword [rsp + 656]  ; 32-byte Reload
	vmulps	ymm3, ymm30, ymm28
	vfmadd231ps	ymm3, ymm7, ymm27  ; ymm3 = (ymm7 * ymm27) + ymm3
	vfmadd231ps	ymm3, ymm21, ymm5  ; ymm3 = (ymm21 * ymm5) + ymm3
	vmaxps	ymm3, ymm15, ymm3
	vmulps	ymm3, ymm3, yword [rsp + 1136]  ; 32-byte Folded Reload
	vmulps	ymm4, ymm10, ymm18
	vmulps	ymm6, ymm4, ymm6
	vmulps	ymm8, ymm8, ymm4
	vmulps	ymm4, ymm12, ymm4
	vmulps	ymm4, ymm30, ymm4
	vfmadd231ps	ymm4, ymm7, ymm8  ; ymm4 = (ymm7 * ymm8) + ymm4
	vmovups	ymm8, yword [rsp - 48]  ; 32-byte Reload
	korb	k4, k5, k4
	korb	k0, k0, k1
	korb	k0, k0, k4
	korb	k0, k0, k3
	knotb	k0, k0
	vfmadd231ps	ymm4, ymm21, ymm6  ; ymm4 = (ymm21 * ymm6) + ymm4
	vmaxps	ymm4, ymm15, ymm4
	vmulps	ymm4, ymm4, ymm4
	vmulps	ymm4, ymm4, ymm4
	vmulps	ymm4, ymm4, ymm4
	vmulps	ymm4, ymm4, ymm4
	vbroadcastss	ymm6, dword [rel LCPI0_32]  ; ymm6 = [3.49999994E-1,3.49999994E-1,3.49999994E-1,3.49999994E-1,3.49999994E-1,3.49999994E-1,3.49999994E-1,3.49999994E-1]
	vfmadd213ps	ymm6, ymm13, dword [rel LCPI0_33]{1to8}  ; ymm6 = (ymm13 * ymm6) + mem
	vmulps	ymm4, ymm4, ymm4
	vmulps	ymm4, ymm4, ymm6
	vpmovm2d	ymm6, k0
	vpand	ymm3, ymm6, ymm3
	vpand	ymm4, ymm6, ymm4
	kmovw	k1, word [rsp - 118]  ; 2-byte Reload
	vmovdqa32	ymm25 {k1}, ymm15
	vaddps	ymm3, ymm3, yword [rsp + 1008]  ; 32-byte Folded Reload
	vfmadd213ps	ymm26, ymm3, ymm4  ; ymm26 = (ymm3 * ymm26) + ymm4
	vfmadd213ps	ymm9, ymm3, ymm4  ; ymm9 = (ymm3 * ymm9) + ymm4
	vfmadd213ps	ymm14, ymm3, ymm4  ; ymm14 = (ymm3 * ymm14) + ymm4
	cmp	r10d, 3
	mov	r11d, 0
	sbb	r11d, r11d
	not	r11b
	kmovd	k0, r11d
	vcmpleps	k1, ymm13, ymm24
	korb	k0, k1, k0
	kandb	k0, k0, k2
	vpmovm2d	ymm4, k0
	vpxord	ymm3 {k2}{z}, ymm4, dword [rel LCPI0_36]{1to8}
	vpandd	ymm4, ymm25, ymm4
	vfmadd231ps	ymm16, ymm4, ymm26  ; ymm16 = (ymm4 * ymm26) + ymm16
	vfmadd231ps	ymm17, ymm4, ymm9  ; ymm17 = (ymm4 * ymm9) + ymm17
	vfmadd231ps	ymm23, ymm14, ymm4  ; ymm23 = (ymm14 * ymm4) + ymm23
	vsubps	ymm4, ymm8, ymm13
	vpandd	ymm5, ymm3, ymm25
	vmulps	ymm26, ymm26, ymm4
	vfmadd213ps	ymm26, ymm5, ymm16  ; ymm26 = (ymm5 * ymm26) + ymm16
	vmulps	ymm20, ymm9, ymm4
	vmovups	ymm9, yword [rsp - 80]  ; 32-byte Reload
	vfmadd213ps	ymm20, ymm5, ymm17  ; ymm20 = (ymm5 * ymm20) + ymm17
	vmulps	ymm29, ymm14, ymm4
	vfmadd213ps	ymm29, ymm5, ymm23  ; ymm29 = (ymm5 * ymm29) + ymm23
	vmulps	ymm4, ymm30, ymm31
	vfmadd231ps	ymm4, ymm7, yword [rsp - 112]  ; 32-byte Folded Reload
	vfmadd231ps	ymm4, ymm9, ymm21  ; ymm4 = (ymm9 * ymm21) + ymm4
	vmovups	ymm6, yword [rsp - 16]  ; 32-byte Reload
	vmulps	ymm5, ymm21, ymm6
	vfmadd231ps	ymm9, ymm4, ymm5  ; ymm9 = (ymm4 * ymm5) + ymm9
	vmulps	ymm5, ymm7, ymm6
	vmovups	ymm7, yword [rsp - 112]  ; 32-byte Reload
	vfmadd231ps	ymm7, ymm4, ymm5  ; ymm7 = (ymm4 * ymm5) + ymm7
	vmulps	ymm5, ymm30, ymm6
	vfmadd231ps	ymm31, ymm4, ymm5  ; ymm31 = (ymm4 * ymm5) + ymm31
	vblendvps	ymm3, ymm15, ymm13, ymm3
	vmulps	ymm25, ymm3, ymm25
	inc	r10d
	vmovaps	ymm21, ymm2
	cmp	r10d, 4
	jne	LBB0_4
	jmp	LBB0_6
LBB0_8:
	add	rsp, 1816
LBB0_9:
	vzeroupper
	ret


section .note.GNU-stack noalloc noexec nowrite progbits
