# CPURender — optimized packet tracer

Software ray tracer from `cpurender_grok2.c`, with the inner loop moved to
an 8-wide AVX2/AVX-512 kernel.

Rewriting X11, pthreads, and keymap polling in NASM would not make frames
faster. Those paths are idle while workers trace. The kernel that is hot
is `render_scanlines_avx2` in `render_avx2.asm`.

## Build

```
# headless bench (no X11 needed)
clang -O3 -ffast-math -march=native -pthread \
    cpurender.c render_ref.c render_avx2.c -lm -pthread -o CPURender_bench

# NASM kernel instead of the C SIMD file
nasm -f elf64 render_avx2.asm -o render_avx2_nasm.o
clang -O3 -ffast-math -march=native -pthread \
    cpurender.c render_ref.c render_avx2_nasm.o -lm -pthread -o CPURender_nasm

# interactive (needs X11 + MIT-SHM)
clang -O3 -ffast-math -march=native -pthread -DCPURENDER_HAS_X11 \
    cpurender.c render_ref.c render_avx2.c -lm -pthread -lX11 -lXext -o CPURender
```

Or `make`, `make nasm`, `make x11`.

## Run

```
./CPURender_nasm --bench 8          # time N frames, AVX2 kernel
./CPURender_nasm --ref --bench 8    # scalar reference
./CPURender_nasm --bench 2 --dump   # also write frame_avx2.ppm
./CPURender [thread_count]          # interactive, same keys as original
```

Keys (X11 build): WASD/arrows move, Q/E down/up, J/L yaw, I/K pitch,
+/- orbit speed, space pause, r reset, Esc quit.

## What changed vs the original C

| | original | this |
|---|---|---|
| rays | 1 scalar ray / pixel | 8-wide packet (`ymm`) |
| ISA | plain SSE-ish C | AVX2 + AVX-512 masks/broadcasts |
| `powf(nh,32)` | libm | 5 multiplies |
| normalize | `sqrtf` + div | `vrsqrtps` + Newton |
| pixels | byte stores | packed BGRA `vmovdqu` |
| threads | pixel chunks | whole scanlines (better cache) |

Same scene, same lighting: 5 spheres, y-plane checker, sky + sun disc,
hard shadows, 3 reflection bounces, 1280×720.

On this box (single thread, 1280×720):

- scalar ref: ~23 fps (43 ms)
- AVX2/AVX-512 kernel: ~47 fps (21 ms)

Two worker threads (X11 build, default `nproc`) scale almost linearly
until the window blit.

## Files

- `render_avx2.asm` — NASM kernel (`render_scanlines_avx2`)
- `render_avx2.c`    — same algorithm in intrinsics (easier to read/edit)
- `render_ref.c`     — scalar reference matching the original shade model
- `cpurender.c`      — camera, animation, X11/headless host
- `render.h`         — shared layout (`RenderCam`, `SphereSOA`)
