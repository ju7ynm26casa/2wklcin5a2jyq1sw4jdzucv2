#include "render.h"
#include <math.h>
#include <string.h>

typedef struct { float x, y, z; } v3;

static inline v3 V(float x, float y, float z) { v3 r = {x, y, z}; return r; }
static inline v3 add(v3 a, v3 b) { return V(a.x+b.x, a.y+b.y, a.z+b.z); }
static inline v3 sub(v3 a, v3 b) { return V(a.x-b.x, a.y-b.y, a.z-b.z); }
static inline v3 mul(v3 a, float s) { return V(a.x*s, a.y*s, a.z*s); }
static inline float dot(v3 a, v3 b) { return a.x*b.x + a.y*b.y + a.z*b.z; }
static inline float mag2(v3 a) { return dot(a, a); }
static inline v3 norm(v3 a)
{
    float l2 = mag2(a);
    if (l2 <= 0.f) return a;
    float inv = 1.f / sqrtf(l2);
    return mul(a, inv);
}

static inline unsigned char to_byte(float c)
{
    if (c < 0.f) c = 0.f;
    if (c > 1.f) c = 1.f;
    return (unsigned char)(c * 255.f + 0.5f);
}

static void sky(v3 dir, float ldx, float ldy, float ldz, float *r, float *g, float *b)
{
    dir = norm(dir);
    float t = 0.5f * (dir.y + 1.f);
    *r = 0.72f * (1.f - t) + 0.18f * t;
    *g = 0.82f * (1.f - t) + 0.32f * t;
    *b = 0.95f * (1.f - t) + 0.72f * t;
    float sun = dir.x * ldx + dir.y * ldy + dir.z * ldz;
    if (sun > 0.997f) {
        float k = (sun - 0.997f) / 0.003f;
        *r += k * 0.8f;
        *g += k * 0.6f;
        *b += k * 0.2f;
    }
}

static void checker(float x, float z, float *r, float *g, float *b)
{
    int cx = (int)floorf(x * 0.8f);
    int cz = (int)floorf(z * 0.8f);
    if ((cx + cz) & 1) { *r = 0.82f; *g = 0.82f; *b = 0.80f; }
    else               { *r = 0.18f; *g = 0.18f; *b = 0.20f; }
}

static int hit_sphere(v3 o, v3 d, float cx, float cy, float cz, float r2,
                      float tmin, float tmax, float *t_out)
{
    v3 Q = V(o.x - cx, o.y - cy, o.z - cz);
    float a = mag2(d);
    float b = dot(d, Q);
    float c = mag2(Q) - r2;
    float disc = b * b - a * c;
    if (disc < 0.f || a <= 0.f) return 0;
    float sd = sqrtf(disc);
    float t = (-b - sd) / a;
    if (t < tmin || t > tmax) {
        t = (-b + sd) / a;
        if (t < tmin || t > tmax) return 0;
    }
    *t_out = t;
    return 1;
}

typedef struct {
    int kind; /* 0 none 1 sphere 2 plane */
    int idx;
    float t;
    v3 p, n;
    float cr, cg, cb, refl;
} Hit;

static Hit closest(v3 o, v3 d, const SphereSOA *s)
{
    Hit h;
    memset(&h, 0, sizeof(h));
    h.t = RT_MAX_DIST;

    for (int i = 0; i < RT_NUM_SPHERES; i++) {
        float t;
        if (hit_sphere(o, d, s->cx[i], s->cy[i], s->cz[i], s->r2[i], RT_HIT_EPS, h.t, &t)) {
            h.kind = 1;
            h.t = t;
            h.idx = i;
        }
    }
    if (fabsf(d.y) >= 1e-8f) {
        float t = (RT_PLANE_Y - o.y) / d.y;
        if (t >= RT_HIT_EPS && t <= h.t) {
            h.kind = 2;
            h.t = t;
            h.idx = -1;
        }
    }
    if (!h.kind) return h;
    h.p = add(o, mul(d, h.t));
    if (h.kind == 1) {
        h.n = norm(V(h.p.x - s->cx[h.idx], h.p.y - s->cy[h.idx], h.p.z - s->cz[h.idx]));
        h.cr = s->cr[h.idx]; h.cg = s->cg[h.idx]; h.cb = s->cb[h.idx];
        h.refl = s->refl[h.idx];
    } else {
        h.n = V(0.f, 1.f, 0.f);
        checker(h.p.x, h.p.z, &h.cr, &h.cg, &h.cb);
        h.refl = 0.12f;
    }
    return h;
}

static int shadowed(v3 p, v3 n, v3 L, const SphereSOA *s)
{
    v3 o = add(p, mul(n, RT_HIT_EPS * 4.f));
    for (int i = 0; i < RT_NUM_SPHERES; i++) {
        float t;
        if (hit_sphere(o, L, s->cx[i], s->cy[i], s->cz[i], s->r2[i], RT_HIT_EPS, RT_MAX_DIST, &t))
            return 1;
    }
    return 0;
}

static void shade(v3 o, v3 d, int bounce, const SphereSOA *s,
                  float ldx, float ldy, float ldz,
                  float *or, float *og, float *ob)
{
    Hit h = closest(o, d, s);
    if (!h.kind) {
        sky(d, ldx, ldy, ldz, or, og, ob);
        return;
    }
    v3 n = h.n;
    if (dot(n, d) > 0.f) n = mul(n, -1.f);

    v3 L = V(ldx, ldy, ldz);
    float ndl = dot(n, L);
    if (ndl < 0.f) ndl = 0.f;
    int sh = shadowed(h.p, n, L, s);
    float ambient = 0.18f;
    float diffuse = sh ? 0.f : 0.72f * ndl;

    float spec = 0.f;
    if (!sh) {
        v3 halfv = norm(sub(L, norm(d)));
        float nh = dot(n, halfv);
        if (nh < 0.f) nh = 0.f;
        float x = nh, x2 = x*x, x4 = x2*x2, x8 = x4*x4, x16 = x8*x8, x32 = x16*x16;
        spec = x32 * 0.35f * (0.4f + h.refl);
    }
    float cr = h.cr * (ambient + diffuse) + spec;
    float cg = h.cg * (ambient + diffuse) + spec;
    float cb = h.cb * (ambient + diffuse) + spec;

    if (bounce < RT_MAX_BOUNCES && h.refl > 0.f) {
        float ang = dot(d, n);
        v3 rd = V(d.x - 2.f * n.x * ang, d.y - 2.f * n.y * ang, d.z - 2.f * n.z * ang);
        float rr, rg, rb;
        shade(add(h.p, mul(n, RT_HIT_EPS * 4.f)), rd, bounce + 1, s, ldx, ldy, ldz, &rr, &rg, &rb);
        float k = h.refl;
        cr = cr * (1.f - k) + rr * k;
        cg = cg * (1.f - k) + rg * k;
        cb = cb * (1.f - k) + rb * k;
    }
    *or = cr; *og = cg; *ob = cb;
}

void render_scanlines_ref(uint8_t *fb, int pitch, int y0, int y1,
                          const RenderCam *cam, const SphereSOA *sph)
{
    v3 pos = V(cam->posx, cam->posy, cam->posz);
    v3 fwd = V(cam->fwdx, cam->fwdy, cam->fwdz);
    v3 rt  = V(cam->rtx,  cam->rty,  cam->rtz);
    v3 up  = V(cam->upx,  cam->upy,  cam->upz);

    for (int py = y0; py < y1; py++) {
        uint8_t *row = fb + (size_t)py * (size_t)pitch;
        float ny = ((float)py + 0.5f) * cam->inv_h;
        float v  = (1.f - 2.f * ny) * cam->fov_scale;
        for (int px = 0; px < RT_WIDTH; px++) {
            float nx = ((float)px + 0.5f) * cam->inv_w;
            float u  = (2.f * nx - 1.f) * cam->aspect * cam->fov_scale;
            v3 dir = add(fwd, add(mul(rt, u), mul(up, v)));
            float r, g, b;
            shade(pos, dir, 0, sph, cam->ldx, cam->ldy, cam->ldz, &r, &g, &b);
            row[px * 4 + 0] = to_byte(b);
            row[px * 4 + 1] = to_byte(g);
            row[px * 4 + 2] = to_byte(r);
            row[px * 4 + 3] = 0;
        }
    }
}
