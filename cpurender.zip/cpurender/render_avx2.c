#include "render.h"
#include <immintrin.h>
#include <math.h>

/* 8-wide AVX2 packet tracer. Same lighting model as the scalar reference. */

static inline __m256 rsqrt_nr(__m256 x)
{
    __m256 y = _mm256_rsqrt_ps(x);
    __m256 half = _mm256_set1_ps(0.5f);
    __m256 three = _mm256_set1_ps(3.0f);
    /* y * (1.5 - 0.5 x y y)  ==  y * 0.5 * (3 - x y y) */
    __m256 yy = _mm256_mul_ps(y, y);
    return _mm256_mul_ps(_mm256_mul_ps(y, half), _mm256_fnmadd_ps(x, yy, three));
}

static inline __m256 clamp01(__m256 x)
{
    x = _mm256_max_ps(x, _mm256_setzero_ps());
    x = _mm256_min_ps(x, _mm256_set1_ps(1.f));
    return x;
}

static inline void normalize3(__m256 *x, __m256 *y, __m256 *z)
{
    __m256 l2 = _mm256_fmadd_ps(*x, *x, _mm256_fmadd_ps(*y, *y, _mm256_mul_ps(*z, *z)));
    __m256 inv = rsqrt_nr(l2);
    *x = _mm256_mul_ps(*x, inv);
    *y = _mm256_mul_ps(*y, inv);
    *z = _mm256_mul_ps(*z, inv);
}

static inline __m256 dot3(__m256 ax, __m256 ay, __m256 az,
                          __m256 bx, __m256 by, __m256 bz)
{
    return _mm256_fmadd_ps(ax, bx, _mm256_fmadd_ps(ay, by, _mm256_mul_ps(az, bz)));
}

/* Closest hit for 8 rays. kind: 0 miss, 1 sphere, 2 plane. */
static void closest8(const SphereSOA *s,
                     __m256 ox, __m256 oy, __m256 oz,
                     __m256 dx, __m256 dy, __m256 dz,
                     __m256 *t_out, __m256i *kind, __m256i *idx)
{
    const __m256 eps = _mm256_set1_ps(RT_HIT_EPS);
    const __m256 tmax0 = _mm256_set1_ps(RT_MAX_DIST);
    __m256 tbest = tmax0;
    __m256i kindv = _mm256_setzero_si256();
    __m256i idxv  = _mm256_set1_epi32(-1);

    __m256 a = dot3(dx, dy, dz, dx, dy, dz);
    __m256 inv_a = _mm256_div_ps(_mm256_set1_ps(1.f), a);
    __m256 a_ok = _mm256_cmp_ps(a, _mm256_set1_ps(1e-20f), _CMP_GT_OQ);

    for (int i = 0; i < RT_NUM_SPHERES; i++) {
        __m256 qx = _mm256_sub_ps(ox, _mm256_set1_ps(s->cx[i]));
        __m256 qy = _mm256_sub_ps(oy, _mm256_set1_ps(s->cy[i]));
        __m256 qz = _mm256_sub_ps(oz, _mm256_set1_ps(s->cz[i]));
        __m256 b  = dot3(dx, dy, dz, qx, qy, qz);
        __m256 c  = _mm256_sub_ps(dot3(qx, qy, qz, qx, qy, qz), _mm256_set1_ps(s->r2[i]));
        __m256 disc = _mm256_fnmadd_ps(a, c, _mm256_mul_ps(b, b));
        __m256 dmsk = _mm256_and_ps(a_ok, _mm256_cmp_ps(disc, _mm256_setzero_ps(), _CMP_GE_OQ));
        __m256 sd = _mm256_sqrt_ps(_mm256_max_ps(disc, _mm256_setzero_ps()));
        __m256 t1 = _mm256_mul_ps(_mm256_sub_ps(_mm256_sub_ps(_mm256_setzero_ps(), b), sd), inv_a);
        __m256 t2 = _mm256_mul_ps(_mm256_sub_ps(sd, b), inv_a);
        __m256 v1 = _mm256_and_ps(dmsk,
                     _mm256_and_ps(_mm256_cmp_ps(t1, eps, _CMP_GE_OQ),
                                   _mm256_cmp_ps(t1, tbest, _CMP_LE_OQ)));
        __m256 t  = t1;
        __m256 v  = v1;
        __m256 v2 = _mm256_and_ps(dmsk,
                     _mm256_and_ps(_mm256_cmp_ps(t2, eps, _CMP_GE_OQ),
                                   _mm256_cmp_ps(t2, tbest, _CMP_LE_OQ)));
        v2 = _mm256_andnot_ps(v1, v2);
        t = _mm256_blendv_ps(t, t2, v2);
        v = _mm256_or_ps(v, v2);
        tbest = _mm256_blendv_ps(tbest, t, v);
        kindv = _mm256_blendv_epi8(kindv, _mm256_set1_epi32(1), _mm256_castps_si256(v));
        idxv  = _mm256_blendv_epi8(idxv,  _mm256_set1_epi32(i), _mm256_castps_si256(v));
    }

    __m256 dyabs = _mm256_andnot_ps(_mm256_set1_ps(-0.f), dy);
    __m256 pok = _mm256_cmp_ps(dyabs, _mm256_set1_ps(1e-8f), _CMP_GE_OQ);
    __m256 tp = _mm256_div_ps(_mm256_sub_ps(_mm256_set1_ps(RT_PLANE_Y), oy), dy);
    __m256 pv = _mm256_and_ps(pok,
                 _mm256_and_ps(_mm256_cmp_ps(tp, eps, _CMP_GE_OQ),
                               _mm256_cmp_ps(tp, tbest, _CMP_LE_OQ)));
    tbest = _mm256_blendv_ps(tbest, tp, pv);
    kindv = _mm256_blendv_epi8(kindv, _mm256_set1_epi32(2), _mm256_castps_si256(pv));
    idxv  = _mm256_blendv_epi8(idxv,  _mm256_set1_epi32(-1), _mm256_castps_si256(pv));

    *t_out = tbest;
    *kind = kindv;
    *idx = idxv;
}

static __m256 shadow8(const SphereSOA *s,
                      __m256 px, __m256 py, __m256 pz,
                      __m256 nx, __m256 ny, __m256 nz,
                      __m256 lx, __m256 ly, __m256 lz)
{
    const __m256 eps = _mm256_set1_ps(RT_HIT_EPS);
    __m256 ox = _mm256_fmadd_ps(nx, _mm256_set1_ps(RT_HIT_EPS * 4.f), px);
    __m256 oy = _mm256_fmadd_ps(ny, _mm256_set1_ps(RT_HIT_EPS * 4.f), py);
    __m256 oz = _mm256_fmadd_ps(nz, _mm256_set1_ps(RT_HIT_EPS * 4.f), pz);
    __m256 a = dot3(lx, ly, lz, lx, ly, lz);
    __m256 inv_a = _mm256_div_ps(_mm256_set1_ps(1.f), a);
    __m256 hit = _mm256_setzero_ps();

    for (int i = 0; i < RT_NUM_SPHERES; i++) {
        __m256 qx = _mm256_sub_ps(ox, _mm256_set1_ps(s->cx[i]));
        __m256 qy = _mm256_sub_ps(oy, _mm256_set1_ps(s->cy[i]));
        __m256 qz = _mm256_sub_ps(oz, _mm256_set1_ps(s->cz[i]));
        __m256 b  = dot3(lx, ly, lz, qx, qy, qz);
        __m256 c  = _mm256_sub_ps(dot3(qx, qy, qz, qx, qy, qz), _mm256_set1_ps(s->r2[i]));
        __m256 disc = _mm256_fnmadd_ps(a, c, _mm256_mul_ps(b, b));
        __m256 dmsk = _mm256_cmp_ps(disc, _mm256_setzero_ps(), _CMP_GE_OQ);
        __m256 sd = _mm256_sqrt_ps(_mm256_max_ps(disc, _mm256_setzero_ps()));
        __m256 t1 = _mm256_mul_ps(_mm256_sub_ps(_mm256_sub_ps(_mm256_setzero_ps(), b), sd), inv_a);
        __m256 t2 = _mm256_mul_ps(_mm256_sub_ps(sd, b), inv_a);
        __m256 v1 = _mm256_and_ps(dmsk,
                     _mm256_and_ps(_mm256_cmp_ps(t1, eps, _CMP_GE_OQ),
                                   _mm256_cmp_ps(t1, _mm256_set1_ps(RT_MAX_DIST), _CMP_LE_OQ)));
        __m256 v2 = _mm256_and_ps(dmsk,
                     _mm256_and_ps(_mm256_cmp_ps(t2, eps, _CMP_GE_OQ),
                                   _mm256_cmp_ps(t2, _mm256_set1_ps(RT_MAX_DIST), _CMP_LE_OQ)));
        hit = _mm256_or_ps(hit, _mm256_or_ps(v1, v2));
    }
    return hit;
}

static void sky8(__m256 dx, __m256 dy, __m256 dz,
                 __m256 lx, __m256 ly, __m256 lz,
                 __m256 *r, __m256 *g, __m256 *b)
{
    normalize3(&dx, &dy, &dz);
    __m256 t = _mm256_mul_ps(_mm256_set1_ps(0.5f), _mm256_add_ps(dy, _mm256_set1_ps(1.f)));
    __m256 omt = _mm256_sub_ps(_mm256_set1_ps(1.f), t);
    *r = _mm256_fmadd_ps(_mm256_set1_ps(0.72f), omt, _mm256_mul_ps(_mm256_set1_ps(0.18f), t));
    *g = _mm256_fmadd_ps(_mm256_set1_ps(0.82f), omt, _mm256_mul_ps(_mm256_set1_ps(0.32f), t));
    *b = _mm256_fmadd_ps(_mm256_set1_ps(0.95f), omt, _mm256_mul_ps(_mm256_set1_ps(0.72f), t));
    __m256 sun = dot3(dx, dy, dz, lx, ly, lz);
    __m256 m = _mm256_cmp_ps(sun, _mm256_set1_ps(0.997f), _CMP_GT_OQ);
    __m256 k = _mm256_mul_ps(_mm256_sub_ps(sun, _mm256_set1_ps(0.997f)), _mm256_set1_ps(1.f / 0.003f));
    *r = _mm256_fmadd_ps(_mm256_and_ps(k, m), _mm256_set1_ps(0.8f), *r);
    *g = _mm256_fmadd_ps(_mm256_and_ps(k, m), _mm256_set1_ps(0.6f), *g);
    *b = _mm256_fmadd_ps(_mm256_and_ps(k, m), _mm256_set1_ps(0.2f), *b);
}

static void checker8(__m256 x, __m256 z, __m256 *r, __m256 *g, __m256 *b)
{
    /* floor(x*0.8) + floor(z*0.8) odd? */
    __m256 xf = _mm256_mul_ps(x, _mm256_set1_ps(0.8f));
    __m256 zf = _mm256_mul_ps(z, _mm256_set1_ps(0.8f));
    __m256i xi = _mm256_cvttps_epi32(_mm256_floor_ps(xf));
    __m256i zi = _mm256_cvttps_epi32(_mm256_floor_ps(zf));
    __m256i on = _mm256_and_si256(_mm256_add_epi32(xi, zi), _mm256_set1_epi32(1));
    __m256 m = _mm256_castsi256_ps(_mm256_cmpeq_epi32(on, _mm256_set1_epi32(1)));
    *r = _mm256_blendv_ps(_mm256_set1_ps(0.18f), _mm256_set1_ps(0.82f), m);
    *g = _mm256_blendv_ps(_mm256_set1_ps(0.18f), _mm256_set1_ps(0.82f), m);
    *b = _mm256_blendv_ps(_mm256_set1_ps(0.20f), _mm256_set1_ps(0.80f), m);
}

static void gather_sph(const SphereSOA *s, __m256i idx,
                       __m256 *cx, __m256 *cy, __m256 *cz,
                       __m256 *cr, __m256 *cg, __m256 *cb, __m256 *refl)
{
    /* idx is 0..4 for spheres. Safe because we only use it when kind==1. */
    *cx = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cx), idx);
    *cy = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cy), idx);
    *cz = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cz), idx);
    *cr = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cr), idx);
    *cg = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cg), idx);
    *cb = _mm256_permutevar8x32_ps(_mm256_load_ps(s->cb), idx);
    *refl= _mm256_permutevar8x32_ps(_mm256_load_ps(s->refl), idx);
}

static void shade_packet(const SphereSOA *s,
                         __m256 ox, __m256 oy, __m256 oz,
                         __m256 dx, __m256 dy, __m256 dz,
                         __m256 lx, __m256 ly, __m256 lz,
                         __m256 *or, __m256 *og, __m256 *ob)
{
    __m256 acc_r = _mm256_setzero_ps();
    __m256 acc_g = _mm256_setzero_ps();
    __m256 acc_b = _mm256_setzero_ps();
    __m256 w = _mm256_set1_ps(1.f); /* throughput */

    for (int bounce = 0; bounce <= RT_MAX_BOUNCES; bounce++) {
        __m256 alive = _mm256_cmp_ps(w, _mm256_set1_ps(1e-6f), _CMP_GT_OQ);
        if (_mm256_movemask_ps(alive) == 0) break;

        __m256 t;
        __m256i kind, idx;
        closest8(s, ox, oy, oz, dx, dy, dz, &t, &kind, &idx);

        __m256 is_hit  = _mm256_castsi256_ps(_mm256_cmpgt_epi32(kind, _mm256_setzero_si256()));
        __m256 is_miss = _mm256_andnot_ps(is_hit, alive);
        __m256 is_sph  = _mm256_castsi256_ps(_mm256_cmpeq_epi32(kind, _mm256_set1_epi32(1)));
        __m256 is_pln  = _mm256_castsi256_ps(_mm256_cmpeq_epi32(kind, _mm256_set1_epi32(2)));
        is_hit = _mm256_and_ps(is_hit, alive);

        __m256 sr, sg, sb;
        sky8(dx, dy, dz, lx, ly, lz, &sr, &sg, &sb);
        acc_r = _mm256_fmadd_ps(_mm256_and_ps(w, is_miss), sr, acc_r);
        acc_g = _mm256_fmadd_ps(_mm256_and_ps(w, is_miss), sg, acc_g);
        acc_b = _mm256_fmadd_ps(_mm256_and_ps(w, is_miss), sb, acc_b);
        w = _mm256_andnot_ps(is_miss, w);

        __m256 px = _mm256_fmadd_ps(dx, t, ox);
        __m256 py = _mm256_fmadd_ps(dy, t, oy);
        __m256 pz = _mm256_fmadd_ps(dz, t, oz);

        __m256 scx, scy, scz, cr, cg, cb, refl;
        gather_sph(s, idx, &scx, &scy, &scz, &cr, &cg, &cb, &refl);

        __m256 nx = _mm256_sub_ps(px, scx);
        __m256 ny = _mm256_sub_ps(py, scy);
        __m256 nz = _mm256_sub_ps(pz, scz);
        normalize3(&nx, &ny, &nz);
        /* plane normal */
        nx = _mm256_blendv_ps(_mm256_setzero_ps(), nx, is_sph);
        ny = _mm256_blendv_ps(_mm256_set1_ps(1.f), ny, is_sph);
        nz = _mm256_blendv_ps(_mm256_setzero_ps(), nz, is_sph);

        __m256 pr, pg, pb;
        checker8(px, pz, &pr, &pg, &pb);
        cr = _mm256_blendv_ps(pr, cr, is_sph);
        cg = _mm256_blendv_ps(pg, cg, is_sph);
        cb = _mm256_blendv_ps(pb, cb, is_sph);
        refl = _mm256_blendv_ps(_mm256_set1_ps(0.12f), refl, is_sph);

        /* flip normal if pointing same way as ray */
        __m256 nd = dot3(nx, ny, nz, dx, dy, dz);
        __m256 flip = _mm256_cmp_ps(nd, _mm256_setzero_ps(), _CMP_GT_OQ);
        nx = _mm256_blendv_ps(nx, _mm256_xor_ps(nx, _mm256_set1_ps(-0.f)), flip);
        ny = _mm256_blendv_ps(ny, _mm256_xor_ps(ny, _mm256_set1_ps(-0.f)), flip);
        nz = _mm256_blendv_ps(nz, _mm256_xor_ps(nz, _mm256_set1_ps(-0.f)), flip);

        __m256 ndl = _mm256_max_ps(dot3(nx, ny, nz, lx, ly, lz), _mm256_setzero_ps());
        __m256 sh  = shadow8(s, px, py, pz, nx, ny, nz, lx, ly, lz);
        __m256 amb = _mm256_set1_ps(0.18f);
        __m256 diff = _mm256_andnot_ps(sh, _mm256_mul_ps(_mm256_set1_ps(0.72f), ndl));

        __m256 ndx = dx, ndy = dy, ndz = dz;
        normalize3(&ndx, &ndy, &ndz);
        __m256 hx = _mm256_sub_ps(lx, ndx);
        __m256 hy = _mm256_sub_ps(ly, ndy);
        __m256 hz = _mm256_sub_ps(lz, ndz);
        normalize3(&hx, &hy, &hz);
        __m256 nh = _mm256_max_ps(dot3(nx, ny, nz, hx, hy, hz), _mm256_setzero_ps());
        __m256 x2 = _mm256_mul_ps(nh, nh);
        __m256 x4 = _mm256_mul_ps(x2, x2);
        __m256 x8 = _mm256_mul_ps(x4, x4);
        __m256 x16= _mm256_mul_ps(x8, x8);
        __m256 x32= _mm256_mul_ps(x16, x16);
        __m256 spec = _mm256_mul_ps(x32, _mm256_mul_ps(_mm256_set1_ps(0.35f),
                              _mm256_add_ps(_mm256_set1_ps(0.4f), refl)));
        spec = _mm256_andnot_ps(sh, spec);

        __m256 light = _mm256_add_ps(amb, diff);
        __m256 lr = _mm256_fmadd_ps(cr, light, spec);
        __m256 lg = _mm256_fmadd_ps(cg, light, spec);
        __m256 lb = _mm256_fmadd_ps(cb, light, spec);

        __m256 last = _mm256_or_ps(
            _mm256_cmp_ps(_mm256_set1_ps((float)bounce), _mm256_set1_ps((float)RT_MAX_BOUNCES), _CMP_GE_OQ),
            _mm256_cmp_ps(refl, _mm256_set1_ps(1e-6f), _CMP_LE_OQ));
        last = _mm256_and_ps(last, is_hit);
        __m256 bounce_more = _mm256_andnot_ps(last, is_hit);

        acc_r = _mm256_fmadd_ps(_mm256_and_ps(w, last), lr, acc_r);
        acc_g = _mm256_fmadd_ps(_mm256_and_ps(w, last), lg, acc_g);
        acc_b = _mm256_fmadd_ps(_mm256_and_ps(w, last), lb, acc_b);

        __m256 omk = _mm256_sub_ps(_mm256_set1_ps(1.f), refl);
        acc_r = _mm256_fmadd_ps(_mm256_and_ps(w, bounce_more), _mm256_mul_ps(lr, omk), acc_r);
        acc_g = _mm256_fmadd_ps(_mm256_and_ps(w, bounce_more), _mm256_mul_ps(lg, omk), acc_g);
        acc_b = _mm256_fmadd_ps(_mm256_and_ps(w, bounce_more), _mm256_mul_ps(lb, omk), acc_b);

        w = _mm256_mul_ps(w, _mm256_blendv_ps(_mm256_setzero_ps(), refl, bounce_more));

        /* spawn reflected ray */
        __m256 ang = dot3(dx, dy, dz, nx, ny, nz);
        __m256 two = _mm256_set1_ps(2.f);
        dx = _mm256_fnmadd_ps(_mm256_mul_ps(two, nx), ang, dx);
        dy = _mm256_fnmadd_ps(_mm256_mul_ps(two, ny), ang, dy);
        dz = _mm256_fnmadd_ps(_mm256_mul_ps(two, nz), ang, dz);
        __m256 e = _mm256_set1_ps(RT_HIT_EPS * 4.f);
        ox = _mm256_fmadd_ps(nx, e, px);
        oy = _mm256_fmadd_ps(ny, e, py);
        oz = _mm256_fmadd_ps(nz, e, pz);
    }

    *or = acc_r; *og = acc_g; *ob = acc_b;
}

void render_scanlines_avx2(uint8_t *fb, int pitch, int y0, int y1,
                           const RenderCam *cam, const SphereSOA *sph)
{
    const __m256 posx = _mm256_set1_ps(cam->posx);
    const __m256 posy = _mm256_set1_ps(cam->posy);
    const __m256 posz = _mm256_set1_ps(cam->posz);
    const __m256 fwdx = _mm256_set1_ps(cam->fwdx);
    const __m256 fwdy = _mm256_set1_ps(cam->fwdy);
    const __m256 fwdz = _mm256_set1_ps(cam->fwdz);
    const __m256 rtx  = _mm256_set1_ps(cam->rtx);
    const __m256 rty  = _mm256_set1_ps(cam->rty);
    const __m256 rtz  = _mm256_set1_ps(cam->rtz);
    const __m256 upx  = _mm256_set1_ps(cam->upx);
    const __m256 upy  = _mm256_set1_ps(cam->upy);
    const __m256 upz  = _mm256_set1_ps(cam->upz);
    const __m256 lx   = _mm256_set1_ps(cam->ldx);
    const __m256 ly   = _mm256_set1_ps(cam->ldy);
    const __m256 lz   = _mm256_set1_ps(cam->ldz);
    const __m256 aspect = _mm256_set1_ps(cam->aspect * cam->fov_scale);
    const __m256 fov    = _mm256_set1_ps(cam->fov_scale);
    const __m256 invw   = _mm256_set1_ps(cam->inv_w);
    const __m256 invh   = _mm256_set1_ps(cam->inv_h);
    const __m256 lane   = _mm256_setr_ps(0.f, 1.f, 2.f, 3.f, 4.f, 5.f, 6.f, 7.f);
    const __m256 half   = _mm256_set1_ps(0.5f);
    const __m256 one    = _mm256_set1_ps(1.f);
    const __m256 two    = _mm256_set1_ps(2.f);
    const __m256 scale  = _mm256_set1_ps(255.f);

    for (int py = y0; py < y1; py++) {
        uint8_t *row = fb + (size_t)py * (size_t)pitch;
        __m256 ny = _mm256_mul_ps(_mm256_add_ps(_mm256_set1_ps((float)py), half), invh);
        __m256 v  = _mm256_mul_ps(_mm256_fnmadd_ps(two, ny, one), fov);
        __m256 diry0 = _mm256_fmadd_ps(upy, v, fwdy);
        __m256 dirz_up = _mm256_mul_ps(upz, v);
        __m256 dirx_up = _mm256_mul_ps(upx, v);

        for (int px = 0; px < RT_WIDTH; px += 8) {
            __m256 pxs = _mm256_add_ps(_mm256_set1_ps((float)px), lane);
            __m256 nx = _mm256_mul_ps(_mm256_add_ps(pxs, half), invw);
            __m256 u  = _mm256_mul_ps(_mm256_fmsub_ps(two, nx, one), aspect);
            __m256 dx = _mm256_fmadd_ps(rtx, u, _mm256_add_ps(fwdx, dirx_up));
            __m256 dy = _mm256_fmadd_ps(rty, u, diry0);
            __m256 dz = _mm256_fmadd_ps(rtz, u, _mm256_add_ps(fwdz, dirz_up));

            __m256 r, g, b;
            shade_packet(sph, posx, posy, posz, dx, dy, dz, lx, ly, lz, &r, &g, &b);

            r = _mm256_mul_ps(clamp01(r), scale);
            g = _mm256_mul_ps(clamp01(g), scale);
            b = _mm256_mul_ps(clamp01(b), scale);
            __m256i ri = _mm256_cvtps_epi32(r);
            __m256i gi = _mm256_cvtps_epi32(g);
            __m256i bi = _mm256_cvtps_epi32(b);

            /* pack BGRA bytes. */
            __m256i bgra0 = bi;
            bgra0 = _mm256_or_si256(bgra0, _mm256_slli_epi32(gi, 8));
            bgra0 = _mm256_or_si256(bgra0, _mm256_slli_epi32(ri, 16));
            _mm256_storeu_si256((__m256i *)(row + px * 4), bgra0);
        }
    }
    _mm256_zeroupper();
}
