#define _GNU_SOURCE
#include "render.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#ifdef CPURENDER_HAS_X11
#include <sys/shm.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <X11/extensions/XShm.h>
#endif

static size_t NUM_THREADS = 1;
static volatile int quit_flag = 0;
static pthread_barrier_t frame_start;
static pthread_barrier_t frame_done;

static uint8_t *framebuffer;
static int fb_pitch = RT_WIDTH * 4;
static RenderCam cam;
static SphereSOA sph __attribute__((aligned(32)));

static float orbit_speed = 0.012f;
static int orbit_paused = 0;
static int use_avx2 = 1;

typedef void (*scan_fn)(uint8_t *, int, int, int, const RenderCam *, const SphereSOA *);
static scan_fn scanlines = render_scanlines_avx2;

static size_t microtime(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (size_t)tv.tv_sec * 1000000u + (size_t)tv.tv_usec;
}

static void vnorm3(float *x, float *y, float *z)
{
    float l2 = (*x)*(*x) + (*y)*(*y) + (*z)*(*z);
    if (l2 <= 0.f) return;
    float inv = 1.f / sqrtf(l2);
    *x *= inv; *y *= inv; *z *= inv;
}

static void rebuild_basis(float yaw, float pitch, float *fx, float *fy, float *fz,
                          float *rx, float *ry, float *rz, float *ux, float *uy, float *uz)
{
    if (pitch > 1.4f) pitch = 1.4f;
    if (pitch < -1.4f) pitch = -1.4f;
    *fx = sinf(yaw) * cosf(pitch);
    *fy = sinf(pitch);
    *fz = cosf(yaw) * cosf(pitch);
    vnorm3(fx, fy, fz);
    /* right = fwd × world_up */
    *rx = (*fy)*0.f - 1.f*(*fz);
    *ry = (*fz)*0.f - 0.f*(*fx);
    *rz = (*fx)*1.f - 0.f*(*fy);
    float r2 = (*rx)*(*rx)+(*ry)*(*ry)+(*rz)*(*rz);
    if (r2 < 1e-8f) {
        *rx = (*fy)*1.f - 0.f*(*fz);
        *ry = (*fz)*0.f - 1.f*(*fx);
        *rz = (*fx)*0.f - 0.f*(*fy);
    }
    vnorm3(rx, ry, rz);
    /* up = right × fwd */
    *ux = (*ry)*(*fz) - (*rz)*(*fy);
    *uy = (*rz)*(*fx) - (*rx)*(*fz);
    *uz = (*rx)*(*fy) - (*ry)*(*fx);
    vnorm3(ux, uy, uz);
}

static void reset_camera(float *yaw, float *pitch)
{
    cam.posx = 0.f; cam.posy = 1.1f; cam.posz = -6.5f;
    *yaw = 0.f;
    *pitch = -0.12f;
    rebuild_basis(*yaw, *pitch,
                  &cam.fwdx, &cam.fwdy, &cam.fwdz,
                  &cam.rtx, &cam.rty, &cam.rtz,
                  &cam.upx, &cam.upy, &cam.upz);
}

static void init_scene(void)
{
    memset(&sph, 0, sizeof(sph));
    const float R[RT_NUM_SPHERES] = {0.80f, 0.12f, 0.12f, 0.12f, 0.12f};
    const float C[RT_NUM_SPHERES][3] = {
        {0.95f, 0.15f, 0.12f},
        {0.15f, 0.95f, 0.20f},
        {0.10f, 0.70f, 0.70f},
        {0.70f, 0.12f, 0.70f},
        {0.20f, 0.25f, 0.95f},
    };
    const float F[RT_NUM_SPHERES] = {0.35f, 0.45f, 0.45f, 0.45f, 0.45f};
    for (int i = 0; i < RT_NUM_SPHERES; i++) {
        sph.r2[i] = R[i] * R[i];
        sph.cr[i] = C[i][0]; sph.cg[i] = C[i][1]; sph.cb[i] = C[i][2];
        sph.refl[i] = F[i];
    }
    cam.aspect = (float)RT_WIDTH / (float)RT_HEIGHT;
    cam.fov_scale = 1.f;
    cam.inv_w = 1.f / (float)RT_WIDTH;
    cam.inv_h = 1.f / (float)RT_HEIGHT;
    cam.ldx = -0.35f; cam.ldy = 0.85f; cam.ldz = -0.4f;
    vnorm3(&cam.ldx, &cam.ldy, &cam.ldz);
}

static void animate(float angle)
{
    sph.cx[0] = 0.f; sph.cy[0] = 0.f; sph.cz[0] = 0.f;
    const float off[4] = {0.f, (float)(M_PI/2), (float)M_PI, (float)(M_PI*3/2)};
    for (int i = 1; i < RT_NUM_SPHERES; i++) {
        float a = angle + off[i-1];
        sph.cx[i] = sinf(a) * 1.35f;
        sph.cy[i] = 0.15f * sinf(a * 2.f);
        sph.cz[i] = cosf(a) * 1.35f;
    }
}

static void *worker(void *arg)
{
    size_t index = (size_t)(uintptr_t)arg;
    while (!quit_flag) {
        pthread_barrier_wait(&frame_start);
        if (quit_flag) break;
        int chunk = RT_HEIGHT / (int)NUM_THREADS;
        int rem = RT_HEIGHT % (int)NUM_THREADS;
        int y0 = chunk * (int)index + (index < (size_t)rem ? (int)index : rem);
        int cnt = chunk + (index < (size_t)rem ? 1 : 0);
        scanlines(framebuffer, fb_pitch, y0, y0 + cnt, &cam, &sph);
        pthread_barrier_wait(&frame_done);
    }
    return NULL;
}

static void write_ppm(const char *path)
{
    FILE *f = fopen(path, "wb");
    if (!f) { perror(path); return; }
    fprintf(f, "P6\n%d %d\n255\n", RT_WIDTH, RT_HEIGHT);
    for (int y = 0; y < RT_HEIGHT; y++) {
        uint8_t *row = framebuffer + (size_t)y * (size_t)fb_pitch;
        for (int x = 0; x < RT_WIDTH; x++) {
            unsigned char rgb[3] = { row[x*4+2], row[x*4+1], row[x*4+0] };
            fwrite(rgb, 1, 3, f);
        }
    }
    fclose(f);
}

static int run_bench(int frames, int dump)
{
    float yaw, pitch;
    init_scene();
    reset_camera(&yaw, &pitch);
    animate(0.4f);

    framebuffer = aligned_alloc(32, (size_t)fb_pitch * RT_HEIGHT);
    if (!framebuffer) return 1;
    memset(framebuffer, 0, (size_t)fb_pitch * RT_HEIGHT);

    /* warmup */
    scanlines(framebuffer, fb_pitch, 0, RT_HEIGHT, &cam, &sph);

    size_t t0 = microtime();
    for (int i = 0; i < frames; i++) {
        animate(0.4f + i * orbit_speed);
        scanlines(framebuffer, fb_pitch, 0, RT_HEIGHT, &cam, &sph);
    }
    size_t dt = microtime() - t0;
    double ms = dt / 1000.0 / frames;
    printf("%s  %d frames  %.2f ms/frame  %.1f fps  (%dx%d)\n",
           use_avx2 ? "avx2" : "ref", frames, ms, ms > 0 ? 1000.0 / ms : 0,
           RT_WIDTH, RT_HEIGHT);
    if (dump)
        write_ppm(use_avx2 ? "frame_avx2.ppm" : "frame_ref.ppm");
    free(framebuffer);
    return 0;
}

#ifdef CPURENDER_HAS_X11
static int run_x11(void)
{
    Display *display = XOpenDisplay(NULL);
    if (!display) {
        fprintf(stderr, "XOpenDisplay failed — use --bench instead\n");
        return 1;
    }
    int shm_opcode, shm_event, shm_error;
    if (!XQueryExtension(display, "MIT-SHM", &shm_opcode, &shm_event, &shm_error) ||
        !XShmQueryExtension(display)) {
        fprintf(stderr, "MIT-SHM required\n");
        return 1;
    }
    int screen = DefaultScreen(display);
    Visual *visual = DefaultVisual(display, screen);
    int depth = DefaultDepth(display, screen);

    XShmSegmentInfo shminfo;
    memset(&shminfo, 0, sizeof(shminfo));
    XImage *ximage = XShmCreateImage(display, visual, (unsigned)depth, ZPixmap,
                                     NULL, &shminfo, RT_WIDTH, RT_HEIGHT);
    if (!ximage) return 2;
    shminfo.shmid = shmget(IPC_PRIVATE, (size_t)ximage->bytes_per_line * (size_t)ximage->height,
                           IPC_CREAT | 0600);
    if (shminfo.shmid < 0) { perror("shmget"); return 3; }
    shminfo.shmaddr = shmat(shminfo.shmid, NULL, 0);
    if (shminfo.shmaddr == (void *)-1) { perror("shmat"); return 4; }
    shminfo.readOnly = False;
    shmctl(shminfo.shmid, IPC_RMID, NULL);
    ximage->data = shminfo.shmaddr;
    if (!XShmAttach(display, &shminfo)) return 5;

    framebuffer = (uint8_t *)ximage->data;
    fb_pitch = ximage->bytes_per_line;
    if (ximage->bits_per_pixel != 32) {
        fprintf(stderr, "need 32-bpp X visual, got %d\n", ximage->bits_per_pixel);
        return 5;
    }

    XSetWindowAttributes swa;
    swa.event_mask = KeyPressMask | KeyReleaseMask | StructureNotifyMask | ExposureMask;
    swa.background_pixel = BlackPixel(display, screen);
    Window window = XCreateWindow(display, RootWindow(display, screen),
                                  0, 0, RT_WIDTH, RT_HEIGHT, 0, depth, InputOutput, visual,
                                  CWEventMask | CWBackPixel, &swa);
    XStoreName(display, window, use_avx2 ? "CPURender AVX2" : "CPURender ref");
    Atom wm_delete = XInternAtom(display, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(display, window, &wm_delete, 1);
    XMapWindow(display, window);
    XFlush(display);
    GC gc = DefaultGC(display, screen);

    if (pthread_barrier_init(&frame_start, NULL, (unsigned)(NUM_THREADS + 1)) != 0 ||
        pthread_barrier_init(&frame_done, NULL, (unsigned)(NUM_THREADS + 1)) != 0)
        return 6;

    pthread_t *threads = calloc(NUM_THREADS, sizeof(*threads));
    for (size_t i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, worker, (void *)(uintptr_t)i);

    float yaw, pitch;
    init_scene();
    reset_camera(&yaw, &pitch);
    float angle = 0.f;
    size_t frame = 0;

    printf("CPURender %dx%d, %zu thread%s, %s. Esc quits.\n",
           RT_WIDTH, RT_HEIGHT, NUM_THREADS, NUM_THREADS == 1 ? "" : "s",
           use_avx2 ? "avx2" : "ref");

    while (!quit_flag) {
        XEvent ev;
        while (XPending(display)) {
            XNextEvent(display, &ev);
            if (ev.type == ClientMessage && (Atom)ev.xclient.data.l[0] == wm_delete)
                quit_flag = 1;
            else if (ev.type == KeyPress) {
                KeySym ks = XLookupKeysym(&ev.xkey, 0);
                if (ks == XK_Escape) quit_flag = 1;
                if (ks == XK_space) orbit_paused = !orbit_paused;
                if (ks == XK_plus || ks == XK_equal || ks == XK_KP_Add) orbit_speed *= 1.15f;
                if (ks == XK_minus || ks == XK_KP_Subtract) orbit_speed *= 0.87f;
                if (ks == XK_r || ks == XK_R) reset_camera(&yaw, &pitch);
            }
        }
        char keymap[32];
        XQueryKeymap(display, keymap);
        #define KEYDOWN(sym) ({ KeyCode _kc = XKeysymToKeycode(display, (sym)); \
            _kc && (keymap[_kc / 8] & (1 << (_kc % 8))); })
        float move = 0.08f;
        if (KEYDOWN(XK_Shift_L) || KEYDOWN(XK_Shift_R)) move *= 3.f;
        if (KEYDOWN(XK_w) || KEYDOWN(XK_W) || KEYDOWN(XK_Up))    cam.posx += cam.fwdx*move, cam.posy += cam.fwdy*move, cam.posz += cam.fwdz*move;
        if (KEYDOWN(XK_s) || KEYDOWN(XK_S) || KEYDOWN(XK_Down))  cam.posx -= cam.fwdx*move, cam.posy -= cam.fwdy*move, cam.posz -= cam.fwdz*move;
        if (KEYDOWN(XK_a) || KEYDOWN(XK_A) || KEYDOWN(XK_Left))  cam.posx -= cam.rtx*move,  cam.posy -= cam.rty*move,  cam.posz -= cam.rtz*move;
        if (KEYDOWN(XK_d) || KEYDOWN(XK_D) || KEYDOWN(XK_Right)) cam.posx += cam.rtx*move,  cam.posy += cam.rty*move,  cam.posz += cam.rtz*move;
        if (KEYDOWN(XK_e) || KEYDOWN(XK_E)) cam.posy += move;
        if (KEYDOWN(XK_q) || KEYDOWN(XK_Q)) cam.posy -= move;
        if (KEYDOWN(XK_j) || KEYDOWN(XK_J)) yaw += 0.03f;
        if (KEYDOWN(XK_l) || KEYDOWN(XK_L)) yaw -= 0.03f;
        if (KEYDOWN(XK_i) || KEYDOWN(XK_I)) pitch += 0.025f;
        if (KEYDOWN(XK_k) || KEYDOWN(XK_K)) pitch -= 0.025f;
        #undef KEYDOWN
        rebuild_basis(yaw, pitch,
                      &cam.fwdx, &cam.fwdy, &cam.fwdz,
                      &cam.rtx, &cam.rty, &cam.rtz,
                      &cam.upx, &cam.upy, &cam.upz);
        if (!orbit_paused) {
            angle += orbit_speed;
            if (angle > (float)(M_PI * 2)) angle -= (float)(M_PI * 2);
        }
        animate(angle);

        size_t t0 = microtime();
        pthread_barrier_wait(&frame_start);
        pthread_barrier_wait(&frame_done);
        size_t dt = microtime() - t0;
        XShmPutImage(display, window, gc, ximage, 0, 0, 0, 0, RT_WIDTH, RT_HEIGHT, False);
        XFlush(display);
        frame++;
        if ((frame & 7) == 0)
            printf("\rframe %zu  %lu us  (%.1f fps)   ", frame, (unsigned long)dt,
                   dt ? 1e6 / (double)dt : 0.0);
        fflush(stdout);
    }
    quit_flag = 1;
    pthread_barrier_wait(&frame_start);
    for (size_t i = 0; i < NUM_THREADS; i++) pthread_join(threads[i], NULL);
    free(threads);
    pthread_barrier_destroy(&frame_start);
    pthread_barrier_destroy(&frame_done);
    XShmDetach(display, &shminfo);
    shmdt(shminfo.shmaddr);
    ximage->data = NULL;
    XDestroyImage(ximage);
    XDestroyWindow(display, window);
    XCloseDisplay(display);
    printf("\n");
    return 0;
}
#endif

int main(int argc, char **argv)
{
    long ncpu = sysconf(_SC_NPROCESSORS_ONLN);
    NUM_THREADS = ncpu > 0 ? (size_t)ncpu : 1;
    int bench = 0, frames = 8, dump = 0;

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--bench")) { bench = 1; if (i+1 < argc && argv[i+1][0] != '-') frames = atoi(argv[++i]); }
        else if (!strcmp(argv[i], "--ref")) { use_avx2 = 0; scanlines = render_scanlines_ref; }
        else if (!strcmp(argv[i], "--avx2")) { use_avx2 = 1; scanlines = render_scanlines_avx2; }
        else if (!strcmp(argv[i], "--dump")) dump = 1;
        else if (!strcmp(argv[i], "--help")) {
            fprintf(stderr, "usage: %s [--bench [N]] [--ref|--avx2] [--dump] [thread_count]\n", argv[0]);
            return 0;
        } else {
            char *end = NULL;
            unsigned long t = strtoul(argv[i], &end, 10);
            if (end != argv[i] && t >= 1 && t <= 256) NUM_THREADS = (size_t)t;
        }
    }

    if (bench) return run_bench(frames, dump);

#ifdef CPURENDER_HAS_X11
    return run_x11();
#else
    fprintf(stderr, "no X11 in this build; running --bench 4 --dump\n");
    return run_bench(4, 1);
#endif
}
