/*
--------------------------------------------------
    James William Fletcher (github.com/mrbid)
         & Test_User       (notabug.org/test_user)
            August 2023
--------------------------------------------------
    C & SDL2 / CPU DDA ray-tracer
    Colour Converter: https://www.easyrgb.com
*/
#include "excess.h"
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>

//#define BENCH_FPS
void WOX_QUIT()
{
    SDL_HideWindow(wnd);
    saveState(openTitle, "", load_state);
    drawText(NULL, "*K", 0, 0, 0);
    SDL_FreeSurface(s_icon);
    SDL_FreeSurface(sHud);
    sw_shutdown();
    SDL_DestroyWindow(wnd);
    SDL_Quit();
    exit(0);
}
void WOX_POP(const int w, const int h)
{
    winw = w;
    winh = h;
    winw2 = winw/2;
    winh2 = winh/2;
    if (winw < winh) {
        xscale = (float)winw/(float)winh;
        yscale = 1.f;
    } else {
        xscale = 1.f;
        yscale = (float)winh/(float)winw;
    }
    doPerspective();
}
static SDL_HitTestResult SDLCALL hitTest(SDL_Window *window, const SDL_Point *pt, void *data)
{
    if( SDL_PointInRect(pt, &(SDL_Rect){40, 0, winw2-85, 22}) == SDL_TRUE ||
        SDL_PointInRect(pt, &(SDL_Rect){winw2+30, 0, winw2-72, 22}) == SDL_TRUE)
        return SDL_HITTEST_DRAGGABLE;
    return SDL_HITTEST_NORMAL;
}
void drawHud(uint type);

void main_loop()
{
    // time delta
    static float lt = 0;
    t = fTime();
    const float dt = t-lt;
    lt = t;

    // fps counter (every frame, 0.5s window)
    {
        static uint fc = 0;
        static float ft = 0.f;
        fc++;
        if(ft == 0.f)
            ft = t + 0.5f;
        else if(t >= ft)
        {
            g_fps = fc * 2u;
#ifdef BENCH_FPS
            static uint count = 0;
            count++;
            if(count > 2){exit(0);}
            printf("%u\n", g_fps);
#endif
            fc = 0;
            ft = t + 0.5f;
        }
    }
#ifdef BENCH_FPS
    return;
#endif

    // input handling
    static float idle = 0.f;

    // if user is idle for 3 minutes, save.
    if(idle != 0.f && t-idle > 180.f)
    {
        saveState(openTitle, ".idle", load_state);
        idle = 0.f; // so we only save once
        // on input a new idle is set, and a
        // count-down for a new save begins.
    }

    // window decor stuff
    if(size == 1)
    {
        static float lt = 0;
        if(t > lt)
        {
            int w,h;
            SDL_GetWindowSize(wnd, &w, &h);
            winw = w+(mx-dsx);
            winh = h+(my-dsy);
            dsx = mx;
            dsy = my;
            if(winw > 400 && winh > 380)
            {
                SDL_SetWindowSize(wnd, winw, winh);
                winw2 = winw/2;
                winh2 = winh/2;
                doPerspective();
            }
            lt = t+0.03f;
        }
    }

    static uint last_focus_mouse = 0;
    SDL_Event event;
    while(SDL_PollEvent(&event))
    {
        switch(event.type)
        {
            case SDL_WINDOWEVENT:
            {
                switch(event.window.event)
                {
                    case SDL_WINDOWEVENT_FOCUS_GAINED:
                    {
                        focus_mouse = last_focus_mouse;
                        //if(focus_mouse == 1){drawHud(1);}else{drawHud(0);}
                        SDL_ShowCursor(focus_mouse ? SDL_DISABLE : SDL_ENABLE);
                        if(wayland == 1 && focus_mouse == 1)
                        {
                            SDL_GetRelativeMouseState(&xd, &yd);
                            SDL_SetRelativeMouseMode(SDL_TRUE);
                        }
                    }
                    break;

                    case SDL_WINDOWEVENT_FOCUS_LOST:
                    {
                        last_focus_mouse = focus_mouse;
                        focus_mouse = 0;
                        //drawHud(0);
                        SDL_ShowCursor(SDL_ENABLE);
                        if(wayland == 1)
                        {
                            SDL_GetRelativeMouseState(&xd, &yd);
                            SDL_SetRelativeMouseMode(SDL_FALSE);
                        }
                    }
                    break;

                    case SDL_WINDOWEVENT_RESIZED:
                    {
                        WOX_POP(event.window.data1, event.window.data2);
                    }
                    break;
                }
            }
            break;

            case SDL_KEYDOWN:
            {
                if(bind_hit(ACT_MENU, &event))
                {
                    focus_mouse = 1 - focus_mouse;
                    SDL_ShowCursor(1 - focus_mouse);
                    if(wayland == 1)
                    {
                        if(focus_mouse == 1)
                        {
                            SDL_GetRelativeMouseState(&xd, &yd);
                            SDL_SetRelativeMouseMode(SDL_TRUE);
                        }
                        else
                        {
                            SDL_GetRelativeMouseState(&xd, &yd);
                            SDL_SetRelativeMouseMode(SDL_FALSE);
                        }
                    }
                    else
                    {
                        mx = winw2, my = winh2;
                        lx = winw2, ly = winh2;
                        SDL_WarpMouseInWindow(wnd, winw2, winh2);
                    }
                }
                else if(bind_hit(ACT_HUD, &event))
                {
                    showhud = 1 - showhud;
                }
                if(focus_mouse == 0){break;}
                if(bind_hit(ACT_FORWARD, &event)){ks[0] = 1;}
                else if(bind_hit(ACT_LEFT, &event)){ks[1] = 1;}
                else if(bind_hit(ACT_BACK, &event)){ks[2] = 1;}
                else if(bind_hit(ACT_RIGHT, &event)){ks[3] = 1;}
                else if(bind_hit(ACT_DOWN, &event)){ks[4] = 1;}
                else if(bind_hit(ACT_LOOK_LEFT, &event)){ks[5] = 1;}
                else if(bind_hit(ACT_LOOK_RIGHT, &event)){ks[6] = 1;}
                else if(bind_hit(ACT_LOOK_UP, &event)){ks[7] = 1;}
                else if(bind_hit(ACT_LOOK_DOWN, &event)){ks[8] = 1;}
                else if(bind_hit(ACT_UP, &event)){ks[9] = 1;}
                else if(bind_hit(ACT_COLOR_PREV, &event))
                {
                    traceViewPath(0);
                    if(lray > -1 && g.voxels[lray] > 7)
                    {
                        g.voxels[lray] = (uchar)pal_prev((float)g.voxels[lray]);
                        g.st = (float)g.voxels[lray];
                        mark_dirty_index(lray);
                        updateSelectColor();
                    }
                    else
                    {
                        g.st = pal_prev(g.st);
                        updateSelectColor();
                    }
                }
                else if(bind_hit(ACT_COLOR_NEXT, &event))
                {
                    traceViewPath(0);
                    if(lray > -1 && g.voxels[lray] > 7)
                    {
                        g.voxels[lray] = (uchar)pal_next((float)g.voxels[lray]);
                        g.st = (float)g.voxels[lray];
                        mark_dirty_index(lray);
                        updateSelectColor();
                    }
                    else
                    {
                        g.st = pal_next(g.st);
                        updateSelectColor();
                    }
                }
                else if(bind_hit(ACT_PLACE, &event))
                {
                    ptt = t+rrsp;
                    traceViewPath(1);
                    if(lray > -1)
                    {
                        if(g.pb.w == 1 && isInBounds(g.pb) && g.voxels[PTI(g.pb.x, g.pb.y, g.pb.z)] == 0)
                        {
                            voxel_set_brush(g.pb.x, g.pb.y, g.pb.z, pal_voxel());
                        }
                    }
                }
                else if(bind_hit(ACT_DELETE, &event))
                {
                    dtt = t+rrsp;
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        voxel_set_brush(ghp.x, ghp.y, ghp.z, 0);
                    }
                }
                else if(bind_hit(ACT_CLONE, &event))
                {
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        if(g.voxels[lray] > 7)
                        {
                            g.st = (float)g.voxels[lray];
                            updateSelectColor();
                        }
                        else{sprintf(warnm, "This is a system color you cannot clone this."); wti = t+1.f;}
                    }
                }
                else if(bind_hit(ACT_REPLACE, &event))
                {
                    rtt = t+rrsp;
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        voxel_set_brush(ghp.x, ghp.y, ghp.z, pal_voxel());
                    }
                }
                else if(bind_hit(ACT_MIRROR, &event))
                {
                    mirror = 1 - mirror;
                }
                else if(bind_hit(ACT_PLACE_HERE, &event))
                {
                    vec p = g.pp;
                    vInv(&p);
                    vec pi = look_dir;
                    vMulS(&pi, pi, 6.f);
                    vAdd(&p, p, pi);
                    const vec rp = (vec){roundf(p.x), roundf(p.y), roundf(p.z)};
                    if(isInBounds(rp) == 1)
                    {
                        voxel_set(rp.x, rp.y, rp.z, 8);
                    }
                }
                else if(bind_hit(ACT_FAST, &event))
                {
                    fks = 1 - fks;
                    if(fks){g.ms = g.cms;}
                       else{g.ms = g.lms;}
                }
                else if(bind_hit(ACT_SPEED1, &event))
                {
                    g.ms = 9.3f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED2, &event))
                {
                    g.ms = 18.6f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED3, &event))
                {
                    g.ms = 37.2f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED4, &event))
                {
                    g.ms = 74.4f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED5, &event))
                {
                    g.ms = 148.8f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED6, &event))
                {
                    g.ms = 297.6f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_SPEED7, &event))
                {
                    g.ms = 595.2f;
                    if(fks){g.cms=g.ms;}else{g.lms=g.ms;}
                }
                else if(bind_hit(ACT_RESET, &event))
                {
                    SDL_SetWindowSize(wnd, 1024, 768);
                    WOX_POP(1024, 768);
                    defaultState(0);
                    fks = 0;
                }
                else if(bind_hit(ACT_SAVE, &event))
                {
                    saveState(openTitle, "", load_state);
                }
                else if(bind_hit(ACT_LOAD, &event))
                {
                    loadState(openTitle, 0);
                    mark_dirty_full();
                }
                else if(bind_hit(ACT_PITCH, &event))
                {
                    g.plock = 1 - g.plock;
                }
                idle = t;
            }
            break;

            case SDL_KEYUP:
            {
                if(focus_mouse == 0){break;}
                if(bind_hit(ACT_FORWARD, &event)){ks[0] = 0;}
                else if(bind_hit(ACT_LEFT, &event)){ks[1] = 0;}
                else if(bind_hit(ACT_BACK, &event)){ks[2] = 0;}
                else if(bind_hit(ACT_RIGHT, &event)){ks[3] = 0;}
                else if(bind_hit(ACT_DOWN, &event)){ks[4] = 0;}
                else if(bind_hit(ACT_LOOK_LEFT, &event)){ks[5] = 0;}
                else if(bind_hit(ACT_LOOK_RIGHT, &event)){ks[6] = 0;}
                else if(bind_hit(ACT_LOOK_UP, &event)){ks[7] = 0;}
                else if(bind_hit(ACT_LOOK_DOWN, &event)){ks[8] = 0;}
                else if(bind_hit(ACT_UP, &event)){ks[9] = 0;}
                else if(bind_hit(ACT_PLACE, &event)){ptt = 0.f;}
                else if(bind_hit(ACT_DELETE, &event)){dtt = 0.f;}
                else if(bind_hit(ACT_REPLACE, &event)){rtt = 0.f;}
                idle = t;
            }
            break;

            case SDL_MOUSEWHEEL: // change selected node
            {
                if(focus_mouse == 0){break;}

                bigc = t+0.5f;

                if(event.wheel.y < 0)
                {
                    g.st = pal_next(g.st);
                    updateSelectColor();
                }
                else if(event.wheel.y > 0)
                {
                    g.st = pal_prev(g.st);
                    updateSelectColor();
                }
            }
            break;

            case SDL_MOUSEMOTION:
            {
                mx = event.motion.x;
                my = event.motion.y;

                if(focus_mouse == 0){break;}
                idle = t;
            }
            break;

            case SDL_MOUSEBUTTONUP:
            {
                if(event.button.button == SDL_BUTTON_LEFT)
                {
                    if(size == 1)
                    {
                        size=0;
                        SDL_GetWindowSize(wnd, &winw, &winh);
                        WOX_POP(winw, winh);
                        SDL_CaptureMouse(SDL_FALSE);
                    }
                    ptt = 0.f;
                }
                else if(event.button.button == SDL_BUTTON_RIGHT){dtt = 0.f;}
                else if(event.button.button == SDL_BUTTON_X2){rtt = 0.f;}
                idle = t;
            }
            break;

            case SDL_MOUSEBUTTONDOWN:
            {
                if(wayland == 0)
                {
                    lx = event.button.x;
                    ly = event.button.y;
                }
                mx = event.button.x;
                my = event.button.y;

                static float llct = 0.f;
                static uint maxed = 0;

                if(event.button.button == SDL_BUTTON_LEFT) // check window decor stuff
                {
                    if(wayland == 1 && focus_mouse == 0)
                    {
                        if(llct != 0.f && t-llct < 0.3f)
                        {
                            if(maxed == 0)
                            {
                                SDL_MaximizeWindow(wnd);
                                maxed = 1;
                                size = 0;
                                llct = t;
                                break;
                            }
                            else
                            {
                                SDL_RestoreWindow(wnd);
                                maxed = 0;
                                size = 0;
                                llct = t;
                                break;
                            }
                        }
                        llct = t;
                        if(my < 22)
                        {
                            if(mx < 14)
                            {
                                WOX_QUIT();
                                break;
                            }
                            else if(mx < 24)
                            {
                                SDL_MinimizeWindow(wnd);
                                break;
                            }
                            else if(mx < 40)
                            {
                                maxed = 1 - maxed;
                                if(maxed == 1){SDL_MaximizeWindow(wnd);}
                                else{SDL_RestoreWindow(wnd);}
                                break;
                            }
                            else if(mx > winw-14)
                            {
                                WOX_QUIT();
                                break;
                            }
                            else if(mx > winw-24)
                            {
                                SDL_MinimizeWindow(wnd);
                                break;
                            }
                            else if(mx > winw-40)
                            {
                                maxed = 1 - maxed;
                                if(maxed == 1){SDL_MaximizeWindow(wnd);}
                                else{SDL_RestoreWindow(wnd);}
                                break;
                            }

                            dsx = mx, dsy = my;
                            break;
                        }
                        else if(mx > winw-15 && my > winh-15)
                        {
                            size = 1;
                            dsx = mx, dsy = my;
                            SDL_CaptureMouse(SDL_TRUE);
                            break;
                        }
                    }
                }

                if(focus_mouse == 0) // lock mouse focus on every mouse input to the window
                {
                    SDL_ShowCursor(0);
                    focus_mouse = 1;
                    if(wayland == 1)
                    {
                        SDL_GetRelativeMouseState(&xd, &yd);
                        SDL_SetRelativeMouseMode(SDL_TRUE);
                    }
                    break;
                }

                if(event.button.button == SDL_BUTTON_LEFT) // place a voxel
                {
                    ptt = t+rrsp;
                    traceViewPath(1);
                    if(lray > -1)
                    {
                        if(g.pb.w == 1 && isInBounds(g.pb) && g.voxels[PTI(g.pb.x, g.pb.y, g.pb.z)] == 0)
                        {
                            voxel_set_brush(g.pb.x, g.pb.y, g.pb.z, pal_voxel());
                        }
                    }
                }
                else if(event.button.button == SDL_BUTTON_RIGHT) // remove pointed voxel
                {
                    dtt = t+rrsp;
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        voxel_set_brush(ghp.x, ghp.y, ghp.z, 0);
                    }
                }
                else if(event.button.button == SDL_BUTTON_MIDDLE || event.button.button == SDL_BUTTON_X1) // clone pointed voxel
                {
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        if(g.voxels[lray] > 7)
                        {
                            g.st = (float)g.voxels[lray];
                            updateSelectColor();
                        }
                        else{sprintf(warnm, "This is a system color you cannot clone this."); wti = t+1.f;}
                    }
                }
                else if(event.button.button == SDL_BUTTON_X2) // replace pointed node
                {
                    rtt = t+rrsp;
                    traceViewPath(0);
                    if(lray > -1)
                    {
                        voxel_set_brush(ghp.x, ghp.y, ghp.z, pal_voxel());
                    }
                }
                idle = t;
            }
            break;

            case SDL_QUIT:
            {
                WOX_QUIT();
            }
            break;
        }
    }

    // on window focus
    if(focus_mouse == 1)
    {
        mGetViewZ(&look_dir, view);

        if(g.plock == 1)
        {
            look_dir.z = -0.001f;
            vNorm(&look_dir);
        }

        if(ks[0] == 1) // W
        {
            vec m;
            vMulS(&m, look_dir, g.ms * dt);
            vSub(&g.pp, g.pp, m);
        }
        else if(ks[2] == 1) // S
        {
            vec m;
            vMulS(&m, look_dir, g.ms * dt);
            vAdd(&g.pp, g.pp, m);
        }

        if(ks[1] == 1) // A
        {
            vec vdc;
            mGetViewX(&vdc, view);
            vec m;
            vMulS(&m, vdc, g.ms * dt);
            vSub(&g.pp, g.pp, m);
        }
        else if(ks[3] == 1) // D
        {
            vec vdc;
            mGetViewX(&vdc, view);
            vec m;
            vMulS(&m, vdc, g.ms * dt);
            vAdd(&g.pp, g.pp, m);
        }

        if(ks[4] == 1) // LSHIFT (down)
        {
            vec vdc;
            if(g.plock == 1)
                vdc = (vec){0.f,0.f,-1.f};
            else
                mGetViewY(&vdc, view);
            vec m;
            vMulS(&m, vdc, g.ms * dt);
            vSub(&g.pp, g.pp, m);
        }
        else if(ks[9] == 1) // SPACE (up)
        {
            vec vdc;
            if(g.plock == 1)
                vdc = (vec){0.f,0.f,-1.f};
            else
                mGetViewY(&vdc, view);
            vec m;
            vMulS(&m, vdc, g.ms * dt);
            vAdd(&g.pp, g.pp, m);
        }

        if(ks[5] == 1) // LEFT
            g.xrot += 0.7f*dt;
        else if(ks[6] == 1) // RIGHT
            g.xrot -= 0.7f*dt;

        if(ks[7] == 1) // UP
            g.yrot += 0.7f*dt;
        else if(ks[8] == 1) // DOWN
            g.yrot -= 0.7f*dt;

        if(wayland == 1)
        {
            // camera/mouse control
            SDL_GetRelativeMouseState(&xd, &yd);
            if(xd != 0 || yd != 0)
            {
                g.xrot -= xd*g.sens;
                g.yrot -= yd*g.sens;

                if(g.plock == 1)
                {
                    if(g.yrot > 3.11f)
                        g.yrot = 3.11f;
                    if(g.yrot < 0.03f)
                        g.yrot = 0.03f;
                }
                else
                {
                    if(g.yrot > 3.14f)
                        g.yrot = 3.14f;
                    if(g.yrot < 0.1f)
                        g.yrot = 0.1f;
                }
            }
        }
        else
        {
            // camera/mouse control
            const float xd = lx-mx;
            const float yd = ly-my;
            if(xd != 0 || yd != 0)
            {
                g.xrot += xd*g.sens;
                g.yrot += yd*g.sens;

                if(g.plock == 1)
                {
                    if(g.yrot > 3.11f)
                        g.yrot = 3.11f;
                    if(g.yrot < 0.03f)
                        g.yrot = 0.03f;
                }
                else
                {
                    if(g.yrot > 3.14f)
                        g.yrot = 3.14f;
                    if(g.yrot < 0.1f)
                        g.yrot = 0.1f;
                }
                
                lx = winw2, ly = winh2;
                SDL_WarpMouseInWindow(wnd, lx, ly);
            }
        }
    }

    mIdent(&view);
    mSetRotY(&view, g.yrot);
    mRotZ(&view, g.xrot);

    mGetViewZ(&look_dir, view); // refresh

//*************************************
// begin render
//*************************************

//*************************************
// main render
//*************************************

    ipp = g.pp; // inverse player position (setting global 'ipp' here is perfect)
    vInv(&ipp); // <--

    if(focus_mouse == 1)
    {
        if(ptt != 0.f && t > ptt) // place trigger
        {
            traceViewPath(1);
            if(lray > -1)
            {
                if(g.pb.w == 1 && isInBounds(g.pb) && g.voxels[PTI(g.pb.x, g.pb.y, g.pb.z)] == 0)
                {
                    voxel_set_brush(g.pb.x, g.pb.y, g.pb.z, pal_voxel());
                }
            }
            ptt = t+0.1f;
        }
        if(dtt != 0.f && t > dtt) // delete rigger
        {
            traceViewPath(0);
            if(lray > -1)
            {
                voxel_set_brush(ghp.x, ghp.y, ghp.z, 0);
            }
            dtt = t+0.1f;
        }
        if(rtt != 0.f) // replace trigger
        {
            traceViewPath(0);
            if(lray > -1)
            {
                voxel_set_brush(ghp.x, ghp.y, ghp.z, pal_voxel());
            }
        }
    }

    // hud
    {
        static float nt = 0.f;
        if(t > nt)
        {
            drawHud(focus_mouse);
            flipHud();
            nt = t+0.1f; // limit hud to 10fps
        }
    }

    has_changed = 0;
    dirty_mode = 0;
    sw_render();
}

void drawHud(const uint type)
{    
    // clear cpu hud before rendering to it
    SDL_FillRect(sHud, &sHud->clip_rect, 0x00000000);
    if(show_fps && showhud)
    {
        char tmp[16];
        sprintf(tmp, "%u", g_fps);
        const int fy = (type == 0 && wayland == 1) ? 19 : 0;
        SDL_FillRect(sHud, &(SDL_Rect){0, fy, lenText(tmp)+8, 19}, 0xCC000000);
        drawText(sHud, tmp, 4, fy + 4, 2);
    }
    if(type == 0)
    {
        if(wayland == 1)
        {
            // updated maxed state >:( wayland
            const uint flags = SDL_GetWindowFlags(wnd);
            if(flags & SDL_WINDOW_MAXIMIZED){maxed = 1;}else{maxed = 0;}

            // window title
            SDL_FillRect(sHud, &(SDL_Rect){0, 0, winw, 19}, 0xDDFFFF00);
            SDL_FillRect(sHud, &(SDL_Rect){1, 1, winw-2, 17}, 0xBB777700);
            const uint len = lenText("Woxel");
            drawText(sHud, "Woxel", winw2-24, 3, 3);
            drawText(sHud, "Woxel", winw2-26, 3, 3);
            drawText(sHud, "Woxel", winw2-25, 5, 3);
            drawText(sHud, "Woxel", winw2-25, 4, 0);
            drawText(sHud, "X -", 5, 4, 3);
            drawText(sHud, "X -", 4, 5, 0);
            if(maxed == 0)
            {
                SDL_FillRect(sHud, &(SDL_Rect){25, 3, 11, 11}, 0xFF00BFFF);
                SDL_FillRect(sHud, &(SDL_Rect){24, 4, 11, 11}, 0xFF000000);
                SDL_FillRect(sHud, &(SDL_Rect){25, 5, 9, 9}, 0xBB777700);
            }
            else
            {
                SDL_FillRect(sHud, &(SDL_Rect){24, 4, 11, 11}, 0xFF00BFFF);
                SDL_FillRect(sHud, &(SDL_Rect){23, 3, 11, 11}, 0xFF000000);
                SDL_FillRect(sHud, &(SDL_Rect){24, 4, 9, 9}, 0xBB777700);
            }
            drawText(sHud, "- X", winw-23, 4, 3);
            drawText(sHud, "- X", winw-22, 5, 0);
            if(maxed == 0)
            {
                SDL_FillRect(sHud, &(SDL_Rect){winw-38, 3, 11, 11}, 0xFF00BFFF);
                SDL_FillRect(sHud, &(SDL_Rect){winw-37, 4, 11, 11}, 0xFF000000);
                SDL_FillRect(sHud, &(SDL_Rect){winw-36, 5, 9, 9}, 0xBB777700);
            }
            else
            {
                SDL_FillRect(sHud, &(SDL_Rect){winw-37, 4, 11, 11}, 0xFF00BFFF);
                SDL_FillRect(sHud, &(SDL_Rect){winw-36, 3, 11, 11}, 0xFF000000);
                SDL_FillRect(sHud, &(SDL_Rect){winw-35, 4, 9, 9}, 0xBB777700);
            }
            SDL_FillRect(sHud, &(SDL_Rect){winw-15, winh-15, 15, 15}, 0xDDFFFF00);
            SDL_FillRect(sHud, &(SDL_Rect){winw-14, winh-14, 13, 13}, 0xBB777700);
            drawText(sHud, "r", winw-9, winh-13, 3);
            drawText(sHud, "r", winw-10, winh-14, 0);

            SDL_FillRect(sHud, &(SDL_Rect){40, 3, winw2-85, 13}, 0xDDa0b010);
            SDL_FillRect(sHud, &(SDL_Rect){winw2+30, 3, winw2-72, 13}, 0xDDa0b010);
        }

        // center hud
        const int left = winw2-177;
        int top = winh2-152;
        SDL_FillRect(sHud, &(SDL_Rect){winw2-193, top-3, 382, 303}, 0x33FFFFFF);
        SDL_FillRect(sHud, &(SDL_Rect){winw2-190, top, 376, 297}, 0xCC000000);
        int a = drawText(sHud, "Woxel", winw2-15, top+11, 3);
        a = drawText(sHud, appVersion, left+330, top+11, 4);
        a = drawText(sHud, "woxels.github.io", left, top+11, 4);

        top += 33;
        a = drawText(sHud, "WASD ", left, top, 2);
        drawText(sHud, "Move around based on relative orientation to X and Y.", a, top, 1);

        top += 11;
        a = drawText(sHud, "SPACE", left, top, 2);
        a = drawText(sHud, " + ", a, top, 4);
        a = drawText(sHud, "L-SHIFT ", a, top, 2);
        drawText(sHud, "Move up and down relative Z.", a, top, 1);

        top += 11;
        a = drawText(sHud, "F ", left, top, 2);
        drawText(sHud, "Toggle player fast speed on and off.", a, top, 1);

        top += 11;
        a = drawText(sHud, "1", left, top, 2);
        a = drawText(sHud, "-", a, top, 4);
        a = drawText(sHud, "7 ", a, top, 2);
        drawText(sHud, "Change move speed for selected fast state.", a, top, 1);

        top += 11;
        a = drawText(sHud, "P ", left, top, 2);
        a = drawText(sHud, "Toggle pitch lock.", a, top, 1);
        a = drawText(sHud, " IJKL", a, top, 2);
        drawText(sHud, "/Arrows look around.", a, top, 1);

        top += 22;
        a = drawText(sHud, "Left Click ", left, top, 2);
        a = drawText(sHud, "Place node.", a, top, 1);
        a = drawText(sHud, " Right Click ", a, top, 2);
        drawText(sHud, "Delete node.", a, top, 1);

        top += 11;
        a = drawText(sHud, "Q ", left, top, 2);
        a = drawText(sHud, "Clone color of pointed node.", a, top, 1);
        a = drawText(sHud, " E ", a, top, 2);
        drawText(sHud, "Replace color of pointed node.", a, top, 1);

        top += 11;
        a = drawText(sHud, "R ", left, top, 2);
        a = drawText(sHud, "Toggle mirror brush.", a, top, 1);
        a = drawText(sHud, " V ", a, top, 2);
        drawText(sHud, "Place node at current location.", a, top, 1);

        top += 11;
        a = drawText(sHud, "Middle Scroll ", left, top, 2);
        drawText(sHud, "Change selected color.", a, top, 1);

        top += 11;
        a = drawText(sHud, "X", left, top, 2);
        a = drawText(sHud, " + ", a, top, 4);
        a = drawText(sHud, "C ", a, top, 2);
        drawText(sHud, "Scroll color of pointed node.", a, top, 1);

        top += 22;
        a = drawText(sHud, "F1 ", left, top, 2);
        drawText(sHud, "Resets environment state back to default.", a, top, 1);

        top += 11;
        a = drawText(sHud, "F2 ", left, top, 2);
        drawText(sHud, "Toggles visibility of the HUD.", a, top, 1);

        top += 11;
        a = drawText(sHud, "F3 ", left, top, 2);
        drawText(sHud, "Save. Will auto save on exit. Backup made if idle for 3 mins.", a, top, 1);

        top += 11;
        a = drawText(sHud, "F8 ", left, top, 2);
        drawText(sHud, "Load. Will erase what you have done since the last save.", a, top, 1);

        top += 21;
        drawText(sHud, "Check the console output for more information.", left, top, 3);

        for(uint i = 0; i < 16; i++)
        {
            const uint left2 = left+(i*22);
            {
                uint tu = g.colors[7+i];
                if(i < g.pal_n)
                {
                    uchar r = (tu & 0x00FF0000) >> 16;
                    uchar gc = (tu & 0x0000FF00) >> 8;
                    uchar b = (tu & 0x000000FF);
                    SDL_FillRect(sHud, &(SDL_Rect){left2, top+21, 20, 20}, 0xFFFFFFFF);
                    const Uint32 tclr = SDL_MapRGB(sHud->format, r,gc,b);
                    SDL_FillRect(sHud, &(SDL_Rect){left2+1, top+22, 18, 18}, tclr);
                    if(mx > left2 && mx < left2+20 && my > top+21 && my < top+42)
                    {
                        char tmp[16];
                        sprintf(tmp, "%02X%02X%02X", r, gc, b);
                        const int len = lenText(tmp);
                        const int len2 = len/2;
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2-4, top-4, len+9, 19}, tclr);
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2-1, top-1, len+3, 13}, 0xFF00BFFF);
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2, top, len+1, 11}, 0xFF000000);
                        drawText(sHud, tmp, mx-len2+1, top, 3);
                    }
                }
            }
            {
                uint tu = g.colors[23+i];
                if((16+i) < g.pal_n)
                {
                    uchar r = (tu & 0x00FF0000) >> 16;
                    uchar gc = (tu & 0x0000FF00) >> 8;
                    uchar b = (tu & 0x000000FF);
                    SDL_FillRect(sHud, &(SDL_Rect){left2, top+43, 20, 20}, 0xFFFFFFFF);
                    const Uint32 tclr = SDL_MapRGB(sHud->format, r,gc,b);
                    SDL_FillRect(sHud, &(SDL_Rect){left2+1, top+44, 18, 18}, tclr);
                    if(mx > left2 && mx < left2+20 && my > top+43 && my < top+63)
                    {
                        char tmp[16];
                        sprintf(tmp, "%02X%02X%02X", r, gc, b);
                        const int len = lenText(tmp);
                        const int len2 = len/2;
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2-4, top-4, len+9, 19}, tclr);
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2-1, top-1, len+3, 13}, 0xFF00BFFF);
                        SDL_FillRect(sHud, &(SDL_Rect){mx-len2, top, len+1, 11}, 0xFF000000);
                        drawText(sHud, tmp, mx-len2+1, top, 3);
                    }
                }
            }
        }
    }
    else if(showhud == 1)
    {
        if(t < bigc)
        {
            SDL_FillRect(sHud, &(SDL_Rect){winw2-3, winh2-3, 6, 6}, sclr);
        }
        else
        {
            setpixel(sHud, winw2, winh2, sclr);
            //
            setpixel(sHud, winw2+1, winh2, sclr);
            setpixel(sHud, winw2-1, winh2, sclr);
            setpixel(sHud, winw2, winh2+1, sclr);
            setpixel(sHud, winw2, winh2-1, sclr);
            //
            setpixel(sHud, winw2+2, winh2, sclr);
            setpixel(sHud, winw2-2, winh2, sclr);
            setpixel(sHud, winw2, winh2+2, sclr);
            setpixel(sHud, winw2, winh2-2, sclr);
            //
            setpixel(sHud, winw2+3, winh2, sclr);
            setpixel(sHud, winw2-3, winh2, sclr);
            setpixel(sHud, winw2, winh2+3, sclr);
            setpixel(sHud, winw2, winh2-3, sclr);
            // now the part to prevent invisible crosshair
            setpixel(sHud, winw2+1, winh2+1, 0xCC000000);
            setpixel(sHud, winw2-1, winh2-1, 0xCC000000);
            setpixel(sHud, winw2-1, winh2+1, 0xCC000000);
            setpixel(sHud, winw2+1, winh2-1, 0xCC000000);
            //
            setpixel(sHud, winw2+2, winh2+1, 0xCC000000);
            setpixel(sHud, winw2-2, winh2-1, 0xCC000000);
            setpixel(sHud, winw2-1, winh2+2, 0xCC000000);
            setpixel(sHud, winw2+1, winh2-2, 0xCC000000);
            //
            setpixel(sHud, winw2+3, winh2+1, 0xCC000000);
            setpixel(sHud, winw2-3, winh2-1, 0xCC000000);
            setpixel(sHud, winw2-1, winh2+3, 0xCC000000);
            setpixel(sHud, winw2+1, winh2-3, 0xCC000000);

            if(g.plock == 1)
            {
                setpixel(sHud, winw2+4, winh2, sclr);
                setpixel(sHud, winw2-4, winh2, sclr);
                setpixel(sHud, winw2+5, winh2, sclr);
                setpixel(sHud, winw2-5, winh2, sclr);
            }

            if(mirror == 1)
            {
                setpixel(sHud, winw2+2, winh2+2, sclr);
                setpixel(sHud, winw2-2, winh2-2, sclr);
                //
                setpixel(sHud, winw2+3, winh2+2, sclr);
                setpixel(sHud, winw2-3, winh2-2, sclr);
                setpixel(sHud, winw2+2, winh2+3, sclr);
                setpixel(sHud, winw2-2, winh2-3, sclr);
                //
                setpixel(sHud, winw2+4, winh2+2, sclr);
                setpixel(sHud, winw2-4, winh2-2, sclr);
                setpixel(sHud, winw2+2, winh2+4, sclr);
                setpixel(sHud, winw2-2, winh2-4, sclr);
                //
                setpixel(sHud, winw2+5, winh2+2, sclr);
                setpixel(sHud, winw2-5, winh2-2, sclr);
                setpixel(sHud, winw2+2, winh2+5, sclr);
                setpixel(sHud, winw2-2, winh2-5, sclr);
                // now the part to prevent invisible crosshair
                setpixel(sHud, winw2+3, winh2+3, 0xCC000000);
                setpixel(sHud, winw2+3, winh2+4, 0xCC000000);
                setpixel(sHud, winw2+3, winh2+5, 0xCC000000);
                setpixel(sHud, winw2+4, winh2+3, 0xCC000000);
                setpixel(sHud, winw2+5, winh2+3, 0xCC000000);
                setpixel(sHud, winw2-3, winh2-3, 0xCC000000);
                setpixel(sHud, winw2-3, winh2-4, 0xCC000000);
                setpixel(sHud, winw2-3, winh2-5, 0xCC000000);
                setpixel(sHud, winw2-4, winh2-3, 0xCC000000);
                setpixel(sHud, winw2-5, winh2-3, 0xCC000000);
            }
        }

        const int hso = winw2-175;
        for(uint i = 0; i < 16; i++)
        {
            const uint left = hso+(i*22);
            {
                uint tu = g.colors[7+i];
                if(i < g.pal_n)
                {
                    uchar r = (tu & 0x00FF0000) >> 16;
                    uchar gc = (tu & 0x0000FF00) >> 8;
                    uchar b = (tu & 0x000000FF);
                    if(pal_color_index() == 7+i)
                        SDL_FillRect(sHud, &(SDL_Rect){left, 11, 20, 20}, 0xFFFFFFFF);
                    else
                        SDL_FillRect(sHud, &(SDL_Rect){left, 11, 20, 20}, 0xFF000000);
                    SDL_FillRect(sHud, &(SDL_Rect){left+1, 12, 18, 18}, SDL_MapRGB(sHud->format, r,gc,b));
                }
            }
            {
                uint tu = g.colors[23+i];
                if((16+i) < g.pal_n)
                {
                    uchar r = (tu & 0x00FF0000) >> 16;
                    uchar gc = (tu & 0x0000FF00) >> 8;
                    uchar b = (tu & 0x000000FF);
                    if(pal_color_index() == 23+i)
                        SDL_FillRect(sHud, &(SDL_Rect){left, 33, 20, 20}, 0xFFFFFFFF);
                    else
                        SDL_FillRect(sHud, &(SDL_Rect){left, 33, 20, 20}, 0xFF000000);
                    SDL_FillRect(sHud, &(SDL_Rect){left+1, 34, 18, 18}, SDL_MapRGB(sHud->format, r,gc,b));
                }
            }
        }
    }

    // tooltips
    if(wti > t)
    {
        const int hlen = lenText(warnm)/2;
        drawText(sHud, warnm, winw2-hlen, winh2-22, 3);
    }

    // flip the new hud to gpu
    flipHud();
}

//*************************************
// Process Entry Point
//*************************************
int main(int argc, char** argv)
{
//*************************************
// init stuff
//*************************************
    printf("██╗    ██╗ ██████╗ ██╗  ██╗███████╗██╗     \n");
    printf("██║    ██║██╔═══██╗╚██╗██╔╝██╔════╝██║     \n");
    printf("██║ █╗ ██║██║   ██║ ╚███╔╝ █████╗  ██║     \n");
    printf("██║███╗██║██║   ██║ ██╔██╗ ██╔══╝  ██║     \n");
    printf("╚███╔███╔╝╚██████╔╝██╔╝ ██╗███████╗███████╗\n");
    printf(" ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝\n");
    printf("\nMouse locks when you click on the window, press ESCAPE/TAB to unlock the mouse.\n\n");
    printf("Input Mapping:\n");
    printf("W,A,S,D = Move around based on relative orientation to X and Y.\n");
    printf("SPACE + L-SHIFT = Move up and down relative Z.\n");
    printf("Left Click / R-SHIFT = Place node.\n");
    printf("Right Click / R-CTRL = Delete node.\n");
    printf("V = Places voxel at current position.\n");
    printf("Q / Z / Middle Click / Mouse4 = Clone color of pointed node.\n");
    printf("E / Mouse5 = Replace color of pointed node.\n");
    printf("F = Toggle player fast speed on and off.\n");
    printf("1-7 = Change move speed for selected fast state.\n");
    printf("X + C / Slash + Quote = Scroll color of pointed node.\n");
    printf("R = Toggle mirror brush.\n");
    printf("P = Toggle pitch lock.\n");
    printf("F1 = Resets environment state back to default.\n");
    printf("F2 = Toggle HUD visibility.\n");
    printf("F3 = Save. (auto saves on exit, backup made if idle for 3 mins)\n");
    printf("F8 = Load. (will erase what you have done since the last save)\n");
    printf("\n* Arrow Keys or IJKL can be used to move the view around.\n");
    printf("* Your state is automatically saved on exit.\n");
    printf("\nConsole Arguments:\n");
    printf("./wox <project_name> <[OPTIONAL]mouse_sensitivity> <[OPTIONAL]color_palette_file_path>\n");
    printf("e.g; ./wox Untitled 0.003 /tmp/colors.txt\n");
    printf("1st, \"Untitled\", Name of project to open or create.\n");
    printf("2nd, \"0.003\", Mouse sensitivity.\n");
    printf("3rd, \"/tmp/colors.txt\", path to a color palette file, the file must contain a hex\n");
    printf("color on each new line, 32 colors maximum. e.g; \"#00FFFF\".\n\n");
    printf("To load from file: ./wox loadgz <file_path>\n");
    printf("e.g; ./wox loadgz /home/user/file.wox.gz\n\n");
    printf("To load Base64: ./wox loadb64 <file_path>\n");
    printf("e.g; ./wox loadb64 /home/user/file.b64\n");
    printf("Loaded files are adopted as a project (basename) so F3 / exit can save them.\n\n");
    printf("Keymap: ./wox keymap [path]   (writes default keymap.txt next to the binary)\n");
    printf("Load a keymap: ./wox --keymap-file ./mykeys.txt   (also -k / --keymap / loadkeymap)\n");
    printf("Search order: --keymap-file, then next to the binary, then ./keymap.txt, then appdata\n");
    printf("Format: action  key [key ...]    suffix * = keycode+scancode (e.g. W*)\n\n");
    printf("Threads: ./wox --threads 8 [project]   (also -j / --cores)\n");
    printf("Wayland custom decorations: ./wox --wayland [project]\n");
    printf("e.g; ./wox --wayland Untitled\n");
    printf("Force native decorations: ./wox --no-wayland  (also --x11)\n");
    printf("The flag can appear anywhere on the command line.\n\n");
    printf("To export: ./wox export <project_or_file> <[OPTIONAL]format> <[OPTIONAL]ply_mode> <export_path>\n");
    printf("Formats: wox, txt, vv, ply, b64\n");
    printf("PLY modes: greedy (merged quads, default), quads (one quad per face), tris (two triangles per face)\n");
    printf("e.g; ./wox export Untitled ply ./file.ply\n");
    printf("e.g; ./wox export Untitled ply greedy ./file.ply\n");
    printf("e.g; ./wox export Untitled ply quads ./file.ply\n");
    printf("e.g; ./wox export Untitled ply tris ./file.ply\n");
    printf("e.g; ./wox export ./file.b64 greedy ./file.ply\n");
    printf("e.g; ./wox export ~/file.wox.gz txt ./file.txt\n");
    printf("Format is optional if the output path ends in .ply/.txt/.vv/.b64/.wox.gz\n\n");
    printf("Find more color palettes at; https://lospec.com/palette-list\n");
    printf("You can use any palette up to 32 colors. #000000 (Black) is a valid color.\n\n");
    printf("Default 32 Color Palette: https://lospec.com/palette-list/resurrect-32\n");
    printf("\n----\n");

    // get paths
    basedir = SDL_GetBasePath();
    appdir = SDL_GetPrefPath("voxdsp", "woxel");

    // argv
    char export_path[1024] = {0};
    char source_path[1024] = {0};
    char resolved_src[1024] = {0};
    uint export_type = 0;
    uint ply_mode = 0; // 0 greedy quads, 1 per-face quads, 2 per-face tris
    uint adopt_title = 0;
    uint loaded_ok = 0;
    uint wayland_cli = 0; // 0 auto, 1 force custom decor, 2 force native
    char keymap_cli[1024] = {0};
    {
        int n = 1;
        for(int i = 1; i < argc; i++)
        {
            if(wox_ieq(argv[i], "wayland") || wox_ieq(argv[i], "--wayland") ||
               wox_ieq(argv[i], "-wayland") || wox_ieq(argv[i], "--decor"))
            {
                wayland_cli = 1;
                continue;
            }
            if(wox_ieq(argv[i], "--no-wayland") || wox_ieq(argv[i], "--x11") ||
               wox_ieq(argv[i], "x11") || wox_ieq(argv[i], "--native"))
            {
                wayland_cli = 2;
                continue;
            }
            if(wox_ieq(argv[i], "--fps") || wox_ieq(argv[i], "-fps"))
            {
                show_fps = 1;
                continue;
            }
            if(wox_ieq(argv[i], "--threads") || wox_ieq(argv[i], "-j") ||
               wox_ieq(argv[i], "--cores") || wox_ieq(argv[i], "--cpu"))
            {
                if(i + 1 < argc)
                {
                    sw_cli_threads = atoi(argv[++i]);
                    continue;
                }
            }
            if(wox_ieq(argv[i], "--keymap-file") || wox_ieq(argv[i], "-k") ||
               wox_ieq(argv[i], "--keymap") || wox_ieq(argv[i], "loadkeymap"))
            {
                if(i + 1 < argc)
                {
                    wox_expand_path(keymap_cli, sizeof(keymap_cli), argv[++i]);
                    continue;
                }
            }
            argv[n++] = argv[i];
        }
        argc = n;
    }
    if(argc >= 2 && (wox_ieq(argv[1], "keymap") ||
                     wox_ieq(argv[1], "write-keymap") || wox_ieq(argv[1], "--write-keymap")))
    {
        wox_keymap_write_default((argc >= 3) ? argv[2] : NULL);
        return 0;
    }
    wox_keymap_init(keymap_cli[0] ? keymap_cli : NULL);
    if(argc >= 2 && strlen(argv[1]) < 256)
    {
        sprintf(openTitle, "%s", argv[1]);
    }
    if(argc >= 3 && strcmp(argv[1], "loadgz") == 0 && strlen(argv[2]) < 1024)
    {
        wox_expand_path(source_path, sizeof(source_path), argv[2]);
        adopt_title = 1;
    }
    if(argc >= 3 && strcmp(argv[1], "loadb64") == 0 && strlen(argv[2]) < 1024)
    {
        wox_expand_path(source_path, sizeof(source_path), argv[2]);
        adopt_title = 1;
    }
    if(argc >= 2 && strcmp(argv[1], "export") == 0)
    {
        if(argc < 4)
        {
            printf("ERROR: usage: ./wox export <project_or_file> [wox|txt|vv|ply|b64] [greedy|quads|tris] <export_path>\n");
            printf("       ./wox export ./scene.b64 ./scene.ply\n");
            printf("       ./wox export ./scene.b64 ply quads ./scene.ply\n");
            return 1;
        }
        wox_expand_path(source_path, sizeof(source_path), argv[2]);
        if(argc >= 6)
        {
            int fmt = wox_parse_format(argv[3]);
            const int mode = wox_parse_ply_mode(argv[4]);
            wox_expand_path(export_path, sizeof(export_path), argv[5]);
            if(fmt < 0){fmt = wox_parse_format(argv[5]);}
            if(fmt < 0)
            {
                printf("ERROR: unknown export format '%s' (use wox, txt, vv, ply, or b64)\n", argv[3]);
                return 1;
            }
            export_type = (uint)fmt;
            if(export_type == 3 && mode >= 0){ply_mode = (uint)mode;}
            else if(export_type == 3)
            {
                const int m2 = wox_parse_ply_mode(argv[3]);
                if(m2 >= 0){ply_mode = (uint)m2;}
            }
        }
        else if(argc >= 5)
        {
            int fmt = wox_parse_format(argv[3]);
            const int mode = wox_parse_ply_mode(argv[3]);
            wox_expand_path(export_path, sizeof(export_path), argv[4]);
            if(fmt < 0){fmt = wox_parse_format(argv[4]);}
            if(fmt < 0)
            {
                printf("ERROR: unknown export format '%s' (use wox, txt, vv, ply, greedy, quads, tris, or b64)\n", argv[3]);
                return 1;
            }
            export_type = (uint)fmt;
            if(export_type == 3 && mode >= 0){ply_mode = (uint)mode;}
        }
        else
        {
            wox_expand_path(export_path, sizeof(export_path), argv[3]);
            const int fmt = wox_parse_format(argv[3]);
            if(fmt < 0)
            {
                printf("ERROR: cannot infer format from '%s' — pass ply/txt/vv/b64/wox\n", argv[3]);
                return 1;
            }
            export_type = (uint)fmt;
        }
    }

    // load source (file, sniffed type, or saved project name)
    if(source_path[0] != 0)
    {
        loaded_ok = wox_load_any(source_path, resolved_src, sizeof(resolved_src));
        if(loaded_ok && adopt_title)
        {
            wox_title_from_path(openTitle, sizeof(openTitle), resolved_src[0] ? resolved_src : source_path);
            load_state = 0;
            char tmpad[16];
            timestamp(tmpad);
            printf("[%s] Project name: %s (save path %s%s.wox.gz)\n", tmpad, openTitle, appdir ? appdir : "", openTitle);
        }
    }
    else
    {
        loaded_ok = loadState(openTitle, load_state);
        snprintf(resolved_src, sizeof(resolved_src), "%s", openTitle);
    }
    if(loaded_ok == 0 && export_path[0] != 0)
    {
        printf("ERROR: could not load '%s' for export.\n", source_path[0] ? source_path : openTitle);
        printf("Tried the path as a file (.b64 / .wox.gz) and as a project name.\n");
        return 1;
    }
    if(loaded_ok == 0)
    {
        defaultState(0);
        memset(&g.voxels, 0, max_voxels);
        //
        g.voxels[PTI(64,64,64)] = 1; // center
        g.voxels[PTI(64,64,1)] = 7;
        g.voxels[PTI(1,64,64)] = 3;
        g.voxels[PTI(64,1,64)] = 5;
        g.voxels[PTI(64,64,126)] = 6;
        g.voxels[PTI(126,64,64)] = 2;
        g.voxels[PTI(64,126,64)] = 4;
        //
        g.voxels[PTI(1,1,1)] = 1;
        g.voxels[PTI(126,126,126)] = 1;
        g.voxels[PTI(1,126,126)] = 1;
        g.voxels[PTI(126,126,1)] = 1;
        g.voxels[PTI(126,1,1)] = 1;
        g.voxels[PTI(1,1,126)] = 1;
        g.voxels[PTI(126,1,126)] = 1;
        g.voxels[PTI(1,126,1)] = 1;
        //
        // system palette
        g.colors[0] = 16777215;
        g.colors[1] = 16711680;
        g.colors[2] = 8388608;
        g.colors[3] = 65280;
        g.colors[4] = 32768;
        g.colors[5] = 255;
        g.colors[6] = 128;
        g.pal_n = 32;
        g.st = 8.f;
        // user palette
        g.colors[7] = 16777215;
        g.colors[8] = 16476957;
        g.colors[9] = 15219515;
        g.colors[10] = 8592477;
        g.colors[11] = 12788820;
        g.colors[12] = 15748984;
        g.colors[13] = 16155009;
        g.colors[14] = 16557968;
        g.colors[15] = 14928022;
        g.colors[16] = 11244666;
        g.colors[17] = 9858156;
        g.colors[18] = 6444389;
        g.colors[19] = 4076870;
        g.colors[20] = 745061;
        g.colors[21] = 756367;
        g.colors[22] = 2014323;
        g.colors[23] = 9558889;
        g.colors[24] = 16514950;
        g.colors[25] = 16496980;
        g.colors[26] = 13461565;
        g.colors[27] = 10372409;
        g.colors[28] = 8007749;
        g.colors[29] = 7028341;
        g.colors[30] = 9461417;
        g.colors[31] = 11044083;
        g.colors[32] = 15379949;
        g.colors[33] = 9425919;
        g.colors[34] = 5086182;
        g.colors[35] = 5072308;
        g.colors[36] = 4737655;
        g.colors[37] = 3203513;
        g.colors[38] = 9435362;
        //
        char tmp[16];
        timestamp(tmp);
        printf("[%s] New volumetric canvas created.\n", tmp);
        if(load_state == 0)
            printf("[%s] Created: %s%s.wox.gz\n", tmp, appdir, openTitle);
        else
            printf("[%s] Created: %s\n", tmp, openTitle);
    }
    else
    {
        char tmp[16];
        timestamp(tmp);
        if(load_state == 0)
            printf("[%s] Opened: %s%s.wox.gz\n", tmp, appdir, openTitle);
        else
            printf("[%s] Opened: %s\n", tmp, openTitle);
    }

    //memset(&g.voxels, 8, max_voxels);

    // if this is just an export job then export and quit.
    if(export_path[0] != 0x00)
    {
        if(export_type == 0){saveState(export_path, "", 1);}
        if(export_type == 4){saveBase64(export_path); return 0;}
        if(export_type == 1)
        {
            FILE* f = fopen(export_path, "w");
            if(f != NULL)
            {
                fprintf(f, "# %s %s\n", appTitle, appVersion);
                fprintf(f, "# X Y Z RRGGBB\n");
                for(uchar z = 0; z < 128; z++)
                {
                    for(uchar y = 0; y < 128; y++)
                    {
                        for(uchar x = 0; x < 128; x++)
                        {
                            const uint i = PTI(x,y,z);
                            if(g.voxels[i] < 8){continue;}
                            const uint tu = g.colors[g.voxels[i]-1];
                            uchar r = (tu & 0x00FF0000) >> 16;
                            uchar gc = (tu & 0x0000FF00) >> 8;
                            uchar b = (tu & 0x000000FF);
                            if(r != 0 || gc != 0 || b != 0)
                                fprintf(f, "%i %i %i %02X%02X%02X\n", ((int)x)-64, ((int)y)-64, z, r, gc, b);
                        }
                    }
                }
                fclose(f);
                char tmp[16];
                timestamp(tmp);
                printf("[%s] Exported TXT: %s\n", tmp, export_path);
            }
        }
        if(export_type == 2)
        {
            FILE* f = fopen(export_path, "w");
            if(f != NULL)
            {
                fprintf(f, "# %s %s - Visible Voxels only\n", appTitle, appVersion);
                fprintf(f, "# X Y Z RRGGBB\n");
                for(uchar z = 0; z < 128; z++)
                {
                    for(uchar y = 0; y < 128; y++)
                    {
                        for(uchar x = 0; x < 128; x++)
                        {
                            const uint i = PTI(x,y,z);
                            if(g.voxels[i] < 8){continue;}
                            const uint tu = g.colors[g.voxels[i]-1];
                            uchar r = (tu & 0x00FF0000) >> 16;
                            uchar gc = (tu & 0x0000FF00) >> 8;
                            uchar b = (tu & 0x000000FF);
                            if(r != 0 || gc != 0 || b != 0)
                            {
                                const int nx0 = PTIB((int)x-1, (int)y, (int)z);
                                const int nx1 = PTIB((int)x+1, (int)y, (int)z);
                                const int ny0 = PTIB((int)x, (int)y-1, (int)z);
                                const int ny1 = PTIB((int)x, (int)y+1, (int)z);
                                const int nz0 = PTIB((int)x, (int)y, (int)z-1);
                                const int nz1 = PTIB((int)x, (int)y, (int)z+1);
                                if( nx0 < 0 || ny0 < 0 || nz0 < 0 ||
                                    nx1 < 0 || ny1 < 0 || nz1 < 0 ||
                                    g.voxels[nx0] == 0 ||
                                    g.voxels[nx1] == 0 ||
                                    g.voxels[ny0] == 0 ||
                                    g.voxels[ny1] == 0 ||
                                    g.voxels[nz0] == 0 ||
                                    g.voxels[nz1] == 0 )
                                {
                                    fprintf(f, "%i %i %i %02X%02X%02X\n", ((int)x)-64, ((int)y)-64, z, r, gc, b);
                                }
                            }
                        }
                    }
                }
                fclose(f);
                char tmp[16];
                timestamp(tmp);
                printf("[%s] Exported VV: %s\n", tmp, export_path);
            }
        }
        if(export_type == 3)
        {
            FILE* f = fopen(export_path, "w");
            if(f != NULL)
            {
                const int greedy = (ply_mode == 0);
                const int tris = (ply_mode == 2);
                ply_mem_reset();
                const uint nquad = greedy ? ply_greedy_mesh(NULL, 1) : ply_cube_mesh(NULL, 1);
                const uint vc = nquad * 4;
                const uint nface = tris ? (nquad * 2) : nquad;
                const char* mode_name = greedy ? "greedy" : (tris ? "tris" : "quads");
                fprintf(f, "ply\n");
                fprintf(f, "format ascii 1.0\n");
                fprintf(f, "comment Created by %s %s - woxels.github.io\n", appTitle, appVersion);
                if(greedy)
                    fprintf(f, "comment greedy-meshed quads, same-color faces merged\n");
                else if(tris)
                    fprintf(f, "comment per-voxel-face triangles (two tris per cube face)\n");
                else
                    fprintf(f, "comment per-voxel-face quads\n");
                fprintf(f, "element vertex %u\n", vc);
                fprintf(f, "property float x\n");
                fprintf(f, "property float y\n");
                fprintf(f, "property float z\n");
                fprintf(f, "property float nx\n");
                fprintf(f, "property float ny\n");
                fprintf(f, "property float nz\n");
                fprintf(f, "property uchar red\n");
                fprintf(f, "property uchar green\n");
                fprintf(f, "property uchar blue\n");
                fprintf(f, "element face %u\n", nface);
                fprintf(f, "property list uchar uint vertex_indices\n");
                fprintf(f, "end_header\n");
                ply_mem_flush(f);
                ply_mem_free();
                for(uint i = 0, t = 0; i < nquad; i++)
                {
                    const uint i0 = t++;
                    const uint i1 = t++;
                    const uint i2 = t++;
                    const uint i3 = t++;
                    if(tris)
                    {
                        fprintf(f, "3 %u %u %u\n", i0, i2, i3);
                        fprintf(f, "3 %u %u %u\n", i0, i1, i2);
                    }
                    else
                        fprintf(f, "4 %u %u %u %u\n", i0, i1, i2, i3);
                }
                fclose(f);
                char tmp[16];
                timestamp(tmp);
                if(tris)
                    printf("[%s] Exported PLY: %s (%s, %u tris)\n", tmp, export_path, mode_name, nface);
                else
                    printf("[%s] Exported PLY: %s (%s, %u quads)\n", tmp, export_path, mode_name, nquad);
            }
        }
        return 0;
    }

    // custom mouse sensitivity
    if(argc >= 3)
    {
        g.sens = atof(argv[2]);
        if(g.sens == 0.f){g.sens = 0.003f;}
        char tmp[16];
        timestamp(tmp);
        printf("[%s] Custom mouse sensitivity applied to project \"%s\".\n", tmp, openTitle);
    }

    // load custom palette
    if(argc >= 4){loadColors(argv[3]);}

//*************************************
// window creation
//*************************************
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_EVENTS) < 0)
    {
        printf("ERROR: SDL_Init(): %s\n", SDL_GetError());
        return 1;
    }
    if(wayland_cli == 1 || (wayland_cli == 0 && isWayland() == 1))
    {
        wayland = 1;
        wnd = SDL_CreateWindow(appTitle, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, winw, winh, SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN | SDL_WINDOW_BORDERLESS);
    }
    else
    {
        wayland = 0;
        wnd = SDL_CreateWindow(appTitle, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, winw, winh, SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN);
    }
    if(wnd == NULL)
    {
        printf("ERROR: SDL_CreateWindow(): %s\n", SDL_GetError());
        return 1;
    }
    if(!sw_init(wnd))
        return 1;

    // callback for custom decor
    if(wayland == 1){SDL_SetWindowHitTest(wnd, hitTest, NULL);}

    // set icon
    s_icon = surfaceFromData((Uint32*)&icon, 16, 16);
    SDL_SetWindowIcon(wnd, s_icon);

    // window title
    char nt[512];
    sprintf(nt, "%s - %s", appTitle, openTitle);
    SDL_SetWindowTitle(wnd, nt);

    if(argc >= 2 && strcmp(argv[1], "debug") == 0)
    {
        printf("----\nDEBUG\n----\n");
        printf("----\n");
        printf("tseT_resU aka (xaH)\n");
        printf("gubaton.gro\\resu_tset\n");
        printf("semaJmailliWrehctelF\n");
        printf("buhtig.moc\\dibrm\n");
        printf("----\n");
        SDL_version compiled;
        SDL_version linked;
        SDL_VERSION(&compiled);
        SDL_GetVersion(&linked);
        printf("Compiled against SDL version %u.%u.%u.\n", compiled.major, compiled.minor, compiled.patch);
        printf("Linked against SDL version %u.%u.%u.\n", linked.major, linked.minor, linked.patch);
        printf("----\n");
        printf("currentPath: %s\n", basedir);
        printf("dataPath:    %s\n", appdir);
        printf("----\n");
    }

    // is this an rtx card? (lol don't need this anymore, but an amusing relic non-the-less)
    // if(strstr(glGetString(GL_RENDERER), "RTX") != NULL)
    //     SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_WARNING, "Uh-oh! RTX DETECTED!", "We see that you are using an RTX graphics card.\n\nWe won't stop you using this software but please be aware this program has\nvery poor to basically an unusable experience on RTX graphics cards.\n\n ... ironically.\n\nConsider using Woxel.xyz the Web version or version 1.3 at github.com/woxels/Woxel", wnd);

    WOX_POP(winw, winh);
    updateSelectColor();

//*************************************
// execute update / render loop
//*************************************
    t = fTime();
    while(1){main_loop();}
    return 0;
}
