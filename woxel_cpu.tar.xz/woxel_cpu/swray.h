/*
    swray.h — Woxel software raytracer
    vec/mat + CPU DDA (former esVoxel.h + sw_trace.h)
*/
#ifndef SWRAY_H
#define SWRAY_H

#ifndef _WIN32
	#include <unistd.h>
#endif

#include <math.h>
#include <string.h>
#include <SDL2/SDL.h>

typedef struct { float x,y,z,w; } vec;
typedef struct { float m[4][4]; } mat;

static void vAdd(vec* r, const vec v1, const vec v2)
{
    r->x = v1.x + v2.x; r->y = v1.y + v2.y; r->z = v1.z + v2.z;
}
static void vSub(vec* r, const vec v1, const vec v2)
{
    r->x = v1.x - v2.x; r->y = v1.y - v2.y; r->z = v1.z - v2.z;
}
static void vMulS(vec* r, const vec v1, const float s)
{
    r->x = v1.x * s; r->y = v1.y * s; r->z = v1.z * s;
}
static void vInv(vec* v)
{
    v->x = -v->x; v->y = -v->y; v->z = -v->z;
}
static void vNorm(vec* v)
{
    const float len = 1.f/sqrtf(v->x*v->x + v->y*v->y + v->z*v->z);
    v->x *= len; v->y *= len; v->z *= len;
}

static void mIdent(mat *m)
{
    memset(m, 0x0, sizeof(mat));
    m->m[0][0] = m->m[1][1] = m->m[2][2] = m->m[3][3] = 1.0f;
}
static void mMul(mat *r, const mat *a, const mat *b)
{
    mat tmp;
    for(int i = 0; i < 4; i++)
    {
        tmp.m[i][0] = (a->m[i][0]*b->m[0][0]) + (a->m[i][1]*b->m[1][0]) + (a->m[i][2]*b->m[2][0]) + (a->m[i][3]*b->m[3][0]);
        tmp.m[i][1] = (a->m[i][0]*b->m[0][1]) + (a->m[i][1]*b->m[1][1]) + (a->m[i][2]*b->m[2][1]) + (a->m[i][3]*b->m[3][1]);
        tmp.m[i][2] = (a->m[i][0]*b->m[0][2]) + (a->m[i][1]*b->m[1][2]) + (a->m[i][2]*b->m[2][2]) + (a->m[i][3]*b->m[3][2]);
        tmp.m[i][3] = (a->m[i][0]*b->m[0][3]) + (a->m[i][1]*b->m[1][3]) + (a->m[i][2]*b->m[2][3]) + (a->m[i][3]*b->m[3][3]);
    }
    memcpy(r, &tmp, sizeof(mat));
}
static void mSetRotY(mat *r, const float radians)
{
    const float s = sinf(radians);
    const float c = cosf(radians);
    r->m[0][0] = 1.f; r->m[0][1] = 0.f; r->m[0][2] = 0.f; r->m[0][3] = 0.f;
    r->m[1][0] = 0.f; r->m[1][1] = c;   r->m[1][2] = -s; r->m[1][3] = 0.f;
    r->m[2][0] = 0.f; r->m[2][1] = s;   r->m[2][2] = c;  r->m[2][3] = 0.f;
}
static void mRotZ(mat *r, const float radians)
{
    const float s = sinf(radians);
    const float c = cosf(radians);
    const mat t = { c, -s, 0.f, 0.f,
                    s,  c, 0.f, 0.f,
                    0.f, 0.f, 1.f, 0.f,
                    0.f, 0.f, 0.f, 1.f };
    mMul(r, &t, r);
}
static void mGetViewX(vec *r, const mat matrix)
{
    r->x = -matrix.m[0][0]; r->y = -matrix.m[1][0]; r->z = -matrix.m[2][0];
}
static void mGetViewY(vec *r, const mat matrix)
{
    r->x = -matrix.m[0][1]; r->y = -matrix.m[1][1]; r->z = -matrix.m[2][1];
}
static void mGetViewZ(vec *r, const mat matrix)
{
    r->x = -matrix.m[0][2]; r->y = -matrix.m[1][2]; r->z = -matrix.m[2][2];
}

#pragma GCC diagnostic ignored "-Wunused-result"

SDL_Surface* sHud;
static void flipHud(void) {}
int sw_cli_threads = 0;
int sw_need_occ = 1;


#endif /* SWRAY_H */

#ifdef SWRAY_IMPL
#ifndef SWRAY_IMPL_ONCE
#define SWRAY_IMPL_ONCE

#include <pthread.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>
#if defined(__SSE2__) || defined(__x86_64__)
#include <emmintrin.h>
#define SW_FLUSH_DENORM() do { unsigned _c = _mm_getcsr(); _mm_setcsr(_c | 0x8040u); } while(0)
#else
#define SW_FLUSH_DENORM() ((void)0)
#endif

#ifndef SW_THREADS
#define SW_THREADS 0
#endif
#ifndef SW_MAX_THREADS
#define SW_MAX_THREADS 256
#endif
#define SW_MAX_STEPS 384

static uint32_t *sw_fb = NULL;
static uint32_t *sw_out = NULL;
static uint8_t *sw_tag = NULL;
static int sw_fw = 0, sw_fh = 0;
static volatile int sw_saw_wall = 0;
static SDL_Texture *sw_tex = NULL;
static SDL_Renderer *sw_ren = NULL;

static int sw_nthr = 0;
static pthread_t sw_th[SW_MAX_THREADS];
static volatile int sw_job = 0;
static volatile int sw_done = 0;
static volatile int sw_die = 0;
static volatile int sw_next_y = 0;
static int sw_pool_n = 0;
static int sw_pool_on = 0;

static uint32_t sw_pal[40];
static uint8_t sw_occ[16 * 16 * 16];
static uint8_t sw_occ32[4 * 4 * 4];
static int sw_occ_any = 0;

static void sw_build_occ(void)
{
    memset(sw_occ, 0, sizeof(sw_occ));
    memset(sw_occ32, 0, sizeof(sw_occ32));
    sw_occ_any = 0;
    const uchar *v = g.voxels;
    for(int z = 0; z < 128; z++)
    {
        const int zb8 = (z >> 3) << 8;
        const int zb32 = (z >> 5) << 4;
        for(int y = 0; y < 128; y++)
        {
            const int yb8 = zb8 | ((y >> 3) << 4);
            const int yb32 = zb32 | ((y >> 5) << 2);
            const int row = (z << 14) | (y << 7);
            for(int x = 0; x < 128; x++)
            {
                if(v[row + x])
                {
                    sw_occ[yb8 | (x >> 3)] = 1;
                    sw_occ32[yb32 | (x >> 5)] = 1;
                    sw_occ_any = 1;
                }
            }
        }
    }
    sw_need_occ = 0;
}

/* Leave one empty 8^3 brick by crossing its exit plane, then
   counting the other axes with the same DDA planes (exact). */
static inline int sw_leave_empty8(int *cx, int *cy, int *cz,
                                  float *t, float *tmaxx, float *tmaxy, float *tmaxz,
                                  unsigned *axis,
                                  int stepx, int stepy, int stepz,
                                  float delx, float dely, float delz,
                                  float limit)
{
    const int bx = *cx >> 3, by = *cy >> 3, bz = *cz >> 3;
    const int nx = stepx > 0 ? (((bx + 1) << 3) - *cx) : (*cx - (bx << 3) + 1);
    const int ny = stepy > 0 ? (((by + 1) << 3) - *cy) : (*cy - (by << 3) + 1);
    const int nz = stepz > 0 ? (((bz + 1) << 3) - *cz) : (*cz - (bz << 3) + 1);
    const float tex = *tmaxx + (float)(nx - 1) * delx;
    const float tey = *tmaxy + (float)(ny - 1) * dely;
    const float tez = *tmaxz + (float)(nz - 1) * delz;
    if(tex <= tey && tex <= tez)
    {
        int k = 0;
        for(float u = *tmaxy; u <= tex + 1e-5f && k < 16; u += dely) k++;
        *cy += k * stepy; *tmaxy += (float)k * dely;
        k = 0;
        for(float u = *tmaxz; u <= tex + 1e-5f && k < 16; u += delz) k++;
        *cz += k * stepz; *tmaxz += (float)k * delz;
        *cx = stepx > 0 ? ((bx + 1) << 3) : ((bx << 3) - 1);
        *tmaxx = tex + delx;
        *t = tex;
        *axis = 0;
    }
    else if(tey <= tez)
    {
        int k = 0;
        for(float u = *tmaxx; u <= tey + 1e-5f && k < 16; u += delx) k++;
        *cx += k * stepx; *tmaxx += (float)k * delx;
        k = 0;
        for(float u = *tmaxz; u <= tey + 1e-5f && k < 16; u += delz) k++;
        *cz += k * stepz; *tmaxz += (float)k * delz;
        *cy = stepy > 0 ? ((by + 1) << 3) : ((by << 3) - 1);
        *tmaxy = tey + dely;
        *t = tey;
        *axis = 1;
    }
    else
    {
        int k = 0;
        for(float u = *tmaxx; u <= tez + 1e-5f && k < 16; u += delx) k++;
        *cx += k * stepx; *tmaxx += (float)k * delx;
        k = 0;
        for(float u = *tmaxy; u <= tez + 1e-5f && k < 16; u += dely) k++;
        *cy += k * stepy; *tmaxy += (float)k * dely;
        *cz = stepz > 0 ? ((bz + 1) << 3) : ((bz << 3) - 1);
        *tmaxz = tez + delz;
        *t = tez;
        *axis = 2;
    }
    return (*t >= limit ||
            (unsigned)*cx > 127u || (unsigned)*cy > 127u || (unsigned)*cz > 127u);
}

typedef struct {
    float rox, roy, roz;
    float fx, fy, fz;
    float ux, uy, uz;
    float rx, ry, rz;
    float xscale, yscale;
    float invw, invh;
    int w, h;
    int do_hud;
} sw_cam_t;

static sw_cam_t sw_cam;

static inline uint32_t sw_tint(uint32_t c, unsigned q)
{
    unsigned r = (c & 255u) * q >> 8;
    unsigned g = ((c >> 8) & 255u) * q >> 8;
    unsigned b = ((c >> 16) & 255u) * q >> 8;
    return r | (g << 8) | (b << 16) | 0xFF000000u;
}

static inline uint32_t sw_fetch(int x, int y, int z)
{
    if((unsigned)x > 127u || (unsigned)y > 127u || (unsigned)z > 127u)
        return 0;
    const int idx = (z << 14) + (y << 7) + x;
    __builtin_prefetch(g.voxels + idx + 1, 0, 1);
    const unsigned id = g.voxels[idx];
    return id ? sw_pal[id - 1] : 0;
}

/* Original GLSL volume_bg without the distance fog:
   vec4(screen_pos, blue, 1.0) */
static inline uint32_t sw_screen_bg(float sx, float sy, float blue)
{
    unsigned r = (unsigned)(sx * 255.f + 0.5f);
    unsigned g = (unsigned)(sy * 255.f + 0.5f);
    unsigned b = (unsigned)(blue * 255.f + 0.5f);
    if(r > 255u) r = 255u;
    if(g > 255u) g = 255u;
    if(b > 255u) b = 255u;
    return r | (g << 8) | (b << 16) | 0xFF000000u;
}

static inline uint32_t sw_wall(float sx, float sy, unsigned axis)
{
    const float face = (axis == 0) ? 0.9f : (axis == 2) ? 0.8f : 1.0f;
    return sw_screen_bg(sx * face, sy * face, face);
}

static inline unsigned sw_exit_axis(float texit, float tlgx, float tlgy, float tlgz)
{
    const float ax = fabsf(texit - tlgx);
    const float ay = fabsf(texit - tlgy);
    const float az = fabsf(texit - tlgz);
    if(ax <= ay && ax <= az) return 0;
    if(ay <= az) return 1;
    return 2;
}

static uint32_t sw_trace_one(float rox, float roy, float roz,
                             float rdx, float rdy, float rdz,
                             float sx, float sy, uint8_t *tag)
{
    if(rdx > -1e-8f && rdx < 1e-8f) rdx = (rdx < 0.f) ? -1e-8f : 1e-8f;
    if(rdy > -1e-8f && rdy < 1e-8f) rdy = (rdy < 0.f) ? -1e-8f : 1e-8f;
    if(rdz > -1e-8f && rdz < 1e-8f) rdz = (rdz < 0.f) ? -1e-8f : 1e-8f;

    const float bmin = -0.5f, bmax = 127.5f;
    const float t1x = (bmin - rox) / rdx, t2x = (bmax - rox) / rdx;
    const float t1y = (bmin - roy) / rdy, t2y = (bmax - roy) / rdy;
    const float t1z = (bmin - roz) / rdz, t2z = (bmax - roz) / rdz;
    const float tsmx = t1x < t2x ? t1x : t2x;
    const float tsmy = t1y < t2y ? t1y : t2y;
    const float tsmz = t1z < t2z ? t1z : t2z;
    const float tlgx = t1x > t2x ? t1x : t2x;
    const float tlgy = t1y > t2y ? t1y : t2y;
    const float tlgz = t1z > t2z ? t1z : t2z;
    float tenter = tsmx > tsmy ? tsmx : tsmy;
    if(tsmz > tenter) tenter = tsmz;
    float texit = tlgx < tlgy ? tlgx : tlgy;
    if(tlgz < texit) texit = tlgz;
    if(texit < 0.f || tenter > texit + 1e-5f)
    {
        *tag = 0;
        return sw_screen_bg(sx, sy, 0.5f);
    }
    if(tenter < 0.f) tenter = 0.f;

    if(!sw_occ_any)
    {
        const unsigned face = sw_exit_axis(texit, tlgx, tlgy, tlgz);
        *tag = (uint8_t)(1 + face);
        sw_saw_wall = 1;
        return sw_wall(sx, sy, face);
    }

    const int stepx = rdx >= 0.f ? 1 : -1;
    const int stepy = rdy >= 0.f ? 1 : -1;
    const int stepz = rdz >= 0.f ? 1 : -1;
    const float delx = fabsf(1.f / rdx);
    const float dely = fabsf(1.f / rdy);
    const float delz = fabsf(1.f / rdz);

    float posx = rox + rdx * tenter;
    float posy = roy + rdy * tenter;
    float posz = roz + rdz * tenter;

    int cx = (int)floorf(posx + 0.5f);
    int cy = (int)floorf(posy + 0.5f);
    int cz = (int)floorf(posz + 0.5f);
    if(cx < 0) cx = 0; else if(cx > 127) cx = 127;
    if(cy < 0) cy = 0; else if(cy > 127) cy = 127;
    if(cz < 0) cz = 0; else if(cz > 127) cz = 127;

    float tmaxx = ((float)cx + (stepx > 0 ? 0.5f : -0.5f) - posx) / rdx;
    float tmaxy = ((float)cy + (stepy > 0 ? 0.5f : -0.5f) - posy) / rdy;
    float tmaxz = ((float)cz + (stepz > 0 ? 0.5f : -0.5f) - posz) / rdz;
    float t = 0.f;
    unsigned axis = 1;
    {
        const float adx = fabsf(tenter - tsmx);
        const float ady = fabsf(tenter - tsmy);
        const float adz = fabsf(tenter - tsmz);
        if(adx <= ady && adx <= adz) axis = 0;
        else if(ady <= adz) axis = 1;
        else axis = 2;
        const uint32_t hit = sw_fetch(cx, cy, cz);
        if(hit)
        {
            *tag = 4;
            if(axis == 0) return sw_tint(hit, 230);
            if(axis == 2) return sw_tint(hit, 205);
            return hit;
        }
    }

    for(int i = 0; i < SW_MAX_STEPS; i++)
    {
        if(tmaxx < tmaxy && tmaxx < tmaxz)
        {
            t = tmaxx;
            cx += stepx;
            tmaxx += delx;
            axis = 0;
        }
        else if(tmaxy < tmaxz)
        {
            t = tmaxy;
            cy += stepy;
            tmaxy += dely;
            axis = 1;
        }
        else
        {
            t = tmaxz;
            cz += stepz;
            tmaxz += delz;
            axis = 2;
        }
        if(t >= (texit - tenter) - 1e-4f ||
           (unsigned)cx > 127u || (unsigned)cy > 127u || (unsigned)cz > 127u)
        {
            const unsigned face = sw_exit_axis(texit, tlgx, tlgy, tlgz);
            *tag = (uint8_t)(1 + face);
            sw_saw_wall = 1;
            return sw_wall(sx, sy, face);
        }
        {
            const float limit = (texit - tenter) - 1e-4f;
            int guard = 0;
            while((unsigned)cx < 128u && (unsigned)cy < 128u && (unsigned)cz < 128u &&
                  !sw_occ[((cz >> 3) << 8) | ((cy >> 3) << 4) | (cx >> 3)] &&
                  guard++ < 32)
            {
                if(sw_leave_empty8(&cx, &cy, &cz, &t, &tmaxx, &tmaxy, &tmaxz, &axis,
                                   stepx, stepy, stepz, delx, dely, delz, limit))
                {
                    const unsigned face = sw_exit_axis(texit, tlgx, tlgy, tlgz);
                    *tag = (uint8_t)(1 + face);
                    sw_saw_wall = 1;
                    return sw_wall(sx, sy, face);
                }
            }
        }
        const uint32_t hit = sw_fetch(cx, cy, cz);
        if(hit)
        {
            *tag = 4;
            if(axis == 0) return sw_tint(hit, 230);
            if(axis == 2) return sw_tint(hit, 205);
            return hit;
        }
    }
    {
        const unsigned face = sw_exit_axis(texit, tlgx, tlgy, tlgz);
        *tag = (uint8_t)(1 + face);
        sw_saw_wall = 1;
        return sw_wall(sx, sy, face);
    }
}

static void sw_rows(int tid)
{
    const int w = sw_cam.w;
    const int h = sw_cam.h;
    const float invw = sw_cam.invw;
    const float invh = sw_cam.invh;
    const float yscale = sw_cam.yscale;
    const float xscale = sw_cam.xscale;
    const float rx = sw_cam.rx, ry = sw_cam.ry, rz = sw_cam.rz;
    const float ux = sw_cam.ux, uy = sw_cam.uy, uz = sw_cam.uz;
    const float fx = sw_cam.fx, fy = sw_cam.fy, fz = sw_cam.fz;
    const float rox = sw_cam.rox, roy = sw_cam.roy, roz = sw_cam.roz;
    const float dx_rd = rx * (2.f * invw * xscale);
    const float dy_rd = ry * (2.f * invw * xscale);
    const float dz_rd = rz * (2.f * invw * xscale);

    (void)tid;
    for(;;)
    {
        const int y = __sync_fetch_and_add(&sw_next_y, 1);
        if(y >= h) break;
        const float py = 1.f - 2.f * ((float)y + 0.5f) * invh;
        const float screen_y = ((float)y + 0.5f) * invh;
        const float uy_term = ux * (py * yscale);
        const float vy_term = uy * (py * yscale);
        const float wy_term = uz * (py * yscale);
        float rdx = fx + uy_term + rx * ((-1.f + invw) * xscale);
        float rdy = fy + vy_term + ry * ((-1.f + invw) * xscale);
        float rdz = fz + wy_term + rz * ((-1.f + invw) * xscale);
        float screen_x = 0.5f * invw;
        uint32_t *row = sw_fb + y * w;
        uint8_t *tagrow = sw_tag + y * w;
        for(int x = 0; x < w; x++)
        {
            row[x] = sw_trace_one(rox, roy, roz, rdx, rdy, rdz, screen_x, screen_y, &tagrow[x]);
            rdx += dx_rd; rdy += dy_rd; rdz += dz_rd;
            screen_x += invw;
        }
    }
}

static void *sw_worker(void *arg)
{
    const int tid = (int)(long)arg;
    SW_FLUSH_DENORM();
    int seen = 0;
    while(!sw_die)
    {
        int job = sw_job;
        if(job == seen)
        {
            while(sw_job == seen && !sw_die)
            {
#if defined(__i386__) || defined(__x86_64__)
                __asm__ __volatile__("pause");
#else
                ;
#endif
            }
            if(sw_die) break;
            job = sw_job;
        }
        seen = job;
        sw_rows(tid);
        __sync_add_and_fetch(&sw_done, 1);
    }
    return NULL;
}

static int sw_init(SDL_Window *window)
{
    if(sw_ren) return 1;
    sw_ren = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if(!sw_ren)
        sw_ren = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    if(!sw_ren)
    {
        printf("ERROR: SDL_CreateRenderer(): %s\n", SDL_GetError());
        return 0;
    }
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "0");
    {
        int n = sw_cli_threads;
        if(n <= 0)
        {
            n = SDL_GetCPUCount();
            long n2 = sysconf(_SC_NPROCESSORS_ONLN);
            if(n2 > n) n = (int)n2;
        }
        if(n < 1) n = 1;
        sw_nthr = n;
        if(sw_nthr > SW_MAX_THREADS) sw_nthr = SW_MAX_THREADS;
        printf("swray: %d threads\n", sw_nthr);
    }
    if(sw_nthr < 1) sw_nthr = 1;
    SW_FLUSH_DENORM();
    sw_die = 0;
    sw_job = 0;
    sw_pool_n = sw_nthr > 1 ? sw_nthr - 1 : 0;
    sw_done = sw_pool_n;
    for(int i = 0; i < sw_pool_n; i++)
        pthread_create(&sw_th[i], NULL, sw_worker, (void*)(long)i);
    sw_pool_on = 1;
    return 1;
}

static void sw_resize(int w, int h)
{
    if(w < 1) w = 1;
    if(h < 1) h = 1;
    if(w == sw_fw && h == sw_fh && sw_fb && sw_out && sw_tag && sw_tex) return;
    free(sw_fb);
    free(sw_out);
    free(sw_tag);
    sw_fb = (uint32_t*)malloc((size_t)w * (size_t)h * 4);
    sw_out = (uint32_t*)malloc((size_t)w * (size_t)h * 4);
    sw_tag = (uint8_t*)malloc((size_t)w * (size_t)h);
    sw_fw = w;
    sw_fh = h;
    if(sw_tex){ SDL_DestroyTexture(sw_tex); sw_tex = NULL; }
    if(sw_ren)
        sw_tex = SDL_CreateTexture(sw_ren, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STREAMING, w, h);
}

static void sw_shutdown(void)
{
    if(sw_pool_on)
    {
        sw_die = 1;
        sw_job++;
        for(int i = 0; i < sw_pool_n; i++)
            pthread_join(sw_th[i], NULL);
        sw_pool_on = 0;
    }
    if(sw_tex){ SDL_DestroyTexture(sw_tex); sw_tex = NULL; }
    if(sw_ren){ SDL_DestroyRenderer(sw_ren); sw_ren = NULL; }
    free(sw_fb); sw_fb = NULL;
    free(sw_out); sw_out = NULL;
    free(sw_tag); sw_tag = NULL;
}

static uint32_t sw_hud_sig = 0xFFFFFFFFu;
static int sw_out_ok = 0;
static void sw_blit_hud(void);

static uint32_t sw_hash_hud(void)
{
    if(!sHud || !sHud->pixels) return 0;
    const uint32_t *p = (const uint32_t*)sHud->pixels;
    const int n = sHud->w * sHud->h;
    uint32_t h = (uint32_t)sHud->w * 1664525u + (uint32_t)sHud->h;
    if(n <= 0) return h;
    h ^= p[0];
    h ^= p[n - 1];
    for(int i = 0; i < n; i += 1024)
        h = h * 16777619u ^ p[i];
    return h;
}

static void sw_present(int compose)
{
    (void)compose;
    if(!sw_tex || !sw_ren) return;
    if(!sHud || !sHud->pixels)
    {
        SDL_UpdateTexture(sw_tex, NULL, sw_fb, sw_fw * 4);
        SDL_RenderCopy(sw_ren, sw_tex, NULL, NULL);
        SDL_RenderPresent(sw_ren);
        return;
    }
    sw_blit_hud();
    SDL_UpdateTexture(sw_tex, NULL, sw_out, sw_fw * 4);
    SDL_RenderCopy(sw_ren, sw_tex, NULL, NULL);
    SDL_RenderPresent(sw_ren);
}

static void sw_blit_hud(void)
{
    const int w = sw_fw, h = sw_fh;
    memcpy(sw_out, sw_fb, (size_t)w * (size_t)h * 4);
    if(!sHud || !sHud->pixels) return;
    const int hw = sHud->w, hh = sHud->h, pitch = sHud->pitch;
    const uint8_t *src = (const uint8_t*)sHud->pixels;
    for(int y = 0; y < h; y++)
    {
        const int hy = (int)(((float)y + 0.5f) * (float)hh / (float)h);
        if((unsigned)hy >= (unsigned)hh) continue;
        const uint8_t *hrow = src + hy * pitch;
        uint32_t *dst = sw_out + y * w;
        for(int x = 0; x < w; x++)
        {
            const int hx = (int)(((float)x + 0.5f) * (float)hw / (float)w);
            if((unsigned)hx >= (unsigned)hw) continue;
            const uint32_t hp = *(const uint32_t*)(hrow + hx * 4);
            const unsigned ha = hp >> 24;
            if(!ha) continue;
            if(ha == 255u)
            {
                dst[x] = hp | 0xFF000000u;
                continue;
            }
            const uint32_t col = dst[x];
            const unsigned ia = 255u - ha;
            unsigned r = (col & 255u) * ia + (hp & 255u) * ha;
            unsigned gc = ((col >> 8) & 255u) * ia + ((hp >> 8) & 255u) * ha;
            unsigned b = ((col >> 16) & 255u) * ia + ((hp >> 16) & 255u) * ha;
            dst[x] = (r >> 8) | ((gc >> 8) << 8) | ((b >> 8) << 16) | 0xFF000000u;
        }
    }
}

static void sw_draw_cube_edges(void)
{
    const int w = sw_fw, h = sw_fh;
    if(!sw_tag || !sw_fb) return;
    for(int y = 0; y < h; y++)
    {
        const uint8_t *row = sw_tag + y * w;
        uint32_t *pix = sw_fb + y * w;
        const float sy = ((float)y + 0.5f) / (float)h;
        for(int x = 0; x < w; x++)
        {
            const uint8_t t = row[x];
            if(t < 1 || t > 3) continue;
            int edge = 0;
            if(x > 0) {
                const uint8_t n = row[x-1];
                if(n == 0 || (n >= 1 && n <= 3 && n != t)) edge = 1;
            }
            if(!edge && x+1 < w) {
                const uint8_t n = row[x+1];
                if(n == 0 || (n >= 1 && n <= 3 && n != t)) edge = 1;
            }
            if(!edge && y > 0) {
                const uint8_t n = sw_tag[(y-1)*w + x];
                if(n == 0 || (n >= 1 && n <= 3 && n != t)) edge = 1;
            }
            if(!edge && y+1 < h) {
                const uint8_t n = sw_tag[(y+1)*w + x];
                if(n == 0 || (n >= 1 && n <= 3 && n != t)) edge = 1;
            }
            if(edge)
            {
                const float sx = ((float)x + 0.5f) / (float)w;
                pix[x] = sw_screen_bg(sx, sy, 1.f);
            }
        }
    }
}

static void sw_render(void)
{
    sw_resize(winw, winh);
    const int voxels_changed = sw_need_occ;
    if(sw_need_occ) sw_build_occ();

    static float idle_px, idle_py, idle_pz, idle_xr, idle_yr, idle_xs, idle_ys;
    static float idle_st;
    static int idle_w, idle_h, idle_ok;
    const int same = idle_ok && !voxels_changed &&
        idle_px == g.pp.x && idle_py == g.pp.y && idle_pz == g.pp.z &&
        idle_xr == g.xrot && idle_yr == g.yrot &&
        idle_xs == xscale && idle_ys == yscale &&
        idle_st == g.st && idle_w == sw_fw && idle_h == sw_fh;

    if(same)
    {
        sw_present(0);
        return;
    }

    sw_cam.rox = -g.pp.x;
    sw_cam.roy = -g.pp.y;
    sw_cam.roz = -g.pp.z;
    sw_cam.xscale = xscale;
    sw_cam.yscale = yscale;
    sw_cam.w = sw_fw;
    sw_cam.h = sw_fh;
    sw_cam.invw = 1.f / (float)sw_fw;
    sw_cam.invh = 1.f / (float)sw_fh;
    sw_cam.do_hud = (showhud && sHud != NULL);

    vec v;
    mGetViewX(&v, view);
    sw_cam.rx = -v.x; sw_cam.ry = -v.y; sw_cam.rz = -v.z;
    mGetViewY(&v, view);
    sw_cam.ux = -v.x; sw_cam.uy = -v.y; sw_cam.uz = -v.z;
    mGetViewZ(&v, view);
    sw_cam.fx = v.x; sw_cam.fy = v.y; sw_cam.fz = v.z;

    for(int i = 0; i < 39; i++)
    {
        const uint32_t c = g.colors[i];
        sw_pal[i] = ((c >> 16) & 255u) | (c & 0x0000FF00u) | ((c & 255u) << 16) | 0xFF000000u;
    }

    sw_saw_wall = 0;
    sw_next_y = 0;
    if(!sw_pool_on || sw_pool_n <= 0)
    {
        sw_rows(0);
    }
    else
    {
        sw_done = 0;
        __sync_synchronize();
        sw_job++;
        sw_rows(0);
        while(sw_done < sw_pool_n)
        {
#if defined(__i386__) || defined(__x86_64__)
            __asm__ __volatile__("pause");
#endif
        }
    }

    if(sw_saw_wall)
        sw_draw_cube_edges();

    idle_px = g.pp.x; idle_py = g.pp.y; idle_pz = g.pp.z;
    idle_xr = g.xrot; idle_yr = g.yrot;
    idle_xs = xscale; idle_ys = yscale;
    idle_st = g.st;
    idle_w = sw_fw; idle_h = sw_fh;
    idle_ok = 1;

    sw_present(1);
}

#endif /* SWRAY_IMPL_ONCE */
#endif /* SWRAY_IMPL */
 