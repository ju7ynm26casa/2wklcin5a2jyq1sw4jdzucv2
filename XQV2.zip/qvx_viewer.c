/* qvx_viewer.c
 * GLFW + OpenGL 3.3 core viewer for packed QVX faces (pure C)
 * Orbit camera: left-drag = rotate, scroll or right-drag = zoom
 *
 * Build (Linux):
 *   gcc -std=c11 qvx_viewer.c -o qvx_viewer -lglfw -lGL -ldl -lm
 */

#define GL_GLEXT_PROTOTYPES
#include <GL/gl.h>
#include <GL/glext.h>
#include <GLFW/glfw3.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "qvx_data.h"

/* ---------------------------------------------------------------------------
 * Minimal math
 * --------------------------------------------------------------------------- */
typedef struct { float x, y, z; } Vec3;
typedef struct { float m[16]; } Mat4;

static Mat4 mat4_identity(void) {
    Mat4 r = {0};
    r.m[0] = r.m[5] = r.m[10] = r.m[15] = 1.0f;
    return r;
}

static Mat4 mat4_mul(Mat4 a, Mat4 b) {
    Mat4 r = {0};
    int c, row, k;
    for (c = 0; c < 4; ++c)
        for (row = 0; row < 4; ++row)
            for (k = 0; k < 4; ++k)
                r.m[c * 4 + row] += a.m[k * 4 + row] * b.m[c * 4 + k];
    return r;
}

static Mat4 mat4_perspective(float fovy_rad, float aspect, float znear, float zfar) {
    float f = 1.0f / tanf(fovy_rad * 0.5f);
    Mat4 r = {0};
    r.m[0] = f / aspect;
    r.m[5] = f;
    r.m[10] = (zfar + znear) / (znear - zfar);
    r.m[11] = -1.0f;
    r.m[14] = (2.0f * zfar * znear) / (znear - zfar);
    return r;
}

static Mat4 mat4_look_at(Vec3 eye, Vec3 center, Vec3 up) {
    Vec3 f = { center.x - eye.x, center.y - eye.y, center.z - eye.z };
    float fl = sqrtf(f.x*f.x + f.y*f.y + f.z*f.z);
    f.x /= fl; f.y /= fl; f.z /= fl;

    Vec3 s = { f.y*up.z - f.z*up.y, f.z*up.x - f.x*up.z, f.x*up.y - f.y*up.x };
    float sl = sqrtf(s.x*s.x + s.y*s.y + s.z*s.z);
    s.x /= sl; s.y /= sl; s.z /= sl;

    Vec3 u = { s.y*f.z - s.z*f.y, s.z*f.x - s.x*f.z, s.x*f.y - s.y*f.x };

    Mat4 r = mat4_identity();
    r.m[0] = s.x;  r.m[4] = s.y;  r.m[8]  = s.z;
    r.m[1] = u.x;  r.m[5] = u.y;  r.m[9]  = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -(s.x*eye.x + s.y*eye.y + s.z*eye.z);
    r.m[13] = -(u.x*eye.x + u.y*eye.y + u.z*eye.z);
    r.m[14] =  (f.x*eye.x + f.y*eye.y + f.z*eye.z);
    return r;
}

/* Rotation around X by angle_rad (right-hand) */
static Mat4 mat4_rotate_x(float angle_rad) {
    float c = cosf(angle_rad);
    float s = sinf(angle_rad);
    Mat4 r = mat4_identity();
    r.m[5]  = c;   /* cos */
    r.m[6]  = s;   /* sin */
    r.m[9]  = -s;  /* -sin */
    r.m[10] = c;   /* cos */
    return r;
}

/* ---------------------------------------------------------------------------
 * Camera
 * --------------------------------------------------------------------------- */
typedef struct {
    float yaw, pitch, dist;
    Vec3 target;
} OrbitCamera;

static OrbitCamera g_cam = { 0.6f, 0.4f, 120.0f, {0,0,0} };
static int g_left_down = 0, g_right_down = 0;
static double g_last_x = 0, g_last_y = 0;
static int g_shade_mode = 1;   /* 0=fullbright, 1=voxel, 2=lambertian */

static float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

static Vec3 camera_eye(void) {
    float cp = cosf(g_cam.pitch);
    Vec3 e = {
        g_cam.target.x + g_cam.dist * cp * sinf(g_cam.yaw),
        g_cam.target.y + g_cam.dist * sinf(g_cam.pitch),
        g_cam.target.z + g_cam.dist * cp * cosf(g_cam.yaw)
    };
    return e;
}

static void cursor_pos_callback(GLFWwindow* w, double x, double y) {
    (void)w;
    double dx = x - g_last_x, dy = y - g_last_y;
    g_last_x = x; g_last_y = y;
    if (g_left_down) {
        g_cam.yaw   -= (float)dx * 0.005f;   /* inverted */
        g_cam.pitch += (float)dy * 0.005f;
        g_cam.pitch = clampf(g_cam.pitch, -1.4f, 1.4f);
    }
    if (g_right_down) {
        g_cam.dist += (float)dy * 0.2f;
        g_cam.dist = clampf(g_cam.dist, 2.0f, 500.0f);
    }
}

static void mouse_button_callback(GLFWwindow* w, int button, int action, int mods) {
    (void)mods;
    if (button == GLFW_MOUSE_BUTTON_LEFT)  g_left_down  = (action == GLFW_PRESS);
    if (button == GLFW_MOUSE_BUTTON_RIGHT) g_right_down = (action == GLFW_PRESS);
    if (action == GLFW_PRESS) glfwGetCursorPos(w, &g_last_x, &g_last_y);
}

static void scroll_callback(GLFWwindow* w, double xoff, double yoff) {
    (void)w; (void)xoff;
    g_cam.dist *= (yoff > 0.0) ? 0.9f : 1.1f;
    g_cam.dist = clampf(g_cam.dist, 2.0f, 500.0f);
}

static void key_callback(GLFWwindow* w, int key, int scancode, int action, int mods) {
    (void)w; (void)scancode; (void)mods;
    if (key == GLFW_KEY_P && action == GLFW_PRESS) {
        g_shade_mode = (g_shade_mode + 1) % 3;
        const char* names[] = { "fullbright", "voxel", "lambertian" };
        printf("Shade mode: %s\n", names[g_shade_mode]);
    }
}

/* ---------------------------------------------------------------------------
 * Shaders  (explicit local quad attribute — more reliable than gl_VertexID)
 * --------------------------------------------------------------------------- */
static const char* VERT_SRC =
    "#version 330 core\n"
    "layout(location = 0) in vec2 aLocal;\n"
    "layout(location = 1) in uint aPacked;\n"
    "uniform mat4 uMVP;\n"
    "uniform mat4 uView;\n"
    "uniform vec3 uPalette[32];\n"
    "uniform int  uShadeMode;\n"
    "flat out vec3 vColor;\n"
    "void main() {\n"
    "    uint axis = (aPacked >> 24) & 7u;\n"
    "    vec3 right, up, nrm;\n"
    "    if (axis == 0u) {      nrm = vec3( 1,0,0); right = vec3(0,0,1); up = vec3(0,1,0); }\n"
    "    else if (axis == 1u) { nrm = vec3(-1,0,0); right = vec3(0,0,-1); up = vec3(0,1,0); }\n"
    "    else if (axis == 2u) { nrm = vec3( 0,1,0); right = vec3(1,0,0); up = vec3(0,0,-1); }\n"
    "    else if (axis == 3u) { nrm = vec3( 0,-1,0); right = vec3(1,0,0); up = vec3(0,0,1); }\n"
    "    else if (axis == 4u) { nrm = vec3( 0,0,1); right = vec3(1,0,0); up = vec3(0,1,0); }\n"
    "    else {                 nrm = vec3( 0,0,-1); right = vec3(-1,0,0); up = vec3(0,1,0); }\n"
    "\n"
    "    float x = float(int( aPacked        & 0xFFu) - 128);\n"
    "    float y = float(int((aPacked >>  8) & 0xFFu) - 128);\n"
    "    float z = float(int((aPacked >> 16) & 0xFFu) - 128);\n"
    "    uint pidx = (aPacked >> 27) & 31u;\n"
    "    vec3 baseColor = uPalette[pidx];\n"
    "\n"
    "    vec3 center = vec3(x, y, z) + nrm * 0.5;\n"
    "    vec3 world  = center + right * aLocal.x + up * aLocal.y;\n"
    "    // Shade from face center so both triangles of the quad match\n"
    "    vec4 viewPos4 = uView * vec4(center, 1.0);\n"
    "    vec3 viewPos  = viewPos4.xyz / viewPos4.w;\n"
    "\n"
    "    vec3 finalColor = baseColor;\n"
    "    if (uShadeMode == 1) {\n"
    "        vec3 absN = abs(nrm);\n"
    "        finalColor = (baseColor * 0.95) * absN.x\n"
    "                   +  baseColor         * absN.y\n"
    "                   + (baseColor * 0.975)* absN.z;\n"
    "    } else if (uShadeMode == 2) {\n"
    "        vec3 viewN = normalize(mat3(uView) * nrm);\n"
    "        vec3 toCam = normalize(-viewPos);\n"
    "        float ndotl = dot(viewN, toCam);\n"
    "        float lambert = clamp(ndotl * 0.35 + 0.72, 0.88, 1.0);\n"
    "        vec3 absN = abs(nrm);\n"
    "        vec3 axisColor = (baseColor * 0.95) * absN.x\n"
    "                       +  baseColor         * absN.y\n"
    "                       + (baseColor * 0.975)* absN.z;\n"
    "        finalColor = lambert * axisColor;\n"
    "    }\n"
    "\n"
    "    // Distance darkening for all modes\n"
    "    float fade = clamp(1.0 - length(viewPos) * 0.0008, 0.0, 1.0);\n"
    "    finalColor *= fade;\n"
    "\n"
    "    gl_Position = uMVP * vec4(world, 1.0);\n"
    "    vColor = finalColor;\n"
    "}\n";

static const char* FRAG_SRC =
    "#version 330 core\n"
    "flat in vec3 vColor;\n"
    "out vec4 FragColor;\n"
    "void main() { FragColor = vec4(vColor, 1.0); }\n";

static void check_shader(GLuint s, const char* what) {
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[2048];
        glGetShaderInfoLog(s, sizeof(buf), NULL, buf);
        fprintf(stderr, "%s compile failed:\n%s\n", what, buf);
    }
}

static void check_program(GLuint p) {
    GLint ok = 0;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[2048];
        glGetProgramInfoLog(p, sizeof(buf), NULL, buf);
        fprintf(stderr, "Program link failed:\n%s\n", buf);
    }
}

static void gl_check(const char* where) {
    GLenum err;
    while ((err = glGetError()) != GL_NO_ERROR) {
        fprintf(stderr, "GL error 0x%X at %s\n", err, where);
    }
}

/* ---------------------------------------------------------------------------
 * Main
 * --------------------------------------------------------------------------- */
int main(void) {
    if (!glfwInit()) { fprintf(stderr, "glfwInit failed\n"); return 1; }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    GLFWwindow* win = glfwCreateWindow(1280, 720, "QVX Viewer", NULL, NULL);
    if (!win) { fprintf(stderr, "window failed\n"); glfwTerminate(); return 1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);

    glfwSetCursorPosCallback(win, cursor_pos_callback);
    glfwSetMouseButtonCallback(win, mouse_button_callback);
    glfwSetScrollCallback(win, scroll_callback);
    glfwSetKeyCallback(win, key_callback);

    /* Center on AABB */
    g_cam.target.x = (qvx_aabb_min[0] + qvx_aabb_max[0]) * 0.5f;
    g_cam.target.y = (qvx_aabb_min[1] + qvx_aabb_max[1]) * 0.5f;
    g_cam.target.z = (qvx_aabb_min[2] + qvx_aabb_max[2]) * 0.5f;
    {
        float dx = qvx_aabb_max[0] - qvx_aabb_min[0];
        float dy = qvx_aabb_max[1] - qvx_aabb_min[1];
        float dz = qvx_aabb_max[2] - qvx_aabb_min[2];
        float m = dx; if (dy > m) m = dy; if (dz > m) m = dz;
        g_cam.dist = m * 2.2f;
    }

    printf("AABB min: %.1f %.1f %.1f\n", qvx_aabb_min[0], qvx_aabb_min[1], qvx_aabb_min[2]);
    printf("AABB max: %.1f %.1f %.1f\n", qvx_aabb_max[0], qvx_aabb_max[1], qvx_aabb_max[2]);
    printf("Faces: %d  Palette: %d  Camera dist: %.1f\n",
           QVX_FACE_COUNT, QVX_PALETTE_SIZE, g_cam.dist);

    /* Unit quad (triangle strip) */
    const float quad_local[] = {
        -0.5f, -0.5f,
         0.5f, -0.5f,
        -0.5f,  0.5f,
         0.5f,  0.5f
    };

    GLuint vao, vbo_quad, vbo_faces;
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo_quad);
    glGenBuffers(1, &vbo_faces);

    glBindVertexArray(vao);

    /* local quad corners — not instanced */
    glBindBuffer(GL_ARRAY_BUFFER, vbo_quad);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad_local), quad_local, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, (void*)0);
    glVertexAttribDivisor(0, 0);

    /* packed faces — one per instance */
    glBindBuffer(GL_ARRAY_BUFFER, vbo_faces);
    glBufferData(GL_ARRAY_BUFFER, sizeof(qvx_faces), qvx_faces, GL_STATIC_DRAW);
    glEnableVertexAttribArray(1);
    glVertexAttribIPointer(1, 1, GL_UNSIGNED_INT, sizeof(uint32_t), (void*)0);
    glVertexAttribDivisor(1, 1);

    glBindVertexArray(0);
    gl_check("after VAO setup");

    /* Shaders */
    GLuint vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &VERT_SRC, NULL);
    glCompileShader(vs);
    check_shader(vs, "vertex");

    GLuint fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &FRAG_SRC, NULL);
    glCompileShader(fs);
    check_shader(fs, "fragment");

    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs);
    glAttachShader(prog, fs);
    glLinkProgram(prog);
    check_program(prog);
    glDeleteShader(vs);
    glDeleteShader(fs);
    gl_check("after program");

    GLint loc_mvp  = glGetUniformLocation(prog, "uMVP");
    GLint loc_view = glGetUniformLocation(prog, "uView");
    GLint loc_pal  = glGetUniformLocation(prog, "uPalette");
    GLint loc_mode = glGetUniformLocation(prog, "uShadeMode");
    if (loc_mvp < 0 || loc_pal < 0)
        fprintf(stderr, "Warning: uniform not found (mvp=%d pal=%d)\n", loc_mvp, loc_pal);

    float palette[32][3] = {0};
    int i;
    for (i = 0; i < QVX_PALETTE_SIZE && i < 32; ++i) {
        palette[i][0] = qvx_palette[i][0] / 255.0f;
        palette[i][1] = qvx_palette[i][1] / 255.0f;
        palette[i][2] = qvx_palette[i][2] / 255.0f;
    }

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE);
    /* show both sides */
    glClearColor(0.15f, 0.16f, 0.18f, 1.0f);

    printf("Left-drag: orbit | Scroll / Right-drag: zoom | P: cycle shading\n");

    while (!glfwWindowShouldClose(win)) {
        int w, h;
        glfwGetFramebufferSize(win, &w, &h);
        glViewport(0, 0, w, h);
        float aspect = (h > 0) ? (float)w / (float)h : 1.0f;

        Vec3 eye = camera_eye();
        Mat4 proj = mat4_perspective(50.0f * 3.14159265f / 180.0f, aspect, 0.5f, 2000.0f);
        Mat4 view = mat4_look_at(eye, g_cam.target, (Vec3){0,1,0});
        /* 90° clockwise around X (stands Z-up models upright) */
        Mat4 model = mat4_rotate_x(-90.0f * 3.14159265f / 180.0f);
        Mat4 vp = mat4_mul(proj, view);
        Mat4 mvp = mat4_mul(vp, model);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(prog);
        glUniformMatrix4fv(loc_mvp, 1, GL_FALSE, mvp.m);
        glUniformMatrix4fv(loc_view, 1, GL_FALSE, view.m);
        glUniform3fv(loc_pal, 32, &palette[0][0]);
        glUniform1i(loc_mode, g_shade_mode);

        glBindVertexArray(vao);
        glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, QVX_FACE_COUNT);
        glBindVertexArray(0);

        glfwSwapBuffers(win);
        glfwPollEvents();
    }

    glDeleteProgram(prog);
    glDeleteBuffers(1, &vbo_quad);
    glDeleteBuffers(1, &vbo_faces);
    glDeleteVertexArrays(1, &vao);
    glfwDestroyWindow(win);
    glfwTerminate();
    return 0;
}
