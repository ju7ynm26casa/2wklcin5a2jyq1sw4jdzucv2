#!/usr/bin/env python3
"""
Convert binary PLY (greedy quads, vertex-colored, axis-aligned) to packed QVX C header.
- Detects color palette (≤32 colors)
- Expands greedy quads to unit faces
- Packs each face into a single uint32:
    bits  0-7  : x + 128   (int8 → uint8)
    bits  8-15 : y + 128
    bits 16-23 : z + 128
    bits 24-26 : axis (0-5)
    bits 27-31 : palette index (0-31)
- Emits palette + AABB + packed face array
"""

import struct
import sys
import numpy as np
from pathlib import Path

def normal_to_axis(n):
    if abs(n[0]) > 0.5:
        return 0 if n[0] > 0 else 1
    if abs(n[1]) > 0.5:
        return 2 if n[1] > 0 else 3
    if abs(n[2]) > 0.5:
        return 4 if n[2] > 0 else 5
    raise ValueError(f"Non-axis-aligned normal: {n}")

def parse_ply(path):
    with open(path, "rb") as f:
        while True:
            line = f.readline()
            if not line:
                raise RuntimeError("EOF before end_header")
            if line.strip() == b"end_header":
                break

        # counts from a second pass over header would be cleaner, but we already know format
        # re-open logic kept simple: we rely on known sizes or re-parse
        f.seek(0)
        header = b""
        while True:
            line = f.readline()
            header += line
            if line.strip() == b"end_header":
                break
        header_txt = header.decode("ascii", errors="replace")
        if "binary_little_endian" not in header_txt:
            raise RuntimeError("Only binary_little_endian PLY supported")

        num_verts = num_faces = 0
        for line in header_txt.splitlines():
            if line.startswith("element vertex"):
                num_verts = int(line.split()[-1])
            elif line.startswith("element face"):
                num_faces = int(line.split()[-1])

        vert_size = 27
        verts_raw = f.read(num_verts * vert_size)
        positions = np.zeros((num_verts, 3), dtype=np.float32)
        normals   = np.zeros((num_verts, 3), dtype=np.float32)
        colors    = np.zeros((num_verts, 3), dtype=np.uint8)
        for i in range(num_verts):
            off = i * vert_size
            positions[i] = struct.unpack_from("<3f", verts_raw, off)
            normals[i]   = struct.unpack_from("<3f", verts_raw, off + 12)
            colors[i]    = struct.unpack_from("<3B", verts_raw, off + 24)

        faces = []
        for _ in range(num_faces):
            n = struct.unpack("<B", f.read(1))[0]
            if n != 4:
                raise RuntimeError(f"Expected quads, got {n}-gon")
            faces.append(struct.unpack("<4I", f.read(16)))
        faces = np.array(faces, dtype=np.uint32)

    return positions, normals, colors, faces

def build_palette(colors):
    """Return list of unique RGB tuples and a dict rgb→index. Max 32."""
    # unique rows
    uniq = np.unique(colors, axis=0)
    if len(uniq) > 32:
        raise RuntimeError(f"Palette has {len(uniq)} colors (max 32 supported)")
    palette = [tuple(int(c) for c in row) for row in uniq]
    index = {rgb: i for i, rgb in enumerate(palette)}
    return palette, index

def split_and_pack(positions, normals, colors, faces, palette_index):
    """Return list of packed uint32 faces."""
    packed = []

    for inds in faces:
        pos = positions[inds]
        norm = normals[inds[0]]
        col = tuple(int(c) for c in colors[inds[0]])
        axis = normal_to_axis(norm)
        pidx = palette_index[col]

        const_axis = axis // 2
        var_axes = [i for i in range(3) if i != const_axis]

        mins = pos.min(axis=0)
        maxs = pos.max(axis=0)
        size1 = int(round(float(maxs[var_axes[0]] - mins[var_axes[0]])))
        size2 = int(round(float(maxs[var_axes[1]] - mins[var_axes[1]])))
        if size1 <= 0 or size2 <= 0:
            continue

        start1 = float(mins[var_axes[0]]) + 0.5
        start2 = float(mins[var_axes[1]]) + 0.5
        const_val = float(pos[0, const_axis])

        for i in range(size1):
            for j in range(size2):
                center = [0.0, 0.0, 0.0]
                center[const_axis] = const_val
                center[var_axes[0]] = start1 + i
                center[var_axes[1]] = start2 + j

                # Store base = round(center - 0.5*normal) so shader's +0.5*normal restores exact *.5
                nrm = [0.0, 0.0, 0.0]
                nrm[const_axis] = 1.0 if (axis % 2 == 0) else -1.0
                base = [center[k] - 0.5 * nrm[k] for k in range(3)]
                xyz = [int(np.clip(round(b), -128, 127)) for b in base]
                # pack: x+128 | (y+128)<<8 | (z+128)<<16 | axis<<24 | pidx<<27
                xu = (xyz[0] + 128) & 0xFF
                yu = (xyz[1] + 128) & 0xFF
                zu = (xyz[2] + 128) & 0xFF
                word = (xu) | (yu << 8) | (zu << 16) | (axis << 24) | (pidx << 27)
                packed.append(word)

    return packed

def emit_header(packed, palette, bb_min, bb_max, out_path):
    n = len(packed)
    with open(out_path, "w") as f:
        f.write(f"""#ifndef QVX_DATA_H
#define QVX_DATA_H

#include <stdint.h>

/* Packed QVX faces (unit quads, axis-aligned)
 *
 * uint32 layout:
 *   bits  0- 7 : x + 128   (int8 center, rounded)
 *   bits  8-15 : y + 128
 *   bits 16-23 : z + 128
 *   bits 24-26 : axis      (0=+X,1=-X,2=+Y,3=-Y,4=+Z,5=-Z)
 *   bits 27-31 : palette index (0-31)
 *
 * Face count : {n}
 * Palette    : {len(palette)} colors
 */

#define QVX_FACE_COUNT     {n}
#define QVX_PALETTE_SIZE   {len(palette)}

static const float qvx_aabb_min[3] = {{ {bb_min[0]:.6f}f, {bb_min[1]:.6f}f, {bb_min[2]:.6f}f }};
static const float qvx_aabb_max[3] = {{ {bb_max[0]:.6f}f, {bb_max[1]:.6f}f, {bb_max[2]:.6f}f }};

/* Palette RGB (index = bits 27-31) */
static const uint8_t qvx_palette[QVX_PALETTE_SIZE][3] = {{
""")
        for i, (r, g, b) in enumerate(palette):
            comma = "," if i + 1 < len(palette) else ""
            f.write(f"    {{ {r:3d}, {g:3d}, {b:3d} }}{comma}\n")
        f.write("};\n\n")

        f.write(f"static const uint32_t qvx_faces[QVX_FACE_COUNT] = {{\n")
        for i, w in enumerate(packed):
            f.write(f"    0x{w:08X}u")
            if i + 1 < n:
                f.write(",")
            if (i + 1) % 8 == 0 or i + 1 == n:
                f.write("\n")
            else:
                f.write(" ")
        f.write("};\n\n#endif /* QVX_DATA_H */\n")

def main():
    if len(sys.argv) < 2:
        print("Usage: ply_to_qvx.py input.ply [output.h]", file=sys.stderr)
        sys.exit(1)
    ply_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2]) if len(sys.argv) > 2 else ply_path.with_suffix(".h")

    print(f"Parsing {ply_path} ...")
    positions, normals, colors, faces = parse_ply(ply_path)
    print(f"  vertices: {len(positions)}, greedy faces: {len(faces)}")

    bb_min = positions.min(axis=0)
    bb_max = positions.max(axis=0)

    print("Building palette ...")
    palette, pindex = build_palette(colors)
    print(f"  {len(palette)} unique colors")

    print("Splitting + packing ...")
    packed = split_and_pack(positions, normals, colors, faces, pindex)
    print(f"  unit faces: {len(packed)}")

    print(f"Writing {out_path} ...")
    emit_header(packed, palette, bb_min, bb_max, out_path)
    print("Done.")

if __name__ == "__main__":
    main()
