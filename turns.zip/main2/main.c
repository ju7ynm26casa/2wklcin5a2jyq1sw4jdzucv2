#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>

#define INPUT_DIM 1
#define HIDDEN1 128
#define HIDDEN2 128
#define OUTPUT_DIM 2
#define NUM_EPOCHS 100
#define BATCH_SIZE 256
#define LAMBDA 1.6732632423543772
#define ALPHA 1.7580993408473766
#define LEARNING_RATE 0.002
#define BETA1 0.9
#define BETA2 0.999
#define EPSILON 1e-8
#define NUM_TRAIN_SAMPLES 10000
#define IMAGE_SIZE 400
#define MAX_SPIRAL_POINTS 1000

typedef struct {
    double *weights;
    double *biases;
} Layer;

typedef struct {
    double *weights;
    double *biases;
} LayerGrad;

typedef struct {
    double *m_w;
    double *v_w;
    double *m_b;
    double *v_b;
} AdamState;

static double selu(double x) {
    if (x > 0) return x;
    return LAMBDA * (exp(x) - 1.0);
}

static double selu_grad(double x) {
    if (x > 0) return 1.0;
    return LAMBDA * exp(x);
}

static double rand_double(void) {
    uint32_t u1, u2;
    int fd = open("/dev/urandom", O_RDONLY);
    if (fd < 0) {
        perror("Failed to open /dev/urandom");
        exit(1);
    }
    read(fd, &u1, 4);
    read(fd, &u2, 4);
    close(fd);
    double mantissa = ((double)u1 / 4294967296.0) * 0x1000000 + ((double)(u2 >> 16) / 65536.0);
    double result = mantissa / 9007199254740992.0;
    return result;
}

static void init_layer(Layer *layer, int in_dim, int out_dim) {
    layer->weights = (double *)malloc(in_dim * out_dim * sizeof(double));
    layer->biases = (double *)malloc(out_dim * sizeof(double));
    for (int i = 0; i < out_dim; i++) {
        layer->biases[i] = 0.0;
        for (int j = 0; j < in_dim; j++) {
            double limit = sqrt(6.0 / (in_dim + out_dim));
            layer->weights[i * in_dim + j] = (rand_double() * 2.0 - 1.0) * limit;
        }
    }
}

static void forward_pass(double *input, Layer *l1, Layer *l2, double *output, double *h1, double *h2) {
    for (int i = 0; i < HIDDEN1; i++) {
        double sum = l1->biases[i];
        for (int j = 0; j < INPUT_DIM; j++) {
            sum += l1->weights[i * INPUT_DIM + j] * input[j];
        }
        h1[i] = selu(sum);
    }
    for (int i = 0; i < HIDDEN2; i++) {
        double sum = l2->biases[i];
        for (int j = 0; j < HIDDEN1; j++) {
            sum += l2->weights[i * HIDDEN1 + j] * h1[j];
        }
        h2[i] = selu(sum);
    }
    for (int i = 0; i < OUTPUT_DIM; i++) {
        double sum = 0.0;
        for (int j = 0; j < HIDDEN2; j++) {
            sum += l2->weights[i * HIDDEN2 + j] * h2[j];
        }
        output[i] = sum;
    }
}

static void backward_pass(double *input, double *target, double *output, double *h1, double *h2,
                          Layer *l1, Layer *l2, LayerGrad *g1, LayerGrad *g2) {
    // Zero gradients
    for (int i = 0; i < OUTPUT_DIM * HIDDEN2; i++) g2->weights[i] = 0.0;
    for (int i = 0; i < OUTPUT_DIM; i++) g2->biases[i] = 0.0;
    for (int i = 0; i < HIDDEN1 * INPUT_DIM; i++) g1->weights[i] = 0.0;
    for (int i = 0; i < HIDDEN1; i++) g1->biases[i] = 0.0;

    // Output layer gradients
    double *dh2 = (double *)malloc(HIDDEN2 * sizeof(double));
    for (int i = 0; i < HIDDEN2; i++) {
        double delta = 0.0;
        for (int j = 0; j < OUTPUT_DIM; j++) {
            double d_out = output[j] - target[j]; // MSE derivative: (y - y_hat)
            delta += d_out * l2->weights[j * HIDDEN2 + i];
            // Accumulate gradient for l2 weights and biases
            g2->weights[j * HIDDEN2 + i] += d_out * h2[i];
            g2->biases[j] += d_out;
        }
        dh2[i] = delta * selu_grad(h2[i]);
    }

    // Hidden layer 2 gradients
    for (int i = 0; i < HIDDEN1; i++) {
        double delta = 0.0;
        for (int j = 0; j < HIDDEN2; j++) {
            delta += dh2[j] * l2->weights[j * HIDDEN2 + i];
            g1->weights[i * HIDDEN1 + j] += dh2[j] * h1[i];
            g1->biases[i] += dh2[j] * l2->weights[j * HIDDEN2 + i]; // Wait, this is wrong. 
            // g1->weights[i * HIDDEN1 + j] is weight from h1[i] to h2[j].
            // The gradient for w[i][j] is dh2[j] * h1[i].
            // The gradient for b[i] is sum(dh2[j] * w2[j][i]).
        }
        // Correcting g1->biases[i] calculation
        double grad_b_i = 0.0;
        for (int j = 0; j < HIDDEN2; j++) {
             grad_b_i += dh2[j] * l2->weights[j * HIDDEN2 + i];
        }
        g1->biases[i] = grad_b_i; // Since we zeroed it, we can just assign or add. Assign is fine if we zeroed.
        // Wait, I zeroed g1->biases[i] at the start. So assignment is correct.
    }
    free(dh2);
}

static void adam_update(Layer *layer, LayerGrad *grad, AdamState *state, int in_dim, int out_dim, double lr, int t) {
    double beta1_power = pow(BETA1, t);
    double beta2_power = pow(BETA2, t);
    double lr_t = lr * sqrt(1.0 - beta2_power) / (1.0 - beta1_power);

    for (int i = 0; i < out_dim * in_dim; i++) {
        state->m_w[i] = BETA1 * state->m_w[i] + (1.0 - BETA1) * grad->weights[i];
        state->v_w[i] = BETA2 * state->v_w[i] + (1.0 - BETA2) * grad->weights[i] * grad->weights[i];
        double m_hat = state->m_w[i] / (1.0 - beta1_power);
        double v_hat = state->v_w[i] / (1.0 - beta2_power);
        layer->weights[i] -= lr_t * m_hat / (sqrt(v_hat) + EPSILON);
    }

    for (int i = 0; i < out_dim; i++) {
        state->m_b[i] = BETA1 * state->m_b[i] + (1.0 - BETA1) * grad->biases[i];
        state->v_b[i] = BETA2 * state->v_b[i] + (1.0 - BETA2) * grad->biases[i] * grad->biases[i];
        double m_hat = state->m_b[i] / (1.0 - beta1_power);
        double v_hat = state->v_b[i] / (1.0 - beta2_power);
        layer->biases[i] -= lr_t * m_hat / (sqrt(v_hat) + EPSILON);
    }
}

double get_target_x(double t) {
    double theta = 4.0 * M_PI * t;
    double r = (1.0 + 0.5 * sin(5.0 * theta)) * t;
    return r * cos(theta);
}

double get_target_y(double t) {
    double theta = 4.0 * M_PI * t;
    double r = (1.0 + 0.5 * sin(5.0 * theta)) * t;
    return r * sin(theta);
}

int main() {
    Layer l1, l2;
    LayerGrad g1, g2;
    AdamState s1, s2;

    init_layer(&l1, INPUT_DIM, HIDDEN1);
    init_layer(&l2, HIDDEN1, HIDDEN2); // Wait, l2 input is HIDDEN1, output is OUTPUT_DIM.
    // Re-init l2 correctly
    free(l2.weights); free(l2.biases);
    init_layer(&l2, HIDDEN1, OUTPUT_DIM);

    s1.m_w = (double *)calloc(HIDDEN1 * INPUT_DIM, sizeof(double));
    s1.v_w = (double *)calloc(HIDDEN1 * INPUT_DIM, sizeof(double));
    s1.m_b = (double *)calloc(HIDDEN1, sizeof(double));
    s1.v_b = (double *)calloc(HIDDEN1, sizeof(double));

    s2.m_w = (double *)calloc(OUTPUT_DIM * HIDDEN1, sizeof(double));
    s2.v_w = (double *)calloc(OUTPUT_DIM * HIDDEN1, sizeof(double));
    s2.m_b = (double *)calloc(OUTPUT_DIM, sizeof(double));
    s2.v_b = (double *)calloc(OUTPUT_DIM, sizeof(double));

    double *input = (double *)malloc(INPUT_DIM * sizeof(double));
    double *target = (double *)malloc(OUTPUT_DIM * sizeof(double));
    double *output = (double *)malloc(OUTPUT_DIM * sizeof(double));
    double *h1 = (double *)malloc(HIDDEN1 * sizeof(double));
    double *h2 = (double *)malloc(HIDDEN2 * sizeof(double));

    // Accumulation buffers
    double *grad_l1_w = (double *)calloc(HIDDEN1 * INPUT_DIM, sizeof(double));
    double *grad_l1_b = (double *)calloc(HIDDEN1, sizeof(double));
    double *grad_l2_w = (double *)calloc(OUTPUT_DIM * HIDDEN1, sizeof(double));
    double *grad_l2_b = (double *)calloc(OUTPUT_DIM, sizeof(double));

    struct timeval start_tv, end_tv;
    gettimeofday(&start_tv, NULL);

    double total_loss = 0.0;
    int total_samples = 0;
    int adam_t = 1;

    for (int epoch = 0; epoch < NUM_EPOCHS; epoch++) {
        double epoch_loss = 0.0;
        int epoch_samples = 0;

        for (int i = 0; i < NUM_TRAIN_SAMPLES; i += BATCH_SIZE) {
            int actual_batch_size = NUM_TRAIN_SAMPLES - i;
            if (actual_batch_size > BATCH_SIZE) actual_batch_size = BATCH_SIZE;

            // Zero accumulation buffers
            memset(grad_l1_w, 0, HIDDEN1 * INPUT_DIM * sizeof(double));
            memset(grad_l1_b, 0, HIDDEN1 * sizeof(double));
            memset(grad_l2_w, 0, OUTPUT_DIM * HIDDEN1 * sizeof(double));
            memset(grad_l2_b, 0, OUTPUT_DIM * sizeof(double));

            for (int j = 0; j < actual_batch_size; j++) {
                int idx = i + j;
                double param = (double)idx / (NUM_TRAIN_SAMPLES - 1);
                input[0] = param;
                target[0] = get_target_x(param);
                target[1] = get_target_y(param);

                forward_pass(input, &l1, &l2, output, h1, h2);
                
                double loss = 0.5 * pow(output[0] - target[0], 2) + 0.5 * pow(output[1] - target[1], 2);
                epoch_loss += loss;
                epoch_samples++;
                total_samples++;

                // Calculate gradients for this sample
                // We need a temporary gradient buffer or modify backward_pass to accumulate.
                // Let's create a helper to get gradients for one sample into temp buffers
                double *temp_g1_w = (double *)calloc(HIDDEN1 * INPUT_DIM, sizeof(double));
                double *temp_g1_b = (double *)calloc(HIDDEN1, sizeof(double));
                double *temp_g2_w = (double *)calloc(OUTPUT_DIM * HIDDEN1, sizeof(double));
                double *temp_g2_b = (double *)calloc(OUTPUT_DIM, sizeof(double));
                
                LayerGrad temp_g1, temp_g2;
                temp_g1.weights = temp_g1_w; temp_g1.biases = temp_g1_b;
                temp_g2.weights = temp_g2_w; temp_g2.biases = temp_g2_b;

                backward_pass(input, target, output, h1, h2, &l1, &l2, &temp_g1, &temp_g2);

                // Accumulate
                for (int k = 0; k < HIDDEN1 * INPUT_DIM; k++) grad_l1_w[k] += temp_g1_w[k];
                for (int k = 0; k < HIDDEN1; k++) grad_l1_b[k] += temp_g1_b[k];
                for (int k = 0; k < OUTPUT_DIM * HIDDEN1; k++) grad_l2_w[k] += temp_g2_w[k];
                for (int k = 0; k < OUTPUT_DIM; k++) grad_l2_b[k] += temp_g2_b[k];

                free(temp_g1_w); free(temp_g1_b);
                free(temp_g2_w); free(temp_g2_b);
            }

            // Average gradients
            for (int k = 0; k < HIDDEN1 * INPUT_DIM; k++) grad_l1_w[k] /= actual_batch_size;
            for (int k = 0; k < HIDDEN1; k++) grad_l1_b[k] /= actual_batch_size;
            for (int k = 0; k < OUTPUT_DIM * HIDDEN1; k++) grad_l2_w[k] /= actual_batch_size;
            for (int k = 0; k < OUTPUT_DIM; k++) grad_l2_b[k] /= actual_batch_size;

            // Update layers
            LayerGrad avg_g1, avg_g2;
            avg_g1.weights = grad_l1_w; avg_g1.biases = grad_l1_b;
            avg_g2.weights = grad_l2_w; avg_g2.biases = grad_l2_b;

            adam_update(&l1, &avg_g1, &s1, INPUT_DIM, HIDDEN1, LEARNING_RATE, adam_t);
            adam_update(&l2, &avg_g2, &s2, HIDDEN1, OUTPUT_DIM, LEARNING_RATE, adam_t);
            adam_t++;

            total_loss += epoch_loss;
        }
        
        if (epoch % 10 == 0) {
            double current_loss = total_loss / total_samples;
            printf("Epoch %d, Loss: %f\n", epoch, current_loss);
        }
    }

    gettimeofday(&end_tv, NULL);
    double total_time = (end_tv.tv_sec - start_tv.tv_sec) + (end_tv.tv_usec - start_tv.tv_usec) / 1e6;
    double avg_epoch_time = total_time / NUM_EPOCHS;
    double final_loss = total_loss / total_samples;

    printf("Training Time: %.4f s\n", total_time);
    printf("Average Epoch Time: %.4f s\n", avg_epoch_time);
    printf("Final Loss: %f\n", final_loss);

    // Generate PGM image
    FILE *fp = fopen("spiral.pgm", "wb");
    if (!fp) {
        perror("Failed to open file");
        return 1;
    }
    fprintf(fp, "P5\n%d %d\n255\n", IMAGE_SIZE, IMAGE_SIZE);

    // Find bounds of the spiral to normalize
    double min_x = 1e9, max_x = -1e9, min_y = 1e9, max_y = -1e9;
    for (int i = 0; i < MAX_SPIRAL_POINTS; i++) {
        double t = (double)i / (MAX_SPIRAL_POINTS - 1);
        double x = get_target_x(t);
        double y = get_target_y(t);
        if (x < min_x) min_x = x;
        if (x > max_x) max_x = x;
        if (y < min_y) min_y = y;
        if (y > max_y) max_y = y;
    }
    
    double range_x = max_x - min_x;
    double range_y = max_y - min_y;
    double scale = 0.8 * IMAGE_SIZE / fmax(range_x, range_y);
    double offset_x = (IMAGE_SIZE - range_x * scale) / 2.0;
    double offset_y = (IMAGE_SIZE - range_y * scale) / 2.0;

    unsigned char *image = (unsigned char *)malloc(IMAGE_SIZE * IMAGE_SIZE);
    memset(image, 0, IMAGE_SIZE * IMAGE_SIZE);

    for (int i = 0; i < MAX_SPIRAL_POINTS; i++) {
        double t = (double)i / (MAX_SPIRAL_POINTS - 1);
        input[0] = t;
        forward_pass(input, &l1, &l2, output, h1, h2);
        
        double x = output[0];
        double y = output[1];
        
        int px = (int)((x - min_x) * scale + offset_x);
        int py = (int)((IMAGE_SIZE - 1 - (y - min_y) * scale - offset_y)); // Flip Y for image coords
        
        if (px >= 0 && px < IMAGE_SIZE && py >= 0 && py < IMAGE_SIZE) {
            image[py * IMAGE_SIZE + px] = 255;
        }
    }

    fwrite(image, 1, IMAGE_SIZE * IMAGE_SIZE, fp);
    fclose(fp);
    printf("Saved spiral.pgm\n");

    return 0;
}