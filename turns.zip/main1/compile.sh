#!/bin/sh
gcc -o main -Ofast -march=native main.c -lm
