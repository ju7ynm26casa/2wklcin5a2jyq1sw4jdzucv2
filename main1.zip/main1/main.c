#include <immintrin.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define H1 512
#define H2 512
#define H3 512
#define OUT 2
#define BATCH 4096
#define EPOCHS 50000
#define ALPHA 1.673263242354377f
#define SCALE 1.0507009873554805f
#define SALPHA (SCALE * ALPHA)
#define NPARAMS (1 * H1 + H1 + H1 * H2 + H2 + H2 * H3 + H3 + H3 * OUT + OUT)
#define NTRAIN 65536
typedef struct
{
    float *x, *y;
    int n;
} Data;
static double get_time()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static float frand(unsigned *seed)
{
    unsigned x;
    FILE *f = fopen("/dev/urandom", "r");
    fread(&x, 4, 1, f);
    fclose(f);
    x ^= *seed;
    *seed = x;
    for (int i = 0; i < 10; i++)
    {
        x ^= x << 13;
        x ^= x >> 17;
        x ^= x << 5;
    }
    return (x & 0x7FFFFFFF) / 2147483647.0f * 2.f - 1.f;
}
static float randn(unsigned *seed)
{
    float u1, u2;
    do
    {
        u1 = frand(seed) * 0.5f + 0.5f;
    } while (u1 < 1e-6f);
    u2 = frand(seed) * 0.5f + 0.5f;
    return sqrtf(-2.f * logf(u1)) * cosf(2.f * M_PI * u2);
}
typedef struct
{
    int in, out;
    float *w, *b, *mw, *mb, *vw, *vb;
} Layer;
static void layer_init(Layer *L, int in, int out, unsigned *seed)
{
    L->in = in;
    L->out = out;
    int nw = in * out;
    L->w = (float *)aligned_alloc(32, nw * sizeof(float));
    L->b = (float *)aligned_alloc(32, out * sizeof(float));
    L->mw = (float *)aligned_alloc(32, nw * sizeof(float));
    L->mb = (float *)aligned_alloc(32, out * sizeof(float));
    L->vw = (float *)aligned_alloc(32, nw * sizeof(float));
    L->vb = (float *)aligned_alloc(32, out * sizeof(float));
    float std = sqrtf(1.0f / in);
    for (int i = 0; i < nw; i++)
        L->w[i] = randn(seed) * std;
    for (int i = 0; i < out; i++)
        L->b[i] = 0;
    memset(L->mw, 0, nw * sizeof(float));
    memset(L->mb, 0, out * sizeof(float));
    memset(L->vw, 0, nw * sizeof(float));
    memset(L->vb, 0, out * sizeof(float));
}
static void selu_fwd(float *in, int n, float *out)
{
    int i = 0;
    __m256 zero = _mm256_setzero_ps(), scale = _mm256_set1_ps(SCALE), sal = _mm256_set1_ps(SALPHA),
           one = _mm256_set1_ps(1.f);
    for (; i + 8 <= n; i += 8)
    {
        __m256 x = _mm256_load_ps(in + i);
        __m256 pos = _mm256_mul_ps(scale, x);
        __m256 expv = _mm256_exp_ps(x);
        __m256 neg = _mm256_mul_ps(sal, _mm256_sub_ps(expv, one));
        __m256 mask = _mm256_cmp_ps(x, zero, _CMP_GT_OQ);
        _mm256_store_ps(out + i, _mm256_blendv_ps(neg, pos, mask));
    }
    for (; i < n; i++)
    {
        if (in[i] > 0)
            out[i] = SCALE * in[i];
        else
            out[i] = SALPHA * (expf(in[i]) - 1.f);
    }
}
static void selu_bwd(float *post, int n, float *grad)
{
    int i = 0;
    __m256 zero = _mm256_setzero_ps(), scale = _mm256_set1_ps(SCALE), sal = _mm256_set1_ps(SALPHA);
    for (; i + 8 <= n; i += 8)
    {
        __m256 a = _mm256_load_ps(post + i);
        __m256 mask = _mm256_cmp_ps(a, zero, _CMP_GT_OQ);
        __m256 d = _mm256_add_ps(a, sal);
        _mm256_store_ps(grad + i, _mm256_blendv_ps(d, scale, mask));
    }
    for (; i < n; i++)
    {
        if (post[i] > 0)
            grad[i] = SCALE;
        else
            grad[i] = post[i] + SALPHA;
    }
}
static void matmul(float *A, float *B, float *C, int m, int k, int n)
{
    memset(C, 0, m * n * sizeof(float));
    int i = 0;
    for (; i < m; i += 4)
    {
        for (int j = 0; j < n; j += 8)
        {
            __m256 c0 = _mm256_setzero_ps(), c1 = _mm256_setzero_ps(), c2 = _mm256_setzero_ps(),
                   c3 = _mm256_setzero_ps();
            for (int p = 0; p < k; p++)
            {
                __m256 b = _mm256_load_ps(B + p * n + j);
                c0 = _mm256_fmadd_ps(_mm256_set1_ps(A[i * k + p]), b, c0);
                c1 = _mm256_fmadd_ps(_mm256_set1_ps(A[(i + 1) * k + p]), b, c1);
                c2 = _mm256_fmadd_ps(_mm256_set1_ps(A[(i + 2) * k + p]), b, c2);
                c3 = _mm256_fmadd_ps(_mm256_set1_ps(A[(i + 3) * k + p]), b, c3);
            }
            _mm256_store_ps(C + i * n + j, c0);
            _mm256_store_ps(C + (i + 1) * n + j, c1);
            _mm256_store_ps(C + (i + 2) * n + j, c2);
            _mm256_store_ps(C + (i + 3) * n + j, c3);
        }
        for (int j = n / 8 * 8; j < n; j++)
            for (int p = 0; p < k; p++)
            {
                C[i * n + j] += A[i * k + p] * B[p * n + j];
                C[(i + 1) * n + j] += A[(i + 1) * k + p] * B[p * n + j];
                C[(i + 2) * n + j] += A[(i + 2) * k + p] * B[p * n + j];
                C[(i + 3) * n + j] += A[(i + 3) * k + p] * B[p * n + j];
            }
        for (; i < m; i++)
            for (int j = 0; j < n; j++)
            {
                float s = 0;
                for (int p = 0; p < k; p++)
                    s += A[i * k + p] * B[p * n + j];
                C[i * n + j] = s;
            }
    }
    static void matmul_t(float *A, float *B, float *C, int m, int k, int n)
    {
        memset(C, 0, m * n * sizeof(float));
        for (int i = 0; i < m; i++)
            for (int j = 0; j < n; j++)
            {
                float s = 0;
                for (int p = 0; p < k; p++)
                    s += A[p * m + i] * B[p * n + j];
                C[i * n + j] = s;
            }
    }
    static float adam_step(Layer * L, float lr, float b1, float b2, float eps, int t)
    {
        int nw = L->in * L->out;
        float *wp = L->w, *mp = L->mw, *vp = L->vw, *bp = L->b, *mb = L->mb, *vb = L->vb;
        float bc1 = 1.f - powf(b1, t), bc2 = 1.f - powf(b2, t);
        int i = 0;
        __m256 vlr = _mm256_set1_ps(lr / bc1), vbc2 = _mm256_set1_ps(1.f / bc2),
               v1mb1 = _mm256_set1_ps(1.f - b1), v1mb2 = _mm256_set1_ps(1.f - b2),
               veps = _mm256_set1_ps(eps);
        for (; i + 8 <= nw; i += 8)
        {
            __m256 g = _mm256_load_ps(wp + nw + i);
            _mm256_store_ps(
                mp + i, _mm256_fmadd_ps(g, v1mb1,
                                        _mm256_mul_ps(_mm256_load_ps(mp + i), _mm256_set1_ps(b1))));
            _mm256_store_ps(
                vp + i, _mm256_fmadd_ps(_mm256_mul_ps(g, g), v1mb2,
                                        _mm256_mul_ps(_mm256_load_ps(vp + i), _mm256_set1_ps(b2))));
            __m256 m = _mm256_load_ps(mp + i);
            __m256 v = _mm256_load_ps(vp + i);
            __m256 denom = _mm256_add_ps(_mm256_sqrt_ps(_mm256_mul_ps(v, vbc2)), veps);
            _mm256_store_ps(wp + i, _mm256_fmsub_ps(m, denom, _mm256_load_ps(wp + i)));
        }
        for (; i < nw; i++)
        {
            float g = wp[nw + i];
            mp[i] = b1 * mp[i] + (1 - b1) * g;
            vp[i] = b2 * vp[i] + (1 - b2) * g * g;
            wp[i] -= lr / bc1 * mp[i] / (sqrtf(vp[i] / bc2) + eps);
        }
        for (i = 0; i < L->out; i++)
        {
            float g = bp[L->out + i];
            mb[i] = b1 * mb[i] + (1 - b1) * g;
            vb[i] = b2 * vb[i] + (1 - b2) * g * g;
            bp[i] -= lr / bc1 * mb[i] / (sqrtf(vb[i] / bc2) + eps);
        }
        return 0;
    }
    static void set_grad(Layer * L, float *gw, float *gb)
    {
        memcpy(L->w + L->in * L->out, gw, L->in * L->out * sizeof(float));
        memcpy(L->b + L->out, gb, L->out * sizeof(float));
    }
    int main()
    {
        double t0 = get_time();
        unsigned seed = 0;
        Layer l1, l2, l3, l4;
        layer_init(&l1, 1, H1, &seed);
        layer_init(&l2, H1, H2, &seed);
        layer_init(&l3, H2, H3, &seed);
        layer_init(&l4, H3, OUT, &seed);
        float *X = (float *)aligned_alloc(32, NTRAIN * sizeof(float));
        float *Y = (float *)aligned_alloc(32, NTRAIN * 2 * sizeof(float));
        for (int i = 0; i < NTRAIN; i++)
        {
            float t = (float)i / NTRAIN;
            X[i] = t;
            Y[i * 2] = t * cosf(6 * M_PI * t);
            Y[i * 2 + 1] = t * sinf(6 * M_PI * t);
        }
        int nbatch = NTRAIN / BATCH;
        float *bx = (float *)aligned_alloc(32, BATCH * sizeof(float));
        float *by = (float *)aligned_alloc(32, BATCH * 2 * sizeof(float));
        float *z1 = (float *)aligned_alloc(32, BATCH * H1 * sizeof(float));
        float *a1 = (float *)aligned_alloc(32, BATCH * H1 * sizeof(float));
        float *z2 = (float *)aligned_alloc(32, BATCH * H2 * sizeof(float));
        float *a2 = (float *)aligned_alloc(32, BATCH * H2 * sizeof(float));
        float *z3 = (float *)aligned_alloc(32, BATCH * H3 * sizeof(float));
        float *a3 = (float *)aligned_alloc(32, BATCH * H3 * sizeof(float));
        float *z4 = (float *)aligned_alloc(32, BATCH * OUT * sizeof(float));
        float *a4 = (float *)aligned_alloc(32, BATCH * OUT * sizeof(float));
        float *dz4 = (float *)aligned_alloc(32, BATCH * OUT * sizeof(float));
        float *dz3 = (float *)aligned_alloc(32, BATCH * H3 * sizeof(float));
        float *dz2 = (float *)aligned_alloc(32, BATCH * H2 * sizeof(float));
        float *dz1 = (float *)aligned_alloc(32, BATCH * H1 * sizeof(float));
        float *da1 = (float *)aligned_alloc(32, BATCH * H1 * sizeof(float));
        float *da2 = (float *)aligned_alloc(32, BATCH * H2 * sizeof(float));
        float *da3 = (float *)aligned_alloc(32, BATCH * H3 * sizeof(float));
        float *gw1 = (float *)aligned_alloc(32, 1 * H1 * sizeof(float));
        float *gb1 = (float *)aligned_alloc(32, H1 * sizeof(float));
        float *gw2 = (float *)aligned_alloc(32, H1 * H2 * sizeof(float));
        float *gb2 = (float *)aligned_alloc(32, H2 * sizeof(float));
        float *gw3 = (float *)aligned_alloc(32, H2 * H3 * sizeof(float));
        float *gb3 = (float *)aligned_alloc(32, H3 * sizeof(float));
        float *gw4 = (float *)aligned_alloc(32, H3 * OUT * sizeof(float));
        float *gb4 = (float *)aligned_alloc(32, OUT * sizeof(float));
        float *bxh = (float *)aligned_alloc(32, BATCH * 1 * sizeof(float));
        int step = 0;
        float total_loss = 0;
        int nsteps = 0;
        float lr_base = 3e-3;
        double train_start = get_time();
        for (int e = 0; e < EPOCHS; e++)
        {
            double et = get_time();
            if (et - t0 > 620)
                break;
            float lr = lr_base * (1.f + cosf(M_PI * (float)e / EPOCHS)) * 0.5f;
            for (int b = 0; b < nbatch; b++)
            {
                step++;
                int off = b * BATCH;
                memcpy(bx, X + off, BATCH * sizeof(float));
                memcpy(by, Y + off * 2, BATCH * 2 * sizeof(float));
                matmul(bx, l1.w, z1, BATCH, 1, H1);
                for (int i = 0; i < BATCH; i++)
                    for (int j = 0; j < H1; j++)
                        z1[i * H1 + j] += l1.b[j];
                selu_fwd(z1, BATCH * H1, a1);
                matmul(a1, l2.w, z2, BATCH, H1, H2);
                for (int i = 0; i < BATCH; i++)
                    for (int j = 0; j < H2; j++)
                        z2[i * H2 + j] += l2.b[j];
                selu_fwd(z2, BATCH * H2, a2);
                matmul(a2, l3.w, z3, BATCH, H2, H3);
                for (int i = 0; i < BATCH; i++)
                    for (int j = 0; j < H3; j++)
                        z3[i * H3 + j] += l3.b[j];
                selu_fwd(z3, BATCH * H3, a3);
                matmul(a3, l4.w, z4, BATCH, H3, OUT);
                for (int i = 0; i < BATCH; i++)
                    for (int j = 0; j < OUT; j++)
                        z4[i * OUT + j] += l4.b[j];
                float loss = 0;
                for (int i = 0; i < BATCH * OUT; i++)
                {
                    float d = z4[i] - by[i];
                    loss += d * d;
                    dz4[i] = 2.f * d / BATCH;
                }
                total_loss += loss / BATCH;
                nsteps++;
                matmul_t(a3, dz4, gw3 + 0, 0, 0, 0);
                memset(gw4, 0, H3 * OUT * sizeof(float));
                matmul_t(a3, dz4, gw4, BATCH, H3, OUT);
                for (int j = 0; j < OUT; j++)
                {
                    float s = 0;
                    for (int i = 0; i < BATCH; i++)
                        s += dz4[i * OUT + j];
                    gb4[j] = s;
                }
                selu_bwd(a3, BATCH * H3, da3);
                for (int i = 0; i < BATCH * H3; i++)
                    dz3[i] = da3[i];
                matmul_t(a2, dz3, gw3, BATCH, H2, H3);
                for (int j = 0; j < H3; j++)
                {
                    float s = 0;
                    for (int i = 0; i < BATCH; i++)
                        s += dz3[i * H3 + j];
                    gb3[j] = s;
                }
                matmul(dz3, l3.w, da2, BATCH, H3, H2);
                selu_bwd(a2, BATCH * H2, dz2);
                for (int i = 0; i < BATCH * H2; i++)
                    dz2[i] *= da2[i];
                matmul_t(a1, dz2, gw2, BATCH, H1, H2);
                for (int j = 0; j < H2; j++)
                {
                    float s = 0;
                    for (int i = 0; i < BATCH; i++)
                        s += dz2[i * H2 + j];
                    gb2[j] = s;
                }
                matmul(dz2, l2.w, da1, BATCH, H2, H1);
                selu_bwd(a1, BATCH * H1, dz1);
                for (int i = 0; i < BATCH * H1; i++)
                    dz1[i] *= da1[i];
                matmul_t(bx, dz1, gw1, BATCH, 1, H1);
                for (int j = 0; j < H1; j++)
                {
                    float s = 0;
                    for (int i = 0; i < BATCH; i++)
                        s += dz1[i * H1 + j];
                    gb1[j] = s;
                }
                set_grad(&l1, gw1, gb1);
                set_grad(&l2, gw2, gb2);
                set_grad(&l3, gw3, gb3);
                set_grad(&l4, gw4, gb4);
                adam_step(&l1, lr, 0.9f, 0.999f, 1e-7f, step);
                adam_step(&l2, lr, 0.9f, 0.999f, 1e-7f, step);
                adam_step(&l3, lr, 0.9f, 0.999f, 1e-7f, step);
                adam_step(&l4, lr, 0.9f, 0.999f, 1e-7f, step);
            }
            if (e % 500 == 0)
            {
                double el = get_time() - train_start;
                printf("Epoch %d | Loss: %.8f | Time: %.1fs | LR: %.6f\n", e, total_loss / nsteps,
                       el, lr);
                fflush(stdout);
            }
        }
        double train_end = get_time();
        printf("\n=== Training Complete ===\n");
        printf("Total training time: %.2fs\n", train_end - train_start);
        printf("Epochs completed: %d\n", e);
        printf("Total steps: %d\n", nsteps);
        printf("Avg epoch time: %.4fs\n", (train_end - train_start) / e);
        printf("Final avg loss (MSE): %.10f\n", total_loss / nsteps);
        float *px = (float *)aligned_alloc(32, 1024);
        float *py = (float *)aligned_alloc(32, 1024);
        float *tx = (float *)aligned_alloc(32, 1024);
        float *ty = (float *)aligned_alloc(32, 1024);
        int NPT = 1024;
        for (int i = 0; i < NPT; i++)
        {
            float t = (float)i / (NPT - 1);
            tx[i] = t * cosf(6 * M_PI * t);
            ty[i] = t * sinf(6 * M_PI * t);
        }
        {
            float *inp = (float *)aligned_alloc(32, NPT * sizeof(float));
            for (int i = 0; i < NPT; i++)
                inp[i] = (float)i / (NPT - 1);
            float *o1 = (float *)aligned_alloc(32, NPT * H1 * sizeof(float));
            float *o2 = (float *)aligned_alloc(32, NPT * H2 * sizeof(float));
            float *o3 = (float *)aligned_alloc(32, NPT * H3 * sizeof(float));
            float *o4 = (float *)aligned_alloc(32, NPT * OUT * sizeof(float));
            matmul(inp, l1.w, o1, NPT, 1, H1);
            for (int i = 0; i < NPT * H1; i++)
                o1[i] += l1.b[i % H1];
            selu_fwd(o1, NPT * H1, o1);
            matmul(o1, l2.w, o2, NPT, H1, H2);
            for (int i = 0; i < NPT * H2; i++)
                o2[i] += l2.b[i % H2];
            selu_fwd(o2, NPT * H2, o2);
            matmul(o2, l3.w, o3, NPT, H2, H3);
            for (int i = 0; i < NPT * H3; i++)
                o3[i] += l3.b[i % H3];
            selu_fwd(o3, NPT * H3, o3);
            matmul(o3, l4.w, o4, NPT, H3, OUT);
            for (int i = 0; i < NPT * OUT; i++)
                o4[i] += l4.b[i % OUT];
            for (int i = 0; i < NPT; i++)
            {
                px[i] = o4[i * 2];
                py[i] = o4[i * 2 + 1];
            }
        }
        float mse = 0;
        for (int i = 0; i < NPT; i++)
        {
            float dx = px[i] - tx[i], dy = py[i] - ty[i];
            mse += dx * dx + dy * dy;
        }
        mse /= NPT;
        printf("Test MSE (1024 pts): %.10f\n", mse);
        printf("Max abs error X: %.6f\n", 0.f);
        float maxex = 0, maxey = 0;
        for (int i = 0; i < NPT; i++)
        {
            float ex = fabsf(px[i] - tx[i]), ey = fabsf(py[i] - ty[i]);
            if (ex > maxex)
                maxex = ex;
            if (ey > maxey)
                maxey = ey;
        }
        printf("Max abs error X: %.6f\n", maxex);
        printf("Max abs error Y: %.6f\n", maxey);
        int IMG = 512;
        unsigned char *img = (unsigned char *)malloc(IMG * IMG);
        memset(img, 255, IMG * IMG);
        float xmin = -1.1, xmax = 1.1, ymin = -1.1, ymax = 1.1;
        for (int i = 0; i < NPT; i++)
        {
            int ix = (int)((tx[i] - xmin) / (xmax - xmin) * (IMG - 1));
            int iy = (int)((ty[i] - ymin) / (ymax - ymin) * (IMG - 1));
            if (ix >= 0 && ix < IMG && iy >= 0 && iy < IMG)
                img[iy * IMG + ix] = 0;
        }
        for (int i = 0; i < NPT; i++)
        {
            int ix = (int)((px[i] - xmin) / (xmax - xmin) * (IMG - 1));
            int iy = (int)((py[i] - ymin) / (ymax - ymin) * (IMG - 1));
            if (ix >= 0 && ix < IMG && iy >= 0 && iy < IMG)
            {
                int p = (IMG - 1 - iy) * IMG + ix;
                img[p] = 200;
            }
        }
        FILE *fp = fopen("spiral.pgm", "wb");
        fprintf(fp, "P5\n%d %d\n255\n", IMG, IMG);
        fwrite(img, 1, IMG * IMG, fp);
        fclose(fp);
        printf("Image saved to spiral.pgm\n");
        printf("Total program time: %.2fs\n", get_time() - t0);
        return 0;
    }