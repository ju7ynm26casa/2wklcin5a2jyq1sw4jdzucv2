#include <fcntl.h>
#include <immintrin.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#define N 4096
#define HH 128
#define LL 128
#define OO 2
#define LR0 0.001f
#define BETA1 0.9f
#define BETA2 0.999f
#define EPS 1e-8f
#define LAM 1.0507009873554805f
#define LALP 1.7596061304156786f
#define TURNS 4.0f
#define TIME_LIMIT 600.0
#define CLIP 0.3f
static float xd[N], yd[N][2];
static float W1[HH], B1[HH], W2[LL * HH], B2[LL], W3[OO * LL], B3[OO];
static float mw1[HH], vw1[HH], mb1[HH], vb1[HH];
static float mw2[LL * HH], vw2[LL * HH], mb2[LL], vb2[LL];
static float mw3[OO * LL], vw3[OO * LL], mb3[OO], vb3[OO];
static float H1[N][HH], H2[N][LL], P[N][OO];
static float dH1[N][HH], dH2[N][LL], dP[N][OO];
static float gW1[HH], gB1[HH], gW2[LL * HH], gB2[LL], gW3[OO * LL], gB3[OO];
static float bW1[HH], bB1[HH], bW2[LL * HH], bB2[LL], bW3[OO * LL], bB3[OO];
static inline float selu(float x)
{
    return x > 0.0f ? LAM * x : LALP * (expf(x) - 1.0f);
}
static unsigned int rng[4];
static float randf()
{
    unsigned int *u = rng;
    u[0] ^= u[0] << 13;
    u[0] ^= u[0] >> 17;
    u[0] ^= u[0] << 5;
    return (u[0] >> 8) * 1.0f / 16777216.0f;
}
static float randn()
{
    float u1 = randf(), u2 = randf();
    if (u1 < 1e-7f)
        u1 = 1e-7f;
    return sqrtf(-2.0f * logf(u1)) * cosf(6.2831853f * u2);
}
static double now()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static void gen_data()
{
    for (int i = 0; i < N; i++)
    {
        float t = (float)i / (N - 1);
        xd[i] = t;
        float th = 6.2831853f * TURNS * t;
        float r = 0.05f + 0.95f * t;
        yd[i][0] = r * cosf(th);
        yd[i][1] = r * sinf(th);
    }
}
static void init_weights()
{
    int fd = open("/dev/urandom", O_RDONLY);
    read(fd, rng, 16);
    close(fd);
    for (int i = 0; i < HH; i++)
        W1[i] = randn();
    for (int i = 0; i < HH; i++)
        B1[i] = 0;
    float s2 = sqrtf(1.0f / (float)HH);
    for (int i = 0; i < LL * HH; i++)
        W2[i] = randn() * s2;
    for (int i = 0; i < LL; i++)
        B2[i] = 0;
    float s3 = sqrtf(1.0f / (float)LL);
    for (int i = 0; i < OO * LL; i++)
        W3[i] = randn() * s3;
    for (int i = 0; i < OO; i++)
        B3[i] = 0;
}
static void fwd()
{
    for (int i = 0; i < N; i++)
    {
        float xi = xd[i];
        for (int j = 0; j < HH; j++)
            H1[i][j] = selu(B1[j] + xi * W1[j]);
        for (int j = 0; j < LL; j++)
        {
            __m256 vs = _mm256_setzero_ps();
            for (int k = 0; k < HH; k += 8)
                vs = _mm256_fmadd_ps(_mm256_loadu_ps(&W2[j * HH + k]), _mm256_loadu_ps(&H1[i][k]),
                                     vs);
            float t8[8];
            _mm256_storeu_ps(t8, vs);
            H2[i][j] = selu(B2[j] + t8[0] + t8[1] + t8[2] + t8[3] + t8[4] + t8[5] + t8[6] + t8[7]);
        }
        for (int j = 0; j < OO; j++)
        {
            __m256 vs = _mm256_setzero_ps();
            for (int k = 0; k < LL; k += 8)
                vs = _mm256_fmadd_ps(_mm256_loadu_ps(&W3[j * LL + k]), _mm256_loadu_ps(&H2[i][k]),
                                     vs);
            float t8[8];
            _mm256_storeu_ps(t8, vs);
            P[i][j] = B3[j] + t8[0] + t8[1] + t8[2] + t8[3] + t8[4] + t8[5] + t8[6] + t8[7];
        }
    }
}
static void bwd()
{
    __m256 vzero = _mm256_setzero_ps(), vlam = _mm256_set1_ps(LAM), vlalp = _mm256_set1_ps(LALP);
    for (int i = 0; i < N; i++)
    {
        dP[i][0] = P[i][0] - yd[i][0];
        dP[i][1] = P[i][1] - yd[i][1];
        for (int j = 0; j < LL; j++)
        {
            float g = dP[i][0] * W3[j] + dP[i][1] * W3[LL + j];
            float a = H2[i][j];
            dH2[i][j] = g * (a > 0.0f ? LAM : a + LALP);
        }
        for (int j = 0; j < HH; j += 8)
        {
            __m256 vg = _mm256_setzero_ps();
            for (int k = 0; k < LL; k++)
            {
                __m256 vk = _mm256_set1_ps(dH2[i][k]);
                vg = _mm256_fmadd_ps(vk, _mm256_loadu_ps(&W2[k * HH + j]), vg);
            }
            __m256 vh = _mm256_loadu_ps(&H1[i][j]);
            __m256 vm = _mm256_cmp_ps(vh, vzero, _CMP_GT_OQ);
            __m256 vd = _mm256_blendv_ps(_mm256_fmadd_ps(vh, vlalp, vlam), vlam, vm);
            _mm256_storeu_ps(&dH1[i][j], _mm256_mul_ps(vg, vd));
        }
    }
}
static void accum()
{
    memset(gW1, 0, sizeof(gW1));
    memset(gB1, 0, sizeof(gB1));
    memset(gW2, 0, sizeof(gW2));
    memset(gB2, 0, sizeof(gB2));
    memset(gW3, 0, sizeof(gW3));
    memset(gB3, 0, sizeof(gB3));
    for (int i = 0; i < N; i++)
    {
        gB3[0] += dP[i][0];
        gB3[1] += dP[i][1];
        for (int k = 0; k < LL; k += 8)
        {
            __m256 v0 = _mm256_set1_ps(dP[i][0]), v1 = _mm256_set1_ps(dP[i][1]),
                   vh = _mm256_loadu_ps(&H2[i][k]);
            _mm256_storeu_ps(&gW3[k], _mm256_fmadd_ps(v0, vh, _mm256_loadu_ps(&gW3[k])));
            _mm256_storeu_ps(&gW3[LL + k], _mm256_fmadd_ps(v1, vh, _mm256_loadu_ps(&gW3[LL + k])));
        }
        for (int j = 0; j < LL; j++)
        {
            float dh = dH2[i][j];
            gB2[j] += dh;
            __m256 vd = _mm256_set1_ps(dh);
            for (int k = 0; k < HH; k += 8)
                _mm256_storeu_ps(&gW2[j * HH + k],
                                 _mm256_fmadd_ps(vd, _mm256_loadu_ps(&H1[i][k]),
                                                 _mm256_loadu_ps(&gW2[j * HH + k])));
        }
        for (int j = 0; j < HH; j += 8)
        {
            __m256 vd = _mm256_loadu_ps(&dH1[i][j]), vxi = _mm256_set1_ps(xd[i]);
            _mm256_storeu_ps(&gW1[j], _mm256_fmadd_ps(vd, vxi, _mm256_loadu_ps(&gW1[j])));
            _mm256_storeu_ps(&gB1[j], _mm256_add_ps(vd, _mm256_loadu_ps(&gB1[j])));
        }
    }
}
static void clip_grads()
{
    float total = 0;
    for (int i = 0; i < HH; i++)
        total += gW1[i] * gW1[i] + gB1[i] * gB1[i];
    for (int i = 0; i < LL * HH; i++)
        total += gW2[i] * gW2[i];
    for (int i = 0; i < LL; i++)
        total += gB2[i] * gB2[i];
    for (int i = 0; i < OO * LL; i++)
        total += gW3[i] * gW3[i];
    for (int i = 0; i < OO; i++)
        total += gB3[i] * gB3[i];
    float norm = sqrtf(total / (float)N);
    if (norm > CLIP)
    {
        float scale = CLIP / norm;
        for (int i = 0; i < HH; i++)
        {
            gW1[i] *= scale;
            gB1[i] *= scale;
        }
        for (int i = 0; i < LL * HH; i++)
            gW2[i] *= scale;
        for (int i = 0; i < LL; i++)
            gB2[i] *= scale;
        for (int i = 0; i < OO * LL; i++)
            gW3[i] *= scale;
        for (int i = 0; i < OO; i++)
            gB3[i] *= scale;
    }
}
static void adam(int t, float lr)
{
    float c1 = 1.0f - powf(1.0f - BETA1, (float)t), c2 = 1.0f - powf(1.0f - BETA2, (float)t);
    float lr_t = lr * sqrtf(c2) / c1, bc1 = 1.0f - BETA1, bc2 = 1.0f - BETA2,
          invN = 1.0f / (float)N, invN2 = invN * invN;
    for (int i = 0; i < HH; i++)
    {
        mw1[i] = BETA1 * mw1[i] + bc1 * gW1[i] * invN;
        vw1[i] = BETA2 * vw1[i] + bc2 * gW1[i] * gW1[i] * invN2;
        W1[i] -= lr_t * mw1[i] / (sqrtf(vw1[i]) + EPS);
        mb1[i] = BETA1 * mb1[i] + bc1 * gB1[i] * invN;
        vb1[i] = BETA2 * vb1[i] + bc2 * gB1[i] * gB1[i] * invN2;
        B1[i] -= lr_t * mb1[i] / (sqrtf(vb1[i]) + EPS);
    }
    for (int i = 0; i < LL * HH; i++)
    {
        mw2[i] = BETA1 * mw2[i] + bc1 * gW2[i] * invN;
        vw2[i] = BETA2 * vw2[i] + bc2 * gW2[i] * gW2[i] * invN2;
        W2[i] -= lr_t * mw2[i] / (sqrtf(vw2[i]) + EPS);
    }
    for (int i = 0; i < LL; i++)
    {
        mb2[i] = BETA1 * mb2[i] + bc1 * gB2[i] * invN;
        vb2[i] = BETA2 * vb2[i] + bc2 * gB2[i] * gB2[i] * invN2;
        B2[i] -= lr_t * mb2[i] / (sqrtf(vb2[i]) + EPS);
    }
    for (int i = 0; i < OO * LL; i++)
    {
        mw3[i] = BETA1 * mw3[i] + bc1 * gW3[i] * invN;
        vw3[i] = BETA2 * vw3[i] + bc2 * gW3[i] * gW3[i] * invN2;
        W3[i] -= lr_t * mw3[i] / (sqrtf(vw3[i]) + EPS);
    }
    for (int i = 0; i < OO; i++)
    {
        mb3[i] = BETA1 * mb3[i] + bc1 * gB3[i] * invN;
        vb3[i] = BETA2 * vb3[i] + bc2 * gB3[i] * gB3[i] * invN2;
        B3[i] -= lr_t * mb3[i] / (sqrtf(vb3[i]) + EPS);
    }
}
static float loss()
{
    float s = 0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < OO; j++)
        {
            float e = P[i][j] - yd[i][j];
            s += e * e;
        }
    return s / (N * OO);
}
static void save_best()
{
    memcpy(bW1, W1, sizeof(W1));
    memcpy(bB1, B1, sizeof(B1));
    memcpy(bW2, W2, sizeof(W2));
    memcpy(bB2, B2, sizeof(B2));
    memcpy(bW3, W3, sizeof(W3));
    memcpy(bB3, B3, sizeof(B3));
}
static void load_best()
{
    memcpy(W1, bW1, sizeof(W1));
    memcpy(B1, bB1, sizeof(B1));
    memcpy(W2, bW2, sizeof(W2));
    memcpy(B2, bB2, sizeof(B2));
    memcpy(W3, bW3, sizeof(W3));
    memcpy(B3, bB3, sizeof(B3));
}
static void save_pgm()
{
    int W = 512, Hh = 512;
    unsigned char *img = malloc(W * Hh);
    memset(img, 255, W * Hh);
    for (int i = 0; i < N; i++)
    {
        float px = (P[i][0] + 1.0f) * 0.5f * (W - 1),
              py = (1.0f - (P[i][1] + 1.0f) * 0.5f) * (Hh - 1);
        int ix = (int)(px + 0.5f), iy = (int)(py + 0.5f);
        for (int dy = -1; dy <= 1; dy++)
            for (int dx = -1; dx <= 1; dx++)
            {
                int nx = ix + dx, ny = iy + dy;
                if (nx >= 0 && nx < W && ny >= 0 && ny < Hh)
                    img[ny * W + nx] = 0;
            }
    }
    FILE *f = fopen("spiral.pgm", "wb");
    fprintf(f, "P5\n%d %d\n255\n", W, Hh);
    fwrite(img, 1, W * Hh, f);
    fclose(f);
    free(img);
}
int main()
{
    double t0 = now();
    gen_data();
    init_weights();
    printf("Arch: 1-%d-%d-%d | SELU | Adam | LeCunNormal | Clip=%.2f\n", HH, LL, OO, CLIP);
    printf("N=%d LR0=%f Cosine | TimeLimit=%.0fs\n", N, (double)LR0, TIME_LIMIT);
    fflush(stdout);
    double ep_total = 0;
    int ae = 0;
    float best_loss = 1e9f;
    int best_epoch = 0;
    int MAX_E = 1000000;
    for (int e = 1; e <= MAX_E; e++)
    {
        double et = now();
        fwd();
        bwd();
        accum();
        clip_grads();
        float lr = LR0 * 0.5f * (1.0f + cosf(3.14159265f * (float)e / (float)MAX_E));
        adam(e, lr);
        double el = now() - et;
        ep_total += el;
        ae = e;
        float l = loss();
        if (l < best_loss)
        {
            best_loss = l;
            best_epoch = e;
            save_best();
        }
        double elapsed = now() - t0;
        if (elapsed > TIME_LIMIT)
        {
            printf("Time limit hit at epoch %d\n", e);
            break;
        }
        if (e <= 3 || e % 10000 == 0)
        {
            printf("Epoch %7d | Loss: %.8e | RMSE: %.6f | Best: %.8e@%d | LR: %.6f | Elapsed: "
                   "%6.2fs | EpochTime: %.4fs\n",
                   e, l, sqrtf(l), best_loss, best_epoch, lr, elapsed, el);
            fflush(stdout);
        }
    }
    load_best();
    fwd();
    float fl = loss();
    float rmse = sqrtf(fl);
    double tt = now() - t0;
    double avg = ep_total / ae;
    printf("\n=== Results ===\n");
    printf("Total training time: %.4f s\n", tt);
    printf("Average epoch time: %.6f s\n", avg);
    printf("Epochs completed: %d\n", ae);
    printf("Best loss: %.10e at epoch %d\n", best_loss, best_epoch);
    printf("Final MSE (best weights): %.10e\n", fl);
    printf("Final RMSE: %.10e\n", rmse);
    printf("Accuracy 1/(1+RMSE): %.8f\n", 1.0f / (1.0f + rmse));
    printf("Arch: 1-%d-%d-%d | N=%d | LR0=%f | Clip=%.2f\n", HH, LL, OO, N, (double)LR0, CLIP);
    save_pgm();
    printf("Saved spiral.pgm\n");
    return 0;
}