#!/bin/sh
gcc -o main main.c -march=native -Ofast -lm
