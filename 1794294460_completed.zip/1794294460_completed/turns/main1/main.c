#include <fcntl.h>
#include <immintrin.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#define N 4096
#define H 128
#define L2 128
#define OUT 2
#define LR 0.001f
#define BETA1 0.9f
#define BETA2 0.999f
#define EPS 1e-8f
#define EPOCHS 50000
#define LAM 1.0507009873554805f
#define ALP 1.6732632423543773f
#define TURNS 4.0
static float x_data[N], y_data[N][2];
static float w1[H], b1[H], w2[L2 * H], b2[L2], w3[OUT * L2], b3[OUT];
static float m_w1[H], v_w1[H], m_b1[H], v_b1[H];
static float m_w2[L2 * H], v_w2[L2 * H], m_b2[L2], v_b2[L2];
static float m_w3[OUT * L2], v_w3[OUT * L2], m_b3[OUT], v_b3[OUT];
static float h1[N][H], h2[N][L2], pred[N][OUT];
static float d1[N][H], d2[N][L2], d3[N][OUT];
static float gw1[H], gb1[H], gw2[L2 * H], gb2[L2], gw3[OUT * L2], gb3[OUT];
static float selu(float x)
{
    return x > 0.0f ? LAM * x : LAM * ALP * (expf(x) - 1.0f);
}
static float selu_deriv_post(float a)
{
    return a > 0.0f ? LAM : a + LAM * ALP;
}
static void load_rand(void *buf, int sz)
{
    int fd = open("/dev/urandom", O_RDONLY);
    read(fd, buf, sz);
    close(fd);
}
static float randf(void *st)
{
    unsigned int *u = (unsigned int *)st;
    u[0] ^= u[0] << 13;
    u[0] ^= u[0] >> 17;
    u[0] ^= u[0] << 5;
    return (u[0] >> 8) * 1.0f / 16777216.0f;
}
static float randn(void *st)
{
    float u1 = randf(st), u2 = randf(st);
    if (u1 < 1e-7f)
        u1 = 1e-7f;
    return sqrtf(-2.0f * logf(u1)) * cosf(2.0f * 3.14159265f * u2);
}
static double now()
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static void gen_data()
{
    for (int i = 0; i < N; i++)
    {
        float t = (float)i / (N - 1);
        x_data[i] = t;
        float th = 2.0f * 3.14159265f * TURNS * t;
        float r = 0.05f + 0.95f * t;
        y_data[i][0] = r * cosf(th);
        y_data[i][1] = r * sinf(th);
    }
}
static void init_weights()
{
    unsigned int seed[4];
    load_rand(seed, 16);
    float s1 = sqrtf(1.0f / 1.0f);
    for (int i = 0; i < H; i++)
        w1[i] = randn(seed) * s1;
    for (int i = 0; i < H; i++)
        b1[i] = 0;
    float s2 = sqrtf(1.0f / (float)H);
    for (int i = 0; i < L2 * H; i++)
        w2[i] = randn(seed) * s2;
    for (int i = 0; i < L2; i++)
        b2[i] = 0;
    float s3 = sqrtf(1.0f / (float)L2);
    for (int i = 0; i < OUT * L2; i++)
        w3[i] = randn(seed) * s3;
    for (int i = 0; i < OUT; i++)
        b3[i] = 0;
}
static void forward()
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < H; j++)
        {
            float s = b1[j];
            for (int k = 0; k < 1; k++)
                s += x_data[i] * w1[j];
            h1[i][j] = selu(s);
        }
        for (int j = 0; j < L2; j++)
        {
            float s = b2[j];
            __m256 vs = _mm256_set1_ps(s);
            __m256 vx = _mm256_set1_ps(x_data[i]);
            for (int k = 0; k < H; k += 8)
            {
                __m256 w = _mm256_loadu_ps(&w2[j * H + k]);
                __m256 a = _mm256_loadu_ps(&h1[i][k]);
                vs = _mm256_fmadd_ps(w, a, vs);
            }
            _mm256_storeu_ps(&h1[i][0], vs);
            float tmp[8];
            _mm256_storeu_ps(tmp, vs);
            s = tmp[0] + tmp[1] + tmp[2] + tmp[3] + tmp[4] + tmp[5] + tmp[6] + tmp[7];
            h1[i][j] = selu(s);
            // oops this is wrong, let me redo
        }
    }
    // Actually let me just do scalar for correctness first, optimize later
}
// Let me rewrite cleanly
#undef N
#undef H
#undef L2
#define N 4096
#define HH 128
#define LL 128
#define OO 2
static float xd[N], yd[N][2];
static float W1[HH], B1[HH], W2[LL * HH], B2[LL], W3[OO * LL], B3[OO];
static float mw1[HH], vw1[HH], mb1[HH], vb1[HH];
static float mw2[LL * HH], vw2[LL * HH], mb2[LL], vb2[LL];
static float mw3[OO * LL], vw3[OO * LL], mb3[OO], vb3[OO];
static float H1[N][HH], H2[N][LL], P[N][OO];
static float dH1[N][HH], dH2[N][LL], dP[N][OO];
static float gW1[HH], gB1[HH], gW2[LL * HH], gB2[LL], gW3[OO * LL], gB3[OO];
static void fwd()
{
    for (int i = 0; i < N; i++)
    {
        float xi = xd[i];
        for (int j = 0; j < HH; j++)
        {
            float s = B1[j] + xi * W1[j];
            H1[i][j] = selu(s);
        }
        for (int j = 0; j < LL; j++)
        {
            float s = B2[j];
            for (int k = 0; k < HH; k++)
                s += H1[i][k] * W2[j * HH + k];
            H2[i][j] = selu(s);
        }
        for (int j = 0; j < OO; j++)
        {
            float s = B3[j];
            for (int k = 0; k < LL; k++)
                s += H2[i][k] * W3[j * LL + k];
            P[i][j] = s;
        }
    }
}
static void bwd()
{
    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < OO; j++)
            dP[i][j] = P[i][j] - yd[i][j];
        for (int j = 0; j < LL; j++)
        {
            float g = 0;
            for (int k = 0; k < OO; k++)
                g += dP[i][k] * W3[k * LL + j];
            dH2[i][j] = g * selu_deriv_post(H2[i][j]);
        }
        for (int j = 0; j < HH; j++)
        {
            float g = 0;
            for (int k = 0; k < LL; k++)
                g += dH2[i][k] * W2[k * HH + j];
            dH1[i][j] = g * selu_deriv_post(H1[i][j]);
        }
    }
}
static float loss()
{
    float s = 0;
    for (int i = 0; i < N; i++)
        for (int j = 0; j < OO; j++)
        {
            float e = P[i][j] - yd[i][j];
            s += e * e;
        }
    return s / (N * OO);
}
static void adam(int t)
{
    float c1 = 1 - powf(1 - LR, t), c2 = 1 - powf(1 - BETA2, t);
    float lr_t = LR * sqrtf(c2) / c1;
    for (int i = 0; i < HH; i++)
    {
        mw1[i] = BETA1 * mw1[i] + (1 - BETA1) * gW1[i] / N;
        vw1[i] = BETA2 * vw1[i] + (1 - BETA2) * gW1[i] * gW1[i] / (N * N);
        W1[i] -= lr_t * mw1[i] / (sqrtf(vw1[i]) + EPS);
    }
    for (int i = 0; i < HH; i++)
    {
        mb1[i] = BETA1 * mb1[i] + (1 - BETA1) * gB1[i] / N;
        vb1[i] = BETA2 * vb1[i] + (1 - BETA2) * gB1[i] * gB1[i] / (N * N);
        B1[i] -= lr_t * mb1[i] / (sqrtf(vb1[i]) + EPS);
    }
    for (int i = 0; i < LL * HH; i++)
    {
        mw2[i] = BETA1 * mw2[i] + (1 - BETA1) * gW2[i] / N;
        vw2[i] = BETA2 * vw2[i] + (1 - BETA2) * gW2[i] * gW2[i] / (N * N);
        W2[i] -= lr_t * mw2[i] / (sqrtf(vw2[i]) + EPS);
    }
    for (int i = 0; i < LL; i++)
    {
        mb2[i] = BETA1 * mb2[i] + (1 - BETA1) * gB2[i] / N;
        vb2[i] = BETA2 * vb2[i] + (1 - BETA2) * gB2[i] * gB2[i] / (N * N);
        B2[i] -= lr_t * mb2[i] / (sqrtf(vb2[i]) + EPS);
    }
    for (int i = 0; i < OO * LL; i++)
    {
        mw3[i] = BETA1 * mw3[i] + (1 - BETA1) * gW3[i] / N;
        vw3[i] = BETA2 * vw3[i] + (1 - BETA2) * gW3[i] * gW3[i] / (N * N);
        W3[i] -= lr_t * mw3[i] / (sqrtf(vw3[i]) + EPS);
    }
    for (int i = 0; i < OO; i++)
    {
        mb3[i] = BETA1 * mb3[i] + (1 - BETA1) * gB3[i] / N;
        vb3[i] = BETA2 * vb3[i] + (1 - BETA2) * gB3[i] * gB3[i] / (N * N);
        B3[i] -= lr_t * mb3[i] / (sqrtf(vb3[i]) + EPS);
    }
}
static void accum_grad()
{
    memset(gW1, 0, HH * 4);
    memset(gB1, 0, HH * 4);
    memset(gW2, 0, LL * HH * 4);
    memset(gB2, 0, LL * 4);
    memset(gW3, 0, OO * LL * 4);
    memset(gB3, 0, OO * 4);
    for (int i = 0; i < N; i++)
    {
        gB3[0] += dP[i][0];
        gB3[1] += dP[i][1];
        for (int k = 0; k < LL; k++)
        {
            gW3[0 * LL + k] += dP[i][0] * H2[i][k];
            gW3[1 * LL + k] += dP[i][1] * H2[i][k];
        }
        for (int j = 0; j < LL; j++)
        {
            gB2[j] += dH2[i][j];
            for (int k = 0; k < HH; k++)
                gW2[j * HH + k] += dH2[i][j] * H1[i][k];
        }
        for (int j = 0; j < HH; j++)
        {
            gB1[j] += dH1[i][j];
            gW1[j] += dH1[i][j] * xd[i];
        }
    }
}
static void save_pgm()
{
    int W = 512, Hh = 512;
    unsigned char *img = malloc(W * Hh);
    memset(img, 255, W * Hh);
    for (int i = 0; i < N; i++)
    {
        float px = (P[i][0] + 1.0f) * 0.5f * (W - 1);
        float py = (1.0f - (P[i][1] + 1.0f) * 0.5f) * (Hh - 1);
        int ix = (int)px, iy = (int)py;
        if (ix >= 0 && ix < W && iy >= 0 && iy < Hh)
        {
            img[iy * W + ix] = 0;
            if (ix + 1 < W)
                img[iy * W + ix + 1] = 0;
            if (iy + 1 < Hh)
                img[(iy + 1) * W + ix] = 0;
            if (ix + 1 < W && iy + 1 < Hh)
                img[(iy + 1) * W + ix + 1] = 0;
            if (ix > 0)
                img[iy * W + ix - 1] = 0;
            if (iy > 0)
                img[(iy - 1) * W + ix] = 0;
            if (ix > 0 && iy > 0)
                img[(iy - 1) * W + ix - 1] = 0;
            if (ix + 1 < W && iy > 0)
                img[(iy - 1) * W + ix + 1] = 0;
            if (ix > 0 && iy + 1 < Hh)
                img[(iy + 1) * W + ix - 1] = 0;
        }
    }
    FILE *f = fopen("spiral.pgm", "wb");
    fprintf(f, "P5\n%d %d\n255\n", W, Hh);
    fwrite(img, 1, W * Hh, f);
    fclose(f);
    free(img);
}
int main()
{
    double t0 = now();
    gen_data();
    init_weights();
    double ep_start, epoch_total = 0;
    int actual_epochs = 0;
    for (int e = 1; e <= EPOCHS; e++)
    {
        double et = now();
        fwd();
        bwd();
        accum_grad();
        adam(e);
        double el = now() - et;
        epoch_total += el;
        actual_epochs = e;
        double elapsed = now() - t0;
        if (elapsed > 600.0)
        {
            printf("Time limit approaching, stopping at epoch %d\n", e);
            break;
        }
        if (e % 5000 == 0 || e == 1)
        {
            float l = loss();
            printf("Epoch %d | Loss: %.8f | RMSE: %.6f | Elapsed: %.2fs | EpochTime: %.4fs\n", e, l,
                   sqrtf(l), now() - t0, el);
        }
    }
    float final_loss = loss();
    float rmse = sqrtf(final_loss);
    float accuracy = 1.0f / (1.0f + rmse);
    double total_time = now() - t0;
    double avg_epoch = epoch_total / actual_epochs;
    printf("\n=== Training Complete ===\n");
    printf("Total training time: %.4f s\n", total_time);
    printf("Average epoch time: %.6f s\n", avg_epoch);
    printf("Epochs completed: %d\n", actual_epochs);
    printf("Final MSE Loss: %.10f\n", final_loss);
    printf("Final RMSE: %.10f\n", rmse);
    printf("Accuracy (1/(1+RMSE)): %.8f\n", accuracy);
    printf("Points: %d | Hidden: %d,%d | Outputs: %d\n", N, HH, LL, OO);
    printf("LR: %.6f | BatchSize: %d (full)\n", LR, N);
    printf("Network: 1-%d-%d-2 SELU+Adam\n", HH, LL);
    save_pgm();
    printf("Saved spiral.pgm\n");
    return 0;
}